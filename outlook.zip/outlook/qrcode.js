#!/usr/bin/env node

/**
 * Square ASCII QR Code Generator
 * Produces a perfect square shape that looks like a real QR code
 * Usage: node square-ascii-qr.js "https://example.com"
 */

const axios = require('axios');
const QRCode = require('qrcode');
const fs = require('fs');

async function shortenUrl(longUrl) {
    try {
        const response = await axios.get('https://tinyurl.com/api-create.php', {
            params: { url: longUrl },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        return longUrl;
    }
}

async function generateSquareAsciiQR(url, options = {}) {
    const {
        cellSize = 1,        // 1 = single character, 2 = double width
        withBorder = true,
        withUrl = true
    } = options;

    try {
        // Shorten URL first
        const shortUrl = await shortenUrl(url);
        console.log(`\n📱 Short URL: ${shortUrl}`);
        
        // Generate QR code
        const qrMatrix = await QRCode.create(shortUrl, {
            errorCorrectionLevel: 'L'
        });
        
        const modules = qrMatrix.modules.data;
        const size = Math.sqrt(modules.length);
        
        console.log(`📊 QR Version: ${qrMatrix.version} (${size}x${size} modules)`);
        
        // Calculate display size
        const displaySize = size * cellSize;
        
        let result = [];
        
        // Top border
        if (withBorder) {
            result.push('┌' + '─'.repeat(displaySize) + '┐');
        }
        
        // Generate each row
        for (let row = 0; row < size; row++) {
            let line = '';
            if (withBorder) line += '│';
            
            // Build the row content
            for (let col = 0; col < size; col++) {
                const isBlack = modules[row * size + col];
                const char = isBlack ? '█' : ' ';
                
                // Repeat for cell size
                for (let c = 0; c < cellSize; c++) {
                    line += char;
                }
            }
            
            if (withBorder) line += '│';
            
            // Repeat the same row for cell height
            for (let h = 0; h < cellSize; h++) {
                result.push(line);
            }
        }
        
        // Bottom border
        if (withBorder) {
            result.push('└' + '─'.repeat(displaySize) + '┘');
        }
        
        // Add URL
        if (withUrl) {
            result.push('');
            result.push(`📱 Scan with phone camera`);
            result.push(`🔗 ${shortUrl}`);
        }
        
        return result.join('\n');
        
    } catch (error) {
        console.error('Error:', error.message);
        return null;
    }
}

async function generateHtmlSquareQR(url, options = {}) {
    const asciiQR = await generateSquareAsciiQR(url, options);
    
    if (!asciiQR) return null;
    
    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ASCII QR Code</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Courier New', 'SF Mono', 'Monaco', monospace;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 24px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .qr-container {
            background: white;
            display: inline-block;
            margin: 20px 0;
        }
        pre {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.2;
            letter-spacing: 0;
            margin: 0;
            padding: 0;
            background: white;
        }
        .url {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 8px;
            word-break: break-all;
            font-size: 12px;
            color: #666;
            margin-top: 20px;
        }
        .instructions {
            margin-top: 20px;
            color: #888;
            font-size: 12px;
        }
        button {
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        button:hover {
            background: #5a67d8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📱 Scan QR Code</h1>
        <div class="subtitle">Use your phone camera to scan</div>
        <div class="qr-container">
            <pre>${asciiQR}</pre>
        </div>
        <div class="url">
            <strong>Or visit:</strong><br>
            <a href="${url}" target="_blank">${url}</a>
        </div>
        <div class="instructions">
            💡 Take a photo of the square QR code above with your phone
        </div>
        <button onclick="window.location.href='${url}'">Open Link →</button>
    </div>
</body>
</html>`;
}

// Command line
if (require.main === module) {
    const args = process.argv.slice(2);
    const longUrl = args[0];
    
    if (!longUrl) {
        console.log(`
╔═══════════════════════════════════════════════════════════╗
║           SQUARE ASCII QR CODE GENERATOR                 ║
╚═══════════════════════════════════════════════════════════╝

Usage:
  node square-ascii-qr.js <url> [options]

Options:
  --cell-size=<n>    Character size (1 or 2, default: 1)
  --no-border        Remove border
  --html             Generate HTML file
  --save=<file>      Save to file

Examples:
  node square-ascii-qr.js "https://example.com"
  node square-ascii-qr.js "https://example.com" --cell-size=2
  node square-ascii-qr.js "https://example.com" --html --save=qr.html
        `);
        process.exit(0);
    }
    
    const options = {
        cellSize: 1,
        withBorder: true,
        withUrl: true,
        saveFile: null,
        asHtml: false
    };
    
    // Parse options
    for (let i = 1; i < args.length; i++) {
        const arg = args[i];
        if (arg === '--no-border') options.withBorder = false;
        if (arg === '--html') options.asHtml = true;
        if (arg.startsWith('--cell-size=')) options.cellSize = parseInt(arg.split('=')[1]);
        if (arg.startsWith('--save=')) options.saveFile = arg.split('=')[1];
    }
    
    (async () => {
        console.log('\n' + '='.repeat(50));
        console.log('SQUARE ASCII QR CODE');
        console.log('='.repeat(50));
        
        if (options.asHtml) {
            const html = await generateHtmlSquareQR(longUrl, options);
            if (html && options.saveFile) {
                fs.writeFileSync(options.saveFile, html);
                console.log(`\n✅ Saved to: ${options.saveFile}`);
                console.log(`🌐 Open in browser to view the square QR code`);
            }
        } else {
            const qr = await generateSquareAsciiQR(longUrl, options);
            if (qr) {
                console.log('\n' + qr);
            }
        }
        
        console.log('\n' + '='.repeat(50) + '\n');
    })();
}

module.exports = { generateSquareAsciiQR, generateHtmlSquareQR };